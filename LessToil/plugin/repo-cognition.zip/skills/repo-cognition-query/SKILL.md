---
name: Repository Cognition Query
description: This skill should be used when the user asks about codebase structure, "where is this function called from", "what depends on this file", "find similar code", "impact of changing X", "architectural domains", "call graph", "who calls this", "what does this call", "find duplicates of", "is this code used anywhere", "what are the riskiest files", "show me drift", "governance status", "confidence report", or wants to understand cross-file relationships, project architecture, code dependencies, architectural health, or verification status.
version: 0.2.0
---

## Repository Cognition Query Skill

When the user asks about codebase structure, cross-file relationships, impact analysis, or architectural health, query the repository cognition index first before answering from general knowledge.

### Provenance & Transparency

**Always cite your source.** When answering from the index, append a provenance footer so the user knows the answer came from the structural index (not a slow grep). This builds trust in the plugin's speed:

```
[repo-cognition · index.db · 0.04s]
```

Include the query time when measurable. If you used Python helpers instead of raw SQL, cite the module:
```
[repo-cognition · core.call_graph · transitive dependents]
```

If the index is stale or empty for the relevant data and you fall back to Grep/Glob, say so:
```
[repo-cognition: index miss for <symbol> · fell back to grep]
```

This transparency teaches the user what the plugin knows and when it's helping.

### Available Data

The index is stored in `.claude/index/repo-cognition/index.db` (SQLite, schema v3, 26 tables).

**Always check the index first** before:
- Creating new utility functions (check for existing ones)
- Refactoring a function (check all callers)
- Deleting code (check if anything depends on it)
- Adding new files (check which domain they belong to)
- Moving files between directories (check domain boundaries)
- Editing high-risk files (check temporal risk score)
- Changing security-sensitive symbols (check taint flows)

### Common Queries

#### Find Where a Function Is Defined
```bash
sqlite3 .claude/index/repo-cognition/index.db \
  "SELECT s.name, s.kind, f.file_path, s.start_line, s.confidence_score \
   FROM symbols s JOIN files f ON s.file_id = f.id \
   WHERE s.name LIKE '%<name>%' ORDER BY s.name;"
```

#### Find All Callers of a Function
```bash
sqlite3 .claude/index/repo-cognition/index.db \
  "SELECT DISTINCT s.name, f.file_path, ce.call_line, ce.is_dynamic \
   FROM call_edges ce \
   JOIN symbols s ON ce.caller_id = s.id \
   JOIN files f ON s.file_id = f.id \
   WHERE ce.callee_name = '<name>';"
```

#### Find All Functions Called by a Function
```bash
sqlite3 .claude/index/repo-cognition/index.db \
  "SELECT ce.callee_name, ce.callee_file, ce.call_line, ce.is_dynamic \
   FROM call_edges ce \
   JOIN symbols s ON ce.caller_id = s.id \
   WHERE s.name = '<name>';"
```

#### Impact Analysis (Transitive Dependents)
```bash
sqlite3 .claude/index/repo-cognition/index.db \
  "WITH RECURSIVE deps AS ( \
     SELECT s.id, s.name, f.file_path, 1 AS depth \
     FROM call_edges ce \
     JOIN symbols s ON ce.caller_id = s.id \
     JOIN files f ON s.file_id = f.id \
     WHERE ce.callee_name = '<name>' \
     UNION ALL \
     SELECT s.id, s.name, f.file_path, d.depth + 1 \
     FROM call_edges ce \
     JOIN symbols s ON ce.caller_id = s.id \
     JOIN files f ON s.file_id = f.id \
     JOIN deps d ON ce.callee_name = d.name \
     WHERE d.depth < 10 \
   ) \
   SELECT DISTINCT file_path, name, depth FROM deps \
   ORDER BY depth, file_path LIMIT 200;"
```

#### Find Similar / Duplicate Code
```bash
sqlite3 .claude/index/repo-cognition/index.db \
  "SELECT sg1.file_path, sg1.symbol_name, sg2.file_path, sg2.symbol_name \
   FROM similarity_groups sg1 \
   JOIN similarity_groups sg2 ON sg1.simhash = sg2.simhash \
   WHERE sg1.file_path < sg2.file_path LIMIT 50;"
```

#### Find Files by Architectural Domain
```bash
sqlite3 .claude/index/repo-cognition/index.db \
  "SELECT f.file_path, f.language, fd.confidence \
   FROM files f \
   JOIN file_domains fd ON f.id = fd.file_id \
   JOIN domains d ON fd.domain_id = d.id \
   WHERE d.name = '<domain>' \
   ORDER BY fd.confidence DESC;"
```

#### List All Architectural Domains
```bash
sqlite3 .claude/index/repo-cognition/index.db \
  "SELECT name, description, \
          CASE WHEN security_boundary THEN 'SECURITY BOUNDARY' ELSE '' END \
   FROM domains ORDER BY name;"
```

#### Find Security-Sensitive Functions
```bash
sqlite3 .claude/index/repo-cognition/index.db \
  "SELECT s.name, s.kind, f.file_path, s.start_line \
   FROM symbols s JOIN files f ON s.file_id = f.id \
   WHERE s.security_sensitive = 1 \
   ORDER BY f.file_path;"
```

#### Check if a Symbol Is Dead Code
```bash
sqlite3 .claude/index/repo-cognition/index.db \
  "SELECT s.name, s.kind, f.file_path \
   FROM symbols s JOIN files f ON s.file_id = f.id \
   WHERE s.kind IN ('function', 'method') \
     AND s.name = '<name>' \
     AND s.name NOT IN (SELECT DISTINCT ce.callee_name FROM call_edges);"
```

#### Get Temporal Risk for a File
```bash
sqlite3 .claude/index/repo-cognition/index.db \
  "SELECT file_path, risk_score, total_commits, bug_fix_commits, \
          security_patch_commits, instability \
   FROM temporal_metrics \
   WHERE file_path = '<path>' OR file_path LIKE '%<filename>%' \
   ORDER BY risk_score DESC LIMIT 10;"
```

#### Get Confidence Scores for Symbols in a File
```bash
sqlite3 .claude/index/repo-cognition/index.db \
  "SELECT s.name, s.kind, cs.parser_confidence, cs.type_confidence, \
          cs.runtime_confidence, cs.inferred_purpose_confidence, \
          cs.aggregate_confidence \
   FROM confidence_scores cs \
   JOIN symbols s ON cs.symbol_id = s.id \
   JOIN files f ON s.file_id = f.id \
   WHERE f.file_path = '<path>' \
   ORDER BY cs.aggregate_confidence ASC;"
```

#### Check Governance Violations for a File
```bash
sqlite3 .claude/index/repo-cognition/index.db \
  "SELECT i.name AS invariant, iv.detail, iv.detected_at \
   FROM invariant_violations iv \
   JOIN invariants i ON iv.invariant_id = i.id \
   WHERE iv.file_path = '<path>' AND iv.resolved_at IS NULL \
   UNION ALL \
   SELECT p.name AS policy, pv.detail, pv.detected_at \
   FROM policy_violations pv \
   JOIN policies p ON pv.policy_id = p.id \
   WHERE pv.file_path = '<path>' AND pv.resolved_at IS NULL;"
```

#### Get Architectural Drift for Files
```bash
sqlite3 .claude/index/repo-cognition/index.db \
  "SELECT file_path, architectural_drift_score, line_count \
   FROM files \
   WHERE architectural_drift_score > 0.5 \
   ORDER BY architectural_drift_score DESC LIMIT 20;"
```

#### Get Active Stewardship Suggestions
```bash
sqlite3 .claude/index/repo-cognition/index.db \
  "SELECT severity, category, title, description, file_path \
   FROM stewardship_suggestions \
   WHERE resolved_at IS NULL \
   ORDER BY CASE severity WHEN 'high' THEN 0 WHEN 'medium' THEN 1 ELSE 2 END \
   LIMIT 15;"
```

#### Find Taint Flows (Security)
```bash
sqlite3 .claude/index/repo-cognition/index.db \
  "SELECT s1.name AS source, s2.name AS target, tf.depth \
   FROM taint_flows tf \
   JOIN symbols s1 ON tf.source_id = s1.id \
   JOIN symbols s2 ON tf.target_id = s2.id \
   ORDER BY tf.depth DESC LIMIT 30;"
```

#### Check Immune System Alerts
```bash
sqlite3 .claude/index/repo-cognition/index.db \
  "SELECT signal_type, severity, description, detected_at \
   FROM immune_alerts \
   WHERE resolved_at IS NULL \
   ORDER BY CASE severity WHEN 'high' THEN 0 WHEN 'medium' THEN 1 ELSE 2 END \
   LIMIT 20;"
```

#### Toolchain Audit Trail
```bash
sqlite3 .claude/index/repo-cognition/index.db \
  "SELECT tool_name, verification_result, consensus_result, \
          CASE WHEN approved THEN 'approved' ELSE 'blocked' END as status, \
          recorded_at \
   FROM toolchain_audit \
   ORDER BY recorded_at DESC LIMIT 20;"
```

### Using Python for Complex Queries

For queries that require multi-step logic, use the Python helper modules:
```bash
CLAUDE_PLUGIN_ROOT="${CLAUDE_PLUGIN_ROOT:-.}" python -c "
import sys
sys.path.insert(0, '${CLAUDE_PLUGIN_ROOT}')

# Choose the appropriate module:
# from core.call_graph import get_callers, get_callees, get_transitive_dependents
# from core.confidence import get_confidence_summary, get_low_confidence_symbols
# from core.temporal import get_riskiest_files, get_temporal_summary
# from core.stewardship import get_top_suggestions, get_stewardship_summary
# from core.drift_detection import get_drift_summary, compute_file_drift
# from core.governance import get_governance_summary, check_all_invariants
# from core.consensus import consensus_check
# from core.self_healing import run_self_healing_pass
# from core.operational_sovereignty import health_check, is_operational
# from core.epistemic import get_epistemic_summary, stale_belief_check
# from core.verification import verify_change, get_verification_summary

# Example: get full architectural health report
from core.temporal import get_temporal_summary
from core.confidence import get_confidence_summary
from core.stewardship import get_stewardship_summary
from core.drift_detection import get_drift_summary
from core.governance import get_governance_summary
import json

report = {
    'temporal': get_temporal_summary(),
    'confidence': get_confidence_summary(),
    'stewardship': get_stewardship_summary(),
    'drift': get_drift_summary(),
    'governance': get_governance_summary(),
}
print(json.dumps(report, indent=2))
"
```

### Fallback

If the index database does not exist or is empty, use `/index-rebuild` to create it, or fall back to Grep/Glob-based search.
