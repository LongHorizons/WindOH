# Repository Cognition Engine

A persistent project cognition layer for Claude Code that indexes your repository into a structural taxonomy (SQLite + JSON), keeps it incrementally updated across sessions, and enforces architectural governance through a 10-phase verification pipeline.

## What It Does

### Indexing & Structural Awareness
- **Indexes** every file (SHA256, language, size, line count) across 56 languages
- **Extracts** symbols (functions, classes, methods, imports) via tree-sitter + regex fallback
- **Builds** a weighted call graph across all files with static + dynamic edge tracking
- **Infers** architectural domains (auth, payments, caching, API, UI, etc.)
- **Detects** duplicated code blocks via SimHash 64-bit fingerprinting
- **Analyzes** git history for temporal risk (churn, bug density, ownership volatility)

### Verification & Governance (Pre-Edit)
- **10-Phase Verification Pipeline**: PLAN → SIMULATE → VERIFY → CONSTRAIN → EXECUTE → TEST → TRACE → SCORE → REPAIR → REVERIFY
- **Invariant enforcement** (SQL queries: 0 rows = satisfied, >0 rows = violation)
- **Policy checks** (max function complexity, max dependency depth, max file size, require tests for security paths)
- **9 Formal constraints** (no circular imports, no dynamic eval, security boundary enforcement, max call depth)
- **6-verifier consensus engine** with disagreement detection and resolution
- **Change simulation** grades edits as safe/cautious/risky/dangerous — dangerous blocks with exit code 2

### Runtime Awareness (Post-Edit)
- **Confidence-weighted planning** across 4 axes (parser, type, runtime, purpose) — weakest-link aggregation
- **Runtime profiling** wraps test execution with cProfile/pprof/node-prof, maps hot functions to indexed symbols
- **Confidence feedback loop** adjusts scores based on profiling data and test results
- **Incremental reindex** of changed files only (~1s per file)

### Architectural Intelligence (Session Start)
- **Autonomous stewardship** scans for dead subsystems, over-complex files, high-churn hotspots, dangerous coupling, unowned critical paths
- **Architectural drift detection** (naming divergence, style outliers, anti-pattern emergence, framework creep)
- **Self-healing loop**: Detect → Propose → Validate → Repair cycle across 4 anomaly sources
- **Repository immune system**: behavioral baseline → anomaly detection → quarantine
- **Knowledge distillation**: per-domain summaries, approved primitives, canonical patterns, forbidden abstractions
- **Unified graph export**: AST + type + runtime + profiling + temporal merged into weighted multi-edge graph (JSON + DOT)

### Advanced Intelligence
- **Epistemic awareness**: evidence provenance for every inference, contradiction detection, stale belief checking
- **Long-horizon forecasting**: projects architecture at 1x/2x/5x/10x scale with risk assessment
- **Semantic compression**: detects equivalent paradigms beyond literal duplication
- **Economics**: build/CI/cloud/dev-hours cost estimation and optimization
- **Cognitive load modeling**: understandability, debugging difficulty, conceptual compression metrics
- **Intent preservation**: tracks WHY abstractions exist, detects intent drift across refactors
- **Adversarial robustness**: detects deceptive patterns, semantic mismatch, hidden execution paths
- **Knowledge decay detection**: flags stale beliefs when source data changes
- **Operational sovereignty**: health checks, corruption repair, graceful degradation
- **Reality alignment**: business correctness vs. technical correctness, Pareto optimization
- **Meta-reasoning**: self-modeling failure tracking, blind spot detection, confidence calibration
- **Toolchain auditor**: every tool invocation recorded with verification trail, trust scoring

## Architecture

```
SessionStart Hook (120s budget)
  ├─ Health check → Index files → Extract symbols → Build call graph
  ├─ Compute confidence scores (parser + type + runtime + purpose)
  ├─ Compute temporal metrics (git history churn/risk analysis)
  ├─ Persist architectural drift scores
  ├─ Run stewardship scans → Persist suggestions
  ├─ Run self-healing pass (Detect → Propose → Validate)
  ├─ Seed invariants + policies (idempotent)
  ├─ Generate CLAUDE.md query reference
  └─ Inject structural summary into agent context

PreToolUse Hook (45s budget, Write/Edit/MultiEdit)
  ├─ Verification Pipeline: PLAN → SIMULATE → VERIFY → CONSTRAIN
  ├─ Governance checks: invariants + policies (can exit 2 to block)
  ├─ Simulation: multi-file changes graded safe/cautious/risky/dangerous
  ├─ Impact analysis: affected callers, tests, domains
  ├─ Confidence warnings for low-confidence symbols
  ├─ Duplicate detection against existing symbol index
  └─ Block dangerous edits (exit 2) or warn

PostToolUse Hook (45s budget, Write/Edit/MultiEdit)
  ├─ Incremental reindex of changed files
  ├─ Re-extract symbols + rebuild call edges
  ├─ Confidence feedback loop (incorporate profiling signals)
  ├─ Temporal change counter increment
  ├─ Post-execute verification (TRACE + SCORE phases)
  └─ Minimal output to avoid flooding transcript
```

## Database Schema v3

**26 tables** across 8 categories:

| Category | Tables |
|----------|--------|
| Core Index | `files`, `symbols`, `call_edges`, `domains`, `file_domains` |
| Similarity | `similarity_groups` |
| Confidence | `confidence_scores` |
| Temporal | `temporal_metadata`, `temporal_metrics`, `temporal_change_log` |
| Governance | `invariants`, `invariant_violations`, `policies`, `policy_violations` |
| Security | `taint_sources`, `taint_flows` |
| Profiling | `profile_snapshots` |
| Intelligence | `stewardship_suggestions`, `evidence_records`, `evidence_dependencies`, `contradictions`, `immune_baselines`, `immune_alerts`, `intent_records`, `toolchain_audit` |
| Meta | `schema_version` |

## Data Stores

| Location | Format | Purpose |
|----------|--------|---------|
| `.claude/index/repo-cognition/index.db` | SQLite (WAL) | All structured index data |
| `.claude/index/repo-cognition/file_manifest.json` | JSON | Flat file manifest with SHA256 |
| `.claude/index/repo-cognition/CLAUDE.md` | Markdown | Auto-generated schema reference + query examples |
| `.claude/index/repo-cognition/unified_graph.json` | JSON | Weighted multi-edge graph (AST + type + runtime + temporal) |
| `.claude/index/repo-cognition/unified_graph.dot` | DOT | Graphviz-compatible visualization |
| `.claude/index/repo-cognition/last_index.txt` | Text | Last index timestamp |
| `.claude/index/repo-cognition/indexing.lock` | Lockfile | Concurrent indexing guard |
| `.claude/repo-cognition.domains.local.md` | Markdown + YAML | Architectural domains (persistent across sessions) |
| `.claude/repo-cognition.patterns.local.md` | Markdown + YAML | Learned patterns (persistent) |
| `.claude/repo-cognition.policies.local.md` | Markdown + YAML | Custom governance policies |
| `.claude/repo-cognition.knowledge.local.md` | Markdown + YAML | Distilled architectural knowledge |

## Core Modules

### Foundation
| Module | Purpose |
|--------|---------|
| `manifest.py` | SQLite DDL, CRUD, schema migrations (v1→v2→v3) |
| `indexer.py` | Repository walker, SHA256, language detection |
| `symbols.py` | tree-sitter + regex symbol extraction |
| `call_graph.py` | Call graph construction and traversal |
| `domains.py` | Architectural domain inference |
| `similarity.py` | SimHash duplicate detection |
| `impact.py` | Impact analysis for proposed changes |
| `dot_gen.py` | DOT graph generation |
| `formatting.py` | Dashboard and output formatting for hook display |

### Confidence & Temporal
| Module | Purpose |
|--------|---------|
| `confidence.py` | 4-axis confidence (parser, type, runtime, purpose), weakest-link aggregation, feedback loop |
| `temporal.py` | Git log analysis, churn/bug-density/risk scoring, change counter |

### Governance & Security
| Module | Purpose |
|--------|---------|
| `governance.py` | SQL invariants + policy enforcement, pre-edit simulation, 3 built-in invariants + 6 policies |
| `security_provenance.py` | Taint analysis, trust boundary crossing detection, per-language patterns |
| `intent_planner.py` | Intent → ConstraintSet → ExecutionPlan translation |

### Analysis & Detection
| Module | Purpose |
|--------|---------|
| `drift_detection.py` | Naming divergence, style outliers, anti-patterns, framework creep, drift persistence |
| `refactor_scoring.py` | Weighted refactor scoring (duplication, maintenance, dependency, migration risk) |
| `minimalism.py` | Abstraction density, dependency entropy, state surface area, simplicity scoring |
| `simulation.py` | Multi-file change simulation with safe/cautious/risky/dangerous grading |
| `mutation_sandbox.py` | Sandboxed code mutation testing and verification |

### Runtime & Visualization
| Module | Purpose |
|--------|---------|
| `runtime_profiling.py` | cProfile/pprof/node-prof wrapping, hot function → symbol mapping |
| `unified_graph.py` | AST + type + runtime + profiling + temporal merged graph (JSON + DOT export) |
| `knowledge_distillery.py` | Domain summaries, approved primitives, canonical patterns, forbidden abstractions |

### Stewardship & Self-Healing
| Module | Purpose |
|--------|---------|
| `stewardship.py` | 6 scan categories: dead subsystems, over-complex, hotspots, coupling, unowned critical paths, stale patterns |
| `self_healing.py` | Detect → Propose → Validate → Repair cycle across 4 anomaly sources |

### Verification & Consensus
| Module | Purpose |
|--------|---------|
| `verification.py` | 10-phase pipeline orchestrator (PLAN → REVERIFY) |
| `consensus.py` | 6-verifier consensus engine with disagreement resolution |
| `formal_constraints.py` | 9 machine-enforced constraints (circular imports, dynamic eval, security boundaries, etc.) |

### Epistemic & Immune
| Module | Purpose |
|--------|---------|
| `epistemic.py` | Evidence provenance, contradiction detection, stale belief checking |
| `immune_system.py` | Behavioral baseline, anomaly detection, quarantine, intrusion detection |

### Advanced Intelligence
| Module | Purpose |
|--------|---------|
| `forecasting.py` | 1x/2x/5x/10x scale architectural projection + alternative synthesis |
| `semantic_compression.py` | Equivalent paradigm detection beyond literal duplication |
| `economics.py` | Build/CI/cloud/dev-hours cost estimation and optimization |
| `cognitive_load.py` | Understandability, debugging difficulty, conceptual compression |
| `intent_preservation.py` | Design intent tracking, consistency checking, drift detection |
| `adversarial.py` | Deceptive patterns, semantic mismatch, hidden execution paths |
| `knowledge_decay.py` | Stale belief detection, knowledge freshness scoring |
| `operational_sovereignty.py` | Health checks, corruption repair, operational status |
| `reality_alignment.py` | Business vs. technical correctness, Pareto optimization |
| `meta_reasoning.py` | Failure tracking, blind spot detection, confidence calibration |
| `toolchain_auditor.py` | Tool invocation audit trail, trust scoring |

### Hook Scripts
| Hook | Budget | Purpose |
|------|--------|---------|
| `session_start.py` | 120s | Full index, confidence, temporal, drift, stewardship, self-healing, context injection |
| `pre_tool_use.py` | 45s | Verification pipeline, governance, simulation, impact, confidence, duplicates |
| `post_tool_use.py` | 45s | Incremental reindex, confidence feedback, temporal counter, post-execute verify |

## Commands

- `/index-status` — Show index health, file counts, domain map, drift, stewardship, confidence
- `/index-rebuild` — Force full reindex from scratch (clears DB, rewalks repo)
- `/index-graph <name>` — Generate call graph for a function
- `/index-graph --domain-graph` — Generate cross-domain dependency graph
- `/index-graph --hotspots` — Show most-called functions
- `/index-graph --orphans` — Show functions never called

## Skill

The `Repository Cognition Query` skill auto-activates when you ask:
- "Where is X called from?"
- "What depends on Y?"
- "What's the impact of changing Z?"
- "Find similar code to this"
- "What architectural domain does this belong to?"
- "Is this code used anywhere?"
- "What are the riskiest files?"

## Supported Languages

| Language | File Index | Symbol Extraction | Call Graph | Profiling |
|----------|-----------|-------------------|------------|-----------|
| Python | Yes | tree-sitter + regex | Yes | cProfile |
| TypeScript | Yes | tree-sitter + regex | Yes | node --prof |
| JavaScript | Yes | tree-sitter + regex | Yes | node --prof |
| Go | Yes | tree-sitter + regex | Yes | pprof |
| Rust | Yes | tree-sitter + regex | Yes | — |
| Java | Yes | tree-sitter + regex | Basic | — |
| C/C++ | Yes | tree-sitter + regex | Basic | — |
| C# | Yes | tree-sitter + regex | Basic | — |
| Ruby | Yes | tree-sitter + regex | Basic | — |
| PHP | Yes | tree-sitter + regex | Basic | — |
| Kotlin | Yes | tree-sitter + regex | Basic | — |
| Swift | Yes | tree-sitter + regex | Basic | — |
| Scala | Yes | tree-sitter + regex | Basic | — |
| Lua | Yes | tree-sitter + regex | Basic | — |
| YAML/TOML/JSON | Yes | N/A | N/A | — |
| Dockerfile | Yes | N/A | N/A | — |
| Terraform/HCL | Yes | N/A | N/A | — |
| SQL | Yes | N/A | N/A | — |
| Shell/Bash | Yes | N/A | N/A | — |
| ... 20+ more | Yes | N/A | N/A | — |

## Install

### Windows (PowerShell)

```powershell
# One-liner from GitHub
irm https://raw.githubusercontent.com/anthropics/claude-code/main/plugins/repo-cognition/install.ps1 | iex

# Or from a local clone
.\install.ps1
```

### macOS / Linux (Bash)

```bash
# One-liner from GitHub
bash <(curl -fsSL https://raw.githubusercontent.com/anthropics/claude-code/main/plugins/repo-cognition/install.sh)

# Or from a local clone
bash install.sh
```

### Offline Install (from release zip)

If you have the release zip (`repo-cognition.zip`), no Git or GitHub access is needed:

```bash
# Bash
bash install.sh --from-zip repo-cognition.zip

# PowerShell
.\install.ps1 -FromZip repo-cognition.zip
```

The installer auto-detects `repo-cognition.zip` in the current directory or adjacent `Presentation/plugin/` folder, so running the installer from the Presentation directory works without flags.

### Options

| Flag (Bash) | Flag (PowerShell) | Purpose |
|-------------|-------------------|---------|
| `--project-dir /path` | `-ProjectDir PATH` | Set up a specific project |
| `--plugin-only` | `-PluginOnly` | Only install the plugin, skip project setup |
| `--reindex` | `-Reindex` | Force immediate index build after install |
| `--from-zip FILE` | `-FromZip FILE` | Install from a local release zip (no Git needed) |

**Source priority**: `--from-zip` > local clone > GitHub fetch

### What Happens

The installer does 7 things:
1. Fetches the plugin from GitHub (sparse checkout) if no local source or zip is available
2. Copies the plugin to `~/.claude/plugins/repo-cognition/`
3. Installs Python dependencies (tree-sitter, pyyaml, 36 grammar packages)
4. Validates all core modules (AST parse check)
5. Creates `.claude/CLAUDE.md` in your project with index-first query instructions
6. Generates `.claude/index/repo-cognition/CLAUDE.md` with schema reference
7. Optionally runs the first index build (`--reindex`)

After install, restart Claude Code or open a new session — the SessionStart hook indexes your repository automatically.

## Configuration

No configuration required — the engine works out of the box.

To customize behavior, create `.claude/repo-cognition.settings.local.md`:
```yaml
---
exclude_dirs: [".terraform", ".cache", "vendor"]
max_extraction_time_sec: 30
similarity_threshold: 0.85
---
```

Custom governance rules go in `.claude/repo-cognition.policies.local.md`:
```yaml
---
invariants:
  - name: my_custom_rule
    description: "Custom architectural constraint"
    severity: error
    enabled: true
policies:
  - name: max_function_complexity
    category: complexity
    threshold_value: 50
    severity: warning
    enabled: true
---
```

## Performance

- **Small repos (<1K files)**: Full index in <5 seconds, all intelligence modules active
- **Medium repos (1K-10K files)**: File index in <15 seconds, symbols in background, drift/stewardship on top 100 files
- **Large repos (>10K files)**: File index in <30 seconds, symbols deferred, intelligence modules sampled
- **Incremental reindex**: <1 second per changed file
- **Hook budgets**: SessionStart 120s, PreToolUse 45s, PostToolUse 45s
- **Graceful degradation**: All advanced modules wrapped in try/except, never block on failure

## Verification Grade System

| Grade | Meaning | Hook Behavior |
|-------|---------|---------------|
| `safe` | Low-impact single file change | Silent pass |
| `cautious` | Moderate impact detected | Advisory warning |
| `risky` | Significant cross-domain impact | Prominent warning |
| `dangerous` | High-risk multi-domain change | **Blocked** (exit code 2) |

## Schema Migration

The database auto-migrates on `init_db()`:
- **v1 → v2**: Adds confidence_scores, temporal tables, governance tables, taint analysis, profile snapshots, new columns
- **v2 → v3**: Adds stewardship_suggestions, evidence_records/dependencies, contradictions, immune_baselines/alerts, intent_records, toolchain_audit

Migration preserves all existing data. Run `/index-rebuild` for a clean start.
