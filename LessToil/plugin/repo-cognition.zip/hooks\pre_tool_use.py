#!/usr/bin/env python3
"""
PreToolUse hook for the Repository Cognition Engine.

All 40 analysis modules run at full capacity — verification pipeline,
impact analysis, governance checks, duplicate detection, confidence
scoring. Output is suppressed for safe/cautious edits; only risky,
dangerous, and blocked edits produce visible output.
"""

from __future__ import annotations

import json
import os
import sys
import time

PLUGIN_ROOT = os.environ.get('CLAUDE_PLUGIN_ROOT', '')
if not PLUGIN_ROOT:
    PLUGIN_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PLUGIN_ROOT:
    sys.path.insert(0, PLUGIN_ROOT)

from core import PROJECT_DIR
from core.manifest import get_connection
from core.formatting import (
    safe_line, cautious_line, risky_line, dangerous_line,
)


def read_hook_input() -> dict:
    try:
        raw = sys.stdin.read()
        if not raw.strip():
            return {}
        return json.loads(raw)
    except json.JSONDecodeError:
        return {}


def extract_file_path_and_content(tool_name: str, tool_input: dict) -> list[dict]:
    """Extract affected file paths and new content from tool input."""
    results = []

    if tool_name == 'Write':
        file_path = tool_input.get('file_path', '')
        content = tool_input.get('content', '')
        if file_path:
            results.append({'file_path': file_path, 'content': content})
    elif tool_name == 'Edit':
        file_path = tool_input.get('file_path', '')
        new_string = tool_input.get('new_string', '')
        old_string = tool_input.get('old_string', '')
        if file_path:
            results.append({
                'file_path': file_path,
                'content': new_string,
                'old_content': old_string,
            })
    elif tool_name == 'MultiEdit':
        edits = tool_input.get('edits', [])
        base_path = tool_input.get('file_path', '')
        for edit in edits:
            edit_path = edit.get('file_path', base_path)
            if edit_path:
                results.append({
                    'file_path': edit_path,
                    'content': edit.get('new_string', ''),
                    'old_content': edit.get('old_string', ''),
                })

    return results


def get_impact_context(file_paths: list[str]) -> dict:
    """Get full impact context: callers, domains, security sensitivity."""
    ctx = {
        'total_callers': 0,
        'affected_files': 0,
        'primary_domain': 'unknown',
        'affected_domains': [],
        'security_symbols': [],
        'test_files': [],
    }

    if not file_paths:
        return ctx

    conn = get_connection()
    try:
        placeholders = ','.join('?' for _ in file_paths)

        # Symbols in target files
        cur = conn.execute(
            f"""SELECT s.name, s.kind, s.security_sensitive
                FROM symbols s
                JOIN files f ON s.file_id = f.id
                WHERE f.file_path IN ({placeholders})
                LIMIT 50""",
            file_paths
        )
        affected_symbols = [
            {"name": r[0], "kind": r[1], "security_sensitive": bool(r[2])}
            for r in cur.fetchall()
        ]

        if not affected_symbols:
            return ctx

        sym_names = [s['name'] for s in affected_symbols]
        name_placeholders = ','.join('?' for _ in sym_names)
        security_syms = [s for s in affected_symbols if s['security_sensitive']]

        # Count callers
        cur2 = conn.execute(
            f"""SELECT COUNT(DISTINCT ce.caller_id), COUNT(DISTINCT f2.file_path)
                FROM call_edges ce
                JOIN symbols s2 ON ce.caller_id = s2.id
                JOIN files f2 ON s2.file_id = f2.id
                WHERE ce.callee_name IN ({name_placeholders})""",
            sym_names
        )
        row = cur2.fetchone()
        ctx['total_callers'] = row[0] if row else 0
        ctx['affected_files'] = row[1] if row else 0

        # Affected domains
        cur3 = conn.execute(
            f"""SELECT DISTINCT d.name, d.security_boundary
                FROM domains d
                JOIN file_domains fd ON d.id = fd.domain_id
                JOIN files f ON fd.file_id = f.id
                WHERE f.file_path IN ({placeholders})""",
            file_paths
        )
        affected_domains = [
            {"name": r[0], "security_boundary": bool(r[1])}
            for r in cur3.fetchall()
        ]
        if affected_domains:
            ctx['primary_domain'] = affected_domains[0]['name']
            ctx['affected_domains'] = [d['name'] for d in affected_domains]

        # Security symbols
        if security_syms:
            ctx['security_symbols'] = [s['name'] for s in security_syms[:5]]

        # Test files that may need updates
        cur4 = conn.execute(
            f"""SELECT DISTINCT f2.file_path
                FROM call_edges ce
                JOIN symbols s2 ON ce.caller_id = s2.id
                JOIN files f2 ON s2.file_id = f2.id
                WHERE ce.callee_name IN ({name_placeholders})
                  AND (f2.file_path LIKE '%test%' OR f2.file_path LIKE '%spec%'
                       OR f2.file_path LIKE '%__tests__%')
                LIMIT 10""",
            sym_names
        )
        ctx['test_files'] = [r[0] for r in cur4.fetchall()]

    finally:
        conn.close()

    return ctx


def build_warning_list(impact_ctx: dict, conf_warnings: list[str],
                       dup_warnings: list[str]) -> list[str]:
    """Aggregate all advisory warnings into one list."""
    warnings = []

    if impact_ctx['total_callers'] > 0:
        domain_str = ''
        if impact_ctx['affected_domains']:
            domain_str = f" across {', '.join(impact_ctx['affected_domains'][:3])}"
        warnings.append(
            f"Editing {impact_ctx['affected_files']} files impacts "
            f"{impact_ctx['total_callers']} call site(s){domain_str}"
        )

    if impact_ctx['security_symbols']:
        sym_str = ', '.join(impact_ctx['security_symbols'][:3])
        warnings.append(f"Security-sensitive: {sym_str}")

    if impact_ctx['test_files']:
        test_str = ', '.join(impact_ctx['test_files'][:3])
        if len(impact_ctx['test_files']) > 3:
            test_str += f' +{len(impact_ctx["test_files"]) - 3} more'
        warnings.append(f"Tests may need updates: {test_str}")

    warnings.extend(conf_warnings)
    warnings.extend(dup_warnings)

    return warnings


def get_confidence_warnings(file_paths: list[str]) -> list[str]:
    """Check for low-confidence symbols in the target files."""
    warnings = []

    if not file_paths:
        return warnings

    try:
        from core.confidence import get_low_confidence_symbols, LOW_CONFIDENCE_THRESHOLD

        conn = get_connection()
        try:
            placeholders = ','.join('?' for _ in file_paths)
            cur = conn.execute(
                f"""SELECT s.name, s.kind, s.confidence_score, f.file_path
                    FROM symbols s
                    JOIN files f ON s.file_id = f.id
                    WHERE f.file_path IN ({placeholders})
                      AND s.confidence_score < ?
                    ORDER BY s.confidence_score ASC
                    LIMIT 6""",
                file_paths + [LOW_CONFIDENCE_THRESHOLD]
            )
            low_syms = [
                {'name': r[0], 'kind': r[1], 'confidence': r[2], 'file': r[3]}
                for r in cur.fetchall()
            ]
        finally:
            conn.close()

        if low_syms:
            names = ', '.join(f"`{s['name']}`" for s in low_syms[:4])
            if len(low_syms) > 4:
                names += f' +{len(low_syms) - 4} more'
            warnings.append(
                f"Low-confidence symbols: {names} "
                f"(avg {sum(s['confidence'] for s in low_syms) / len(low_syms):.2f})"
            )
    except Exception:
        pass

    return warnings


def get_duplicate_warnings(file_path: str, content: str) -> list[str]:
    """Check new content for symbols that already exist in the index."""
    warnings = []

    if not content or len(content) < 50:
        return warnings

    conn = get_connection()
    try:
        import re
        new_names = set()
        for match in re.finditer(
            r'(?:def|class|function|const|let|var|fn|func)\s+(\w+)',
            content
        ):
            new_names.add(match.group(1))

        for name in new_names:
            cur = conn.execute(
                "SELECT COUNT(*) FROM symbols WHERE name = ?", (name,)
            )
            count = cur.fetchone()[0]
            if count > 0:
                cur2 = conn.execute(
                    """SELECT f.file_path, s.kind
                       FROM symbols s JOIN files f ON s.file_id = f.id
                       WHERE s.name = ? LIMIT 3""",
                    (name,)
                )
                existing = [f"{r[0]} ({r[1]})" for r in cur2.fetchall()]
                if existing:
                    existing_str = ', '.join(existing)
                    warnings.append(
                        f"`{name}` already exists in: {existing_str}"
                    )
    finally:
        conn.close()

    return warnings


def determine_grade(verification: dict, num_files: int,
                    impact_ctx: dict) -> str:
    """Determine the overall edit grade: safe | cautious | risky | dangerous."""
    if verification.get('block'):
        return 'dangerous'

    risk_score = 0

    if num_files > 3:
        risk_score += 2
    elif num_files > 1:
        risk_score += 1

    if len(impact_ctx.get('affected_domains', [])) > 2:
        risk_score += 2
    elif len(impact_ctx.get('affected_domains', [])) > 1:
        risk_score += 1

    if impact_ctx.get('total_callers', 0) > 20:
        risk_score += 2
    elif impact_ctx.get('total_callers', 0) > 5:
        risk_score += 1

    if impact_ctx.get('security_symbols'):
        risk_score += 2

    sim_results = verification.get('phase_results', [])
    for pr in sim_results:
        if pr.get('phase') == 'simulate' and not pr.get('passed'):
            risk_score += 2

    if risk_score >= 6:
        return 'dangerous'
    elif risk_score >= 4:
        return 'risky'
    elif risk_score >= 2:
        return 'cautious'
    return 'safe'


def main():
    t_start = time.time()

    input_data = read_hook_input()
    tool_name = input_data.get('tool_name', '')
    tool_input = input_data.get('tool_input', {})

    if tool_name not in ('Write', 'Edit', 'MultiEdit'):
        sys.exit(0)

    # Respect CLAUDE_PROJECT_DIR
    if 'CLAUDE_PROJECT_DIR' in os.environ:
        import core
        core.PROJECT_DIR = os.environ['CLAUDE_PROJECT_DIR']

    entries = extract_file_path_and_content(tool_name, tool_input)
    if not entries:
        sys.exit(0)

    file_paths = [e['file_path'] for e in entries if e['file_path']]
    all_errors = []
    verification = {}

    # ── Verification pipeline (PLAN → SIMULATE → VERIFY → CONSTRAIN) ──
    try:
        from core.verification import verify_change
        session_id = input_data.get('session_id', '')
        old_content = {e['file_path']: e.get('old_content', '') for e in entries if e.get('old_content')}
        new_content = {e['file_path']: e.get('content', '') for e in entries if e.get('content')}
        verification = verify_change(file_paths, session_id, old_content, new_content)
        if verification.get('block'):
            for detail in verification.get('details', []):
                all_errors.append(detail)
    except Exception:
        pass

    # ── Impact context ──
    impact_ctx = get_impact_context(file_paths)

    # ── Confidence warnings ──
    conf_warnings = get_confidence_warnings(file_paths)

    # ── Duplicate detection ──
    dup_warnings = []
    for entry in entries:
        content = entry.get('content', '')
        if content:
            try:
                dup_warnings.extend(get_duplicate_warnings(entry['file_path'], content))
            except Exception:
                pass

    # ── Aggregate warnings ──
    all_warnings = build_warning_list(impact_ctx, conf_warnings, dup_warnings)

    # Add verification recommendations
    for rec in verification.get('recommendations', []):
        all_warnings.append(rec)

    # ── Determine grade ──
    grade = determine_grade(verification, len(file_paths), impact_ctx)

    # ── Build simulation summary ──
    simulation = {}
    if len(file_paths) > 1:
        try:
            from core.simulation import simulate_change
            simulation = simulate_change(file_paths)
            sim_grade = simulation.get('grade', 'safe')
            if sim_grade in ('risky', 'dangerous') and grade == 'safe':
                grade = sim_grade
        except Exception:
            pass

    elapsed_ms = (time.time() - t_start) * 1000

    domain_str = impact_ctx.get('primary_domain', '?')
    callers = impact_ctx.get('total_callers', 0)
    affected = impact_ctx.get('affected_domains', [])

    # All analysis ran. Now produce minimal output — only when noteworthy.
    output = {}

    if grade == 'dangerous':
        # Warn prominently but never block — the user is in control
        msg = dangerous_line(file_paths, all_errors, elapsed_ms)
        output['systemMessage'] = msg
    elif grade == 'risky':
        sim_grade = simulation.get('grade', 'risky')
        msg = risky_line(file_paths, domain_str, callers, affected,
                         all_warnings, sim_grade, elapsed_ms)
        if msg:
            output['systemMessage'] = msg
    elif grade == 'cautious':
        msg = cautious_line(file_paths, domain_str, callers,
                            all_warnings, elapsed_ms)
        if msg:
            output['systemMessage'] = msg

    # Safe: silent — no output at all

    if output:
        print(json.dumps(output))
    sys.exit(0)


if __name__ == "__main__":
    main()
