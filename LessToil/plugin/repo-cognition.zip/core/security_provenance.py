"""Security provenance tracking: taint analysis and trust boundary enforcement.

Identifies taint sources (user input, network, file I/O), propagates taint
through the call graph, detects trust boundary crossings, and traces secret
access paths backward from security_sensitive symbols.
"""

from __future__ import annotations

import re
from typing import Optional

from .manifest import get_connection

# Taint source regex patterns by language
TAINT_SOURCE_PATTERNS = {
    'python': [
        r'request\.(args|form|json|data|files|get|post)\b',
        r'input\s*\(', r'raw_input\s*\(',
        r'os\.environ', r'os\.getenv\s*\(',
        r'open\s*\(', r'file\s*\(',
        r'\.read\s*\(', r'\.readlines\s*\(',
        r'socket\.', r'urllib\.', r'httpx\.',
        r'\.recv\s*\(', r'\.accept\s*\(',
        r'yaml\.(load|safe_load)\s*\(', r'json\.loads?\s*\(',
        r'pickle\.load', r'marshal\.load',
        r'subprocess\.(run|call|Popen|check_output)',
        r'os\.(system|popen|execv)',
        r'exec\s*\(', r'eval\s*\(',
    ],
    'typescript': [
        r'\.(query|params|body|cookies|headers)\b',
        r'fetch\s*\(', r'axios\.', r'XMLHttpRequest',
        r'addEventListener\s*\(', r'\.on\s*\(',
        r'fs\.readFile', r'fs\.writeFile',
        r'process\.env', r'process\.argv',
        r'localStorage\.', r'sessionStorage\.',
        r'JSON\.parse\s*\(', r'\.innerHTML\s*=',
        r'document\.cookie', r'window\.location',
    ],
    'javascript': [
        r'\.(query|params|body|cookies|headers)\b',
        r'fetch\s*\(', r'axios\.', r'XMLHttpRequest',
        r'addEventListener\s*\(', r'\.on\s*\(',
        r'fs\.readFile', r'fs\.writeFile',
        r'process\.env', r'process\.argv',
        r'localStorage\.', r'sessionStorage\.',
        r'JSON\.parse\s*\(', r'\.innerHTML\s*=',
        r'document\.cookie', r'window\.location',
    ],
    'go': [
        r'http\.Request', r'\.FormValue\s*\(', r'\.PostFormValue\s*\(',
        r'\.Query\s*\(', r'\.Header\.Get\s*\(',
        r'os\.(Open|Create|ReadFile)\s*\(', r'ioutil\.ReadFile\s*\(',
        r'os\.(Getenv|Environ|Args)', r'flag\.',
        r'json\.(Unmarshal|NewDecoder)', r'yaml\.(Unmarshal|NewDecoder)',
        r'gob\.NewDecoder', r'xml\.(Unmarshal|NewDecoder)',
        r'bufio\.', r'net\.(Dial|Listen|Accept)',
        r'exec\.Command\s*\(', r'crypto/(rand|tls)',
    ],
    'rust': [
        r'std::io::stdin', r'std::env::args', r'std::env::var',
        r'std::fs::(read|read_to_string|File::open)',
        r'reqwest::', r'hyper::', r'serde_json::from_',
        r'\.read_to_string\s*\(', r'\.read\s*\(',
        r'Command::new\s*(', r'std::process::',
    ],
}

# Sanitizer patterns
SANITIZER_PATTERNS = [
    r'(?:html_escape|escape_html|sanitize|validate|verify|clean)\w*\s*\(',
    r'\.(?:strip|trim|replace|encode|escape)\s*\(',
    r'(?:filter_var|filter_input)\s*\(',
    r'(?:htmlspecialchars|htmlentities|strip_tags)\s*\(',
    r'(?:DOMPurify\.sanitize|sanitize-html)',
    r'(?:regex|Regex)::(?:new|is_match)',
]


def identify_taint_sources(file_path: str, language: str, source: str) -> list[dict]:
    """Identify taint sources in a source file.

    Returns a list of {line, pattern, category, source_text}.
    """
    patterns = TAINT_SOURCE_PATTERNS.get(language, [])
    if not patterns:
        return []

    sources = []
    lines = source.split('\n')

    for line_num, line_text in enumerate(lines, 1):
        for pattern in patterns:
            match = re.search(pattern, line_text, re.IGNORECASE)
            if match:
                category = _classify_taint_category(pattern)
                sources.append({
                    'line': line_num,
                    'pattern': pattern,
                    'category': category,
                    'source_text': line_text.strip()[:120],
                    'matched_text': match.group(0),
                })
                break  # one match per line is enough

    return sources


def _classify_taint_category(pattern: str) -> str:
    """Classify a taint source pattern into a category."""
    pattern_lower = pattern.lower()
    if any(w in pattern_lower for w in ('request', 'query', 'params', 'body',
                                          'cookies', 'headers', 'form', 'getenv',
                                          'environ', 'argv', 'flag.', '\.args')):
        return 'user_input'
    if any(w in pattern_lower for w in ('fetch', 'http', 'socket', 'net.',
                                          'url', 'reqwest', 'hyper', 'listen',
                                          'accept', 'dial', 'recv')):
        return 'network'
    if any(w in pattern_lower for w in ('open', 'readfile', 'read_to_string',
                                          'file::open', 'files', 'io::')):
        return 'file_io'
    if any(w in pattern_lower for w in ('subprocess', 'command', 'exec',
                                          'eval', 'system', 'popen', 'spawn')):
        return 'command_execution'
    if any(w in pattern_lower for w in ('parse', 'loads', 'unmarshal', 'decode',
                                          'pickle', 'marshal', 'yaml', 'json')):
        return 'deserialization'
    if any(w in pattern_lower for w in ('localstorage', 'sessionstorage',
                                          'document.cookie', 'innerhtml')):
        return 'client_storage'
    return 'other'


def has_sanitizer(signature: str, source_lines: list[str],
                   start_line: int, end_line: int) -> bool:
    """Check if taint is sanitized within the given line range."""
    check_lines = source_lines[max(0, start_line - 1):min(len(source_lines), end_line)]
    for line in check_lines:
        for pattern in SANITIZER_PATTERNS:
            if re.search(pattern, line, re.IGNORECASE):
                return True
    return False


def store_taint_sources(file_id: int, sources: list[dict]) -> None:
    """Store identified taint sources in the database."""
    conn = get_connection()
    try:
        for src in sources:
            conn.execute(
                """INSERT INTO taint_sources
                   (file_id, line_number, category, source_text, matched_text)
                   VALUES (?, ?, ?, ?, ?)""",
                (file_id, src['line'], src['category'],
                 src['source_text'], src['matched_text'])
            )
        conn.commit()
    finally:
        conn.close()


def propagate_taint() -> dict:
    """Propagate taint through the call graph.

    Starting from known taint sources, walk the call graph forward
    to find all downstream symbols that may receive tainted data.

    Returns a summary dict.
    """
    conn = get_connection()
    try:
        # Find symbols at taint source locations
        cur = conn.execute(
            """SELECT DISTINCT s.id, s.name, s.kind, f.file_path, ts.category
               FROM taint_sources ts
               JOIN files f ON ts.file_id = f.id
               JOIN symbols s ON s.file_id = f.id
                 AND ts.line_number BETWEEN s.start_line AND s.end_line""",
        )
        tainted_symbols = list(cur.fetchall())

        if not tainted_symbols:
            return {'tainted_symbols': 0, 'tainted_downstream': 0}

        # Clear previous taint flows
        conn.execute("DELETE FROM taint_flows")

        processed = set()
        downstream = set()
        queue = [(sym_id, 0) for sym_id, _, _, _, _ in tainted_symbols]

        while queue:
            sym_id, depth = queue.pop(0)
            if sym_id in processed or depth > 10:
                continue
            processed.add(sym_id)

            # Store taint flow
            for orig in tainted_symbols:
                conn.execute(
                    """INSERT INTO taint_flows (source_id, target_id, depth)
                       VALUES (?, ?, ?)""",
                    (orig[0], sym_id, depth)
                )

            # Find callers (symbols that call this tainted symbol)
            cur2 = conn.execute(
                """SELECT s2.id FROM symbols s
                   JOIN call_edges ce ON s.name = ce.callee_name
                   JOIN symbols s2 ON ce.caller_id = s2.id
                   WHERE s.id = ? AND s2.id NOT IN (
                       SELECT target_id FROM taint_flows WHERE source_id = ?
                   )
                   LIMIT 50""",
                (sym_id, orig[0])
            )
            for (caller_id,) in cur2.fetchall():
                if caller_id not in processed:
                    queue.append((caller_id, depth + 1))
                    downstream.add(caller_id)

        conn.commit()
        return {
            'tainted_symbols': len(tainted_symbols),
            'tainted_downstream': len(downstream) + len(processed),
        }
    finally:
        conn.close()


def check_trust_boundary_crossings() -> list[dict]:
    """Detect where tainted data crosses security domain boundaries."""
    conn = get_connection()
    try:
        cur = conn.execute(
            """SELECT tf.target_id, s.name, s.kind, f.file_path,
                      d.name AS domain, d.security_boundary
               FROM taint_flows tf
               JOIN symbols s ON tf.target_id = s.id
               JOIN files f ON s.file_id = f.id
               LEFT JOIN file_domains fd ON f.id = fd.file_id
               LEFT JOIN domains d ON fd.domain_id = d.id
               WHERE d.security_boundary = 1
               LIMIT 50"""
        )
        return [
            {
                'symbol': r[1], 'kind': r[2], 'file': r[3],
                'domain': r[4], 'security_boundary': bool(r[5]),
            }
            for r in cur.fetchall()
        ]
    finally:
        conn.close()


def check_privilege_escalation() -> list[dict]:
    """Detect potential privilege escalation paths.

    A privilege escalation occurs when a symbol in a low-privilege domain
    calls into a high-privilege domain without going through an intermediary.
    """
    conn = get_connection()
    try:
        # Define privilege tiers (heuristic)
        high_priv_keywords = ['admin', 'root', 'sudo', 'privilege', 'system',
                               'kernel', 'auth', 'permission', 'role']
        low_priv_keywords = ['user', 'public', 'guest', 'anonymous', 'client',
                              'viewer', 'visitor']

        results = []
        for hp_kw in high_priv_keywords:
            for lp_kw in low_priv_keywords:
                cur = conn.execute(
                    """SELECT s1.name AS caller, s2.name AS callee,
                              f1.file_path AS caller_file, f2.file_path AS callee_file
                       FROM call_edges ce
                       JOIN symbols s1 ON ce.caller_id = s1.id
                       JOIN symbols s2 ON s2.name = ce.callee_name
                       JOIN files f1 ON s1.file_id = f1.id
                       JOIN files f2 ON s2.file_id = f2.id
                       WHERE (s1.name LIKE ? OR f1.file_path LIKE ?)
                         AND (s2.name LIKE ? OR f2.file_path LIKE ?)
                       LIMIT 20""",
                    (f'%{lp_kw}%', f'%{lp_kw}%', f'%{hp_kw}%', f'%{hp_kw}%')
                )
                for r in cur.fetchall():
                    results.append({
                        'caller': r[0], 'callee': r[1],
                        'caller_file': r[2], 'callee_file': r[3],
                        'pattern': f'{lp_kw} -> {hp_kw}',
                    })
        return results[:30]
    finally:
        conn.close()


def trace_secret_access_paths() -> list[dict]:
    """Backward-trace from security_sensitive symbols to find access paths."""
    conn = get_connection()
    try:
        cur = conn.execute(
            """SELECT s.id, s.name, f.file_path
               FROM symbols s JOIN files f ON s.file_id = f.id
               WHERE s.security_sensitive = 1
               LIMIT 20"""
        )
        security_syms = list(cur.fetchall())

        paths = []
        for sym_id, sym_name, file_path in security_syms:
            # Find all callers (who accesses this sensitive symbol)
            cur2 = conn.execute(
                """WITH RECURSIVE access_path AS (
                    SELECT s.id, s.name, f.file_path, 1 AS depth
                    FROM call_edges ce
                    JOIN symbols s ON ce.caller_id = s.id
                    JOIN files f ON s.file_id = f.id
                    WHERE ce.callee_name = ?
                    UNION ALL
                    SELECT s.id, s.name, f.file_path, ap.depth + 1
                    FROM call_edges ce
                    JOIN symbols s ON ce.caller_id = s.id
                    JOIN files f ON s.file_id = f.id
                    JOIN access_path ap ON ce.callee_name = ap.name
                    WHERE ap.depth < 5
                )
                SELECT DISTINCT name, file_path, depth FROM access_path
                ORDER BY depth""",
                (sym_name,)
            )
            callers = [
                {'name': r[0], 'file': r[1], 'depth': r[2]}
                for r in cur2.fetchall()
            ]
            if callers:
                paths.append({
                    'sensitive_symbol': sym_name,
                    'file': file_path,
                    'access_paths': callers,
                })

        return paths
    finally:
        conn.close()


def analyze_security(file_path: str, language: str, source: str) -> dict:
    """Run full security analysis on a file. Called during indexing.

    Returns a dict with taint sources found and any security flags.
    """
    taint_sources = identify_taint_sources(file_path, language, source)

    result = {
        'taint_sources_found': len(taint_sources),
        'taint_categories': list(set(s['category'] for s in taint_sources)),
        'flags': [],
    }

    # Flag dangerous patterns
    for src in taint_sources:
        if src['category'] == 'command_execution':
            result['flags'].append(
                f"Command execution with potential taint at line {src['line']}: "
                f"{src['source_text'][:80]}"
            )
        if src['category'] == 'deserialization':
            result['flags'].append(
                f"Deserialization of untrusted data at line {src['line']}: "
                f"{src['source_text'][:80]}"
            )

    # Check for unsanitized taint reaching sensitive operations
    if taint_sources:
        lines = source.split('\n')
        unsanitized = []
        for src in taint_sources:
            if src['category'] in ('command_execution', 'deserialization'):
                continue  # already flagged above
            # Check if there's a sanitizer on the same line or next line
            line_idx = src['line'] - 1
            check_lines = lines[max(0, line_idx - 2):min(len(lines), line_idx + 2)]
            has_san = any(
                any(re.search(sp, l, re.IGNORECASE) for sp in SANITIZER_PATTERNS)
                for l in check_lines
            )
            if not has_san:
                unsanitized.append(src)

        if unsanitized:
            result['flags'].append(
                f"{len(unsanitized)} taint source(s) without visible sanitization"
            )

    return result


def get_security_summary() -> dict:
    """Return a summary of security provenance data."""
    conn = get_connection()
    try:
        taint_source_count = conn.execute(
            "SELECT COUNT(*) FROM taint_sources"
        ).fetchone()[0]

        taint_flow_count = conn.execute(
            "SELECT COUNT(DISTINCT source_id, target_id) FROM taint_flows"
        ).fetchone()[0]

        boundary_crossings = len(check_trust_boundary_crossings())

        security_sym_count = conn.execute(
            "SELECT COUNT(*) FROM symbols WHERE security_sensitive = 1"
        ).fetchone()[0]

        return {
            'taint_sources': taint_source_count,
            'taint_flows': taint_flow_count,
            'trust_boundary_crossings': boundary_crossings,
            'security_sensitive_symbols': security_sym_count,
        }
    finally:
        conn.close()
