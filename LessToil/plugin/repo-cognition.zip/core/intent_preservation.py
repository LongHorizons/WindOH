"""Intent Preservation — track WHY abstractions exist, not just WHAT they do.

Preserves design intent across refactors so changes don't inadvertently
break the rationale behind existing architecture.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field


@dataclass
class IntentRecord:
    symbol_name: str
    intent_category: str  # 'security', 'performance', 'compatibility', 'abstraction', etc.
    rationale: str = ''
    constraints: list[str] = field(default_factory=list)
    created_by: str = ''


def capture_intent(symbol_name: str, intent_category: str, rationale: str = '',
                   constraints: list[str] | None = None, created_by: str = '') -> int:
    """Store design intent for a symbol. Returns record id."""
    from .manifest import get_connection
    conn = get_connection()
    try:
        cur = conn.execute(
            """INSERT INTO intent_records
               (symbol_name, intent_category, rationale, constraints, created_by)
               VALUES (?, ?, ?, ?, ?)""",
            (symbol_name, intent_category, rationale,
             json.dumps(constraints or []), created_by or 'system')
        )
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


def check_intent_consistency(change: dict) -> dict:
    """Verify a proposed change preserves recorded intents.

    change: {'symbol_name': str, 'new_name': str, 'new_kind': str, ...}
    Returns: {'consistent': bool, 'violations': [...]}
    """
    symbol_name = change.get('symbol_name', '')
    if not symbol_name:
        return {'consistent': True, 'violations': []}

    from .manifest import get_connection
    conn = get_connection()
    try:
        cur = conn.execute(
            "SELECT intent_category, rationale, constraints FROM intent_records WHERE symbol_name = ?",
            (symbol_name,)
        )
        records = cur.fetchall()
        if not records:
            return {'consistent': True, 'violations': []}

        violations = []
        for category, rationale, constraints_json in records:
            constraints = json.loads(constraints_json or '[]')
            for constraint in constraints:
                # Check if the change would violate a stored constraint
                if constraint == 'name_must_not_change' and change.get('new_name') != symbol_name:
                    violations.append({
                        'intent': category,
                        'rationale': rationale,
                        'constraint': constraint,
                        'detail': f"Symbol '{symbol_name}' intent '{category}' forbids renaming",
                    })
                if constraint == 'kind_must_not_change' and change.get('new_kind'):
                    violations.append({
                        'intent': category,
                        'rationale': rationale,
                        'constraint': constraint,
                        'detail': f"Symbol '{symbol_name}' intent '{category}' forbids kind change",
                    })

        return {
            'consistent': len(violations) == 0,
            'violations': violations,
            'intents_found': len(records),
        }
    finally:
        conn.close()


def detect_intent_drift() -> list[dict]:
    """Find symbols that have diverged from their recorded intent."""
    drift_cases = []
    try:
        from .manifest import get_connection
        conn = get_connection()
        try:
            cur = conn.execute(
                """SELECT ir.symbol_name, ir.intent_category, ir.rationale,
                          s.kind, f.file_path
                   FROM intent_records ir
                   LEFT JOIN symbols s ON s.name = ir.symbol_name
                   LEFT JOIN files f ON s.file_id = f.id
                   ORDER BY ir.created_at DESC LIMIT 50"""
            )
            for sym_name, category, rationale, kind, file_path in cur.fetchall():
                if kind is None:
                    drift_cases.append({
                        'symbol': sym_name,
                        'intent': category,
                        'rationale': rationale or '',
                        'issue': 'Symbol no longer exists in index',
                    })
                elif category == 'security' and file_path and 'test' not in file_path.lower():
                    # Security-intent symbols should have tests nearby
                    pass
        finally:
            conn.close()
    except Exception:
        pass
    return drift_cases[:20]


def get_intent_summary() -> dict:
    """Return summary of recorded intents."""
    try:
        from .manifest import get_connection
        conn = get_connection()
        try:
            total = conn.execute("SELECT COUNT(*) FROM intent_records").fetchone()[0]
            categories = {}
            for row in conn.execute(
                "SELECT intent_category, COUNT(*) FROM intent_records GROUP BY intent_category"
            ):
                categories[row[0]] = row[1]
            return {'total_intents': total, 'by_category': categories}
        finally:
            conn.close()
    except Exception:
        return {'total_intents': 0, 'by_category': {}}
