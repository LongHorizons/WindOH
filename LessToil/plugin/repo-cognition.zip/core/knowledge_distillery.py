"""Knowledge distillation layer.

Per-domain: subsystem summaries, canonical patterns (SimHash clusters),
approved primitives (most-called, low-bug), forbidden abstractions
(anti-patterns). Outputs to .claude/repo-cognition.knowledge.local.md.
"""

from __future__ import annotations

import json
import os
import re

from .manifest import get_connection
from . import PROJECT_DIR

KNOWLEDGE_PATH = os.path.join(PROJECT_DIR, '.claude', 'repo-cognition.knowledge.local.md')


def extract_domain_summary(domain_name: str) -> dict:
    """Extract a structured summary for a given architectural domain."""
    conn = get_connection()
    try:
        # Domain metadata
        cur = conn.execute(
            "SELECT description, entry_points, security_boundary FROM domains WHERE name = ?",
            (domain_name,)
        )
        domain_row = cur.fetchone()
        if domain_row is None:
            return {}

        # Files in domain
        cur2 = conn.execute(
            """SELECT f.file_path, f.language, f.line_count, f.file_size,
                      COUNT(s.id) AS symbol_count
               FROM files f
               JOIN file_domains fd ON f.id = fd.file_id
               LEFT JOIN symbols s ON f.id = s.file_id
               WHERE fd.domain_id = (SELECT id FROM domains WHERE name = ?)
               GROUP BY f.id
               ORDER BY f.line_count DESC""",
            (domain_name,)
        )
        files = [
            {'file_path': r[0], 'language': r[1], 'line_count': r[2],
             'file_size': r[3], 'symbol_count': r[4]}
            for r in cur2.fetchall()
        ]

        # Most-called symbols in this domain
        cur3 = conn.execute(
            """SELECT s.name, s.kind, COUNT(ce.caller_id) AS caller_count
               FROM symbols s
               JOIN files f ON s.file_id = f.id
               JOIN file_domains fd ON f.id = fd.file_id
               LEFT JOIN call_edges ce ON s.name = ce.callee_name
               WHERE fd.domain_id = (SELECT id FROM domains WHERE name = ?)
                 AND s.is_exported = 1
               GROUP BY s.id
               ORDER BY caller_count DESC
               LIMIT 10""",
            (domain_name,)
        )
        top_symbols = [
            {'name': r[0], 'kind': r[1], 'callers': r[2]}
            for r in cur3.fetchall()
        ]

        # Entry points to this domain
        cur4 = conn.execute(
            """SELECT s.name, s.kind, f.file_path
               FROM symbols s
               JOIN files f ON s.file_id = f.id
               JOIN file_domains fd ON f.id = fd.file_id
               WHERE fd.domain_id = (SELECT id FROM domains WHERE name = ?)
                 AND s.is_exported = 1
               ORDER BY s.name
               LIMIT 10""",
            (domain_name,)
        )
        entry_points = [
            {'name': r[0], 'kind': r[1], 'file': r[2]}
            for r in cur4.fetchall()
        ]

        # Similar patterns (SimHash clusters)
        cur5 = conn.execute(
            """SELECT simhash, symbol_name, file_path, start_line
               FROM similarity_groups sg
               JOIN files f ON sg.file_path = f.file_path
               JOIN file_domains fd ON f.id = fd.file_id
               WHERE fd.domain_id = (SELECT id FROM domains WHERE name = ?)
               LIMIT 10""",
            (domain_name,)
        )
        patterns = [
            {'simhash': r[0][:8], 'symbol': r[1], 'file': r[2], 'line': r[3]}
            for r in cur5.fetchall()
        ]

        return {
            'domain': domain_name,
            'description': domain_row[0],
            'security_boundary': bool(domain_row[2]),
            'file_count': len(files),
            'files': files[:10],
            'top_symbols': top_symbols,
            'entry_points': entry_points,
            'patterns': patterns,
        }
    finally:
        conn.close()


def extract_approved_primitives() -> list[dict]:
    """Identify approved primitives: most-called, low-bug symbols.

    These are the canonical building blocks the codebase trusts.
    """
    conn = get_connection()
    try:
        cur = conn.execute(
            """SELECT s.name, s.kind, f.file_path,
                      COUNT(ce.caller_id) AS caller_count
               FROM symbols s
               JOIN files f ON s.file_id = f.id
               LEFT JOIN call_edges ce ON s.name = ce.callee_name
               WHERE s.is_exported = 1
               GROUP BY s.id
               HAVING caller_count >= 3
               ORDER BY caller_count DESC
               LIMIT 30"""
        )
        return [
            {'name': r[0], 'kind': r[1], 'file': r[2], 'callers': r[3]}
            for r in cur.fetchall()
        ]
    finally:
        conn.close()


def extract_forbidden_abstractions() -> list[dict]:
    """Identify forbidden abstractions: anti-patterns to avoid."""
    forbidden = []

    conn = get_connection()
    try:
        # God objects
        cur = conn.execute(
            """SELECT f.file_path, f.line_count, f.language, COUNT(s.id) AS sym_count
               FROM files f JOIN symbols s ON f.id = s.file_id
               GROUP BY f.id HAVING f.line_count > 800 OR COUNT(s.id) > 30
               LIMIT 10"""
        )
        for r in cur.fetchall():
            forbidden.append({
                'pattern': 'god_object',
                'file': r[0], 'detail': f"{r[1]} lines, {r[3]} symbols",
            })

        # Heavily duplicated
        cur2 = conn.execute(
            """SELECT file_path, COUNT(*) AS dup_count
               FROM similarity_groups
               GROUP BY file_path
               HAVING COUNT(*) > 5
               LIMIT 10"""
        )
        for r in cur2.fetchall():
            forbidden.append({
                'pattern': 'heavily_duplicated',
                'file': r[0], 'detail': f"{r[1]} similar blocks",
            })

        # High churn
        cur3 = conn.execute(
            """SELECT file_path, total_commits, bug_fix_commits
               FROM temporal_metrics
               WHERE bug_fix_commits > 5
               ORDER BY bug_fix_commits DESC
               LIMIT 10"""
        )
        for r in cur3.fetchall():
            forbidden.append({
                'pattern': 'high_bug_density',
                'file': r[0], 'detail': f"{r[2]} bug-fixes in {r[1]} commits",
            })
    finally:
        conn.close()

    return forbidden


def extract_canonical_patterns() -> list[dict]:
    """Extract canonical patterns from SimHash clusters."""
    conn = get_connection()
    try:
        cur = conn.execute(
            """SELECT sg.simhash, COUNT(*) AS cluster_size,
                      GROUP_CONCAT(DISTINCT sg.symbol_name) AS symbols,
                      GROUP_CONCAT(DISTINCT sg.file_path) AS files
               FROM similarity_groups sg
               GROUP BY SUBSTR(sg.simhash, 1, 4)
               HAVING COUNT(*) >= 2
               ORDER BY COUNT(*) DESC
               LIMIT 10"""
        )
        return [
            {
                'hash_prefix': r[0][:8],
                'cluster_size': r[1],
                'symbols': r[2].split(',')[:5] if r[2] else [],
                'files': r[3].split(',')[:5] if r[3] else [],
            }
            for r in cur.fetchall()
        ]
    finally:
        conn.close()


def generate_knowledge_file() -> str:
    """Generate the knowledge distillation file.

    Returns the path to the written file.
    """
    conn = get_connection()
    try:
        domains = [r[0] for r in conn.execute("SELECT name FROM domains").fetchall()]
    finally:
        conn.close()

    if not domains:
        return ''

    lines = [
        '# Repository Cognition — Distilled Knowledge',
        '',
        'This file is auto-generated by the knowledge distillation layer.',
        'It captures architectural patterns, approved primitives, and',
        'anti-patterns learned from the codebase index.',
        '',
        '---',
        '',
    ]

    # Per-domain summaries
    lines.append('## Domain Summaries')
    lines.append('')
    for domain in domains:
        summary = extract_domain_summary(domain)
        if not summary:
            continue

        lines.append(f'### {domain}')
        lines.append(f'Description: {summary.get("description", "N/A")}')
        lines.append(f'Files: {summary["file_count"]}')
        lines.append(f'Security boundary: {summary.get("security_boundary", False)}')
        lines.append('')

        if summary.get('top_symbols'):
            lines.append('**Key symbols:**')
            for sym in summary['top_symbols'][:5]:
                lines.append(f'  - `{sym["name"]}` ({sym["kind"]}) — {sym["callers"]} callers')
            lines.append('')

        if summary.get('entry_points'):
            lines.append('**Entry points:**')
            for ep in summary['entry_points'][:5]:
                lines.append(f'  - `{ep["name"]}` in {ep["file"]}')
            lines.append('')

    # Approved primitives
    lines.append('## Approved Primitives')
    lines.append('')
    lines.append('Most-called, trusted building blocks:')
    lines.append('')
    primitives = extract_approved_primitives()
    for prim in primitives[:15]:
        lines.append(f'- `{prim["name"]}` ({prim["kind"]}) in {prim["file"]} — {prim["callers"]} callers')
    lines.append('')

    # Canonical patterns
    lines.append('## Canonical Patterns')
    lines.append('')
    patterns = extract_canonical_patterns()
    if patterns:
        for pat in patterns[:5]:
            lines.append(f'- Cluster `{pat["hash_prefix"]}` ({pat["cluster_size"]} occurrences)')
            lines.append(f'  Symbols: {", ".join(pat["symbols"][:3])}')
            lines.append(f'  Files: {", ".join(pat["files"][:3])}')
    else:
        lines.append('*(No structural patterns detected yet. Index more code for SimHash clustering.)*')
    lines.append('')

    # Forbidden abstractions
    lines.append('## Forbidden Abstractions')
    lines.append('')
    forbidden = extract_forbidden_abstractions()
    if forbidden:
        by_pattern = {}
        for item in forbidden:
            pattern = item['pattern']
            if pattern not in by_pattern:
                by_pattern[pattern] = []
            by_pattern[pattern].append(item)

        for pattern, items in by_pattern.items():
            lines.append(f'### {pattern.replace("_", " ").title()}')
            lines.append('')
            for item in items[:5]:
                lines.append(f'- {item["file"]}: {item["detail"]}')
            lines.append('')
    else:
        lines.append('*(No anti-patterns detected.)*')
    lines.append('')

    # Footer
    from datetime import datetime
    lines.append('---')
    lines.append(f'*Generated: {datetime.now().isoformat()}*')

    content = '\n'.join(lines)

    try:
        os.makedirs(os.path.dirname(KNOWLEDGE_PATH), exist_ok=True)
    except OSError:
        pass

    try:
        with open(KNOWLEDGE_PATH, 'w', encoding='utf-8') as f:
            f.write(content)
    except OSError:
        pass

    return KNOWLEDGE_PATH


def get_distilled_knowledge_summary() -> str:
    """Return a brief summary of the distillery output for session context."""
    conn = get_connection()
    try:
        domain_count = conn.execute("SELECT COUNT(*) FROM domains").fetchone()[0]
        sym_count = conn.execute("SELECT COUNT(*) FROM symbols").fetchone()[0]
        pattern_count = conn.execute(
            "SELECT COUNT(DISTINCT SUBSTR(simhash, 1, 4)) FROM similarity_groups"
        ).fetchone()[0]
        prim_count = len(extract_approved_primitives())
        forbidden_count = len(extract_forbidden_abstractions())
    finally:
        conn.close()

    return (
        f"Knowledge distilled: {domain_count} domains, {sym_count} symbols, "
        f"{prim_count} approved primitives, {pattern_count} canonical patterns, "
        f"{forbidden_count} anti-patterns. "
        f"See `.claude/repo-cognition.knowledge.local.md` for details."
    )
