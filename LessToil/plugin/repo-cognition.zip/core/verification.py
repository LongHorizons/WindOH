"""Verification Kernel — 10-phase pipeline for deterministic change validation.

PLAN → SIMULATE → VERIFY → CONSTRAIN → (EXECUTE) → TEST → TRACE → SCORE → REPAIR → REVERIFY

Each phase calls into existing modules. The pipeline short-circuits on the first
blocking phase. Phases after EXECUTE are post-hoc (run after the edit completes).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class VerificationPhase(Enum):
    PLAN = 'plan'
    SIMULATE = 'simulate'
    VERIFY = 'verify'
    CONSTRAIN = 'constrain'
    EXECUTE = 'execute'
    TEST = 'test'
    TRACE = 'trace'
    SCORE = 'score'
    REPAIR = 'repair'
    REVERIFY = 'reverify'


@dataclass
class VerificationResult:
    phase: VerificationPhase
    passed: bool = True
    details: list[str] = field(default_factory=list)
    recommendations: list[str] = field(default_factory=list)
    score: float = 0.0
    evidence: list[dict] = field(default_factory=list)
    block: bool = False


class VerificationPipeline:
    """Orchestrates the 10-phase verification pipeline for a proposed change.

    Short-circuits on the first blocking phase. Post-execute phases
    (TEST, TRACE, SCORE, REPAIR, REVERIFY) are only run when
    post_execute=True.
    """

    def __init__(self, file_paths: list[str], session_id: str = '',
                 old_content: dict[str, str] | None = None,
                 new_content: dict[str, str] | None = None):
        self.file_paths = file_paths
        self.session_id = session_id
        self.old_content = old_content or {}
        self.new_content = new_content or {}
        self.results: list[VerificationResult] = []

    def run(self, post_execute: bool = False) -> dict:
        """Run the verification pipeline.

        Returns a dict with block, results, and aggregated recommendations.
        """
        if not post_execute:
            return self._run_pre_execute()
        else:
            return self._run_post_execute()

    def _run_pre_execute(self) -> dict:
        """Run pre-execute phases: PLAN → SIMULATE → VERIFY → CONSTRAIN."""
        # Phase 1: PLAN — generate execution plan via intent_planner
        plan_result = self._phase_plan()
        self.results.append(plan_result)
        if plan_result.block:
            return self._build_response()

        # Phase 2: SIMULATE — simulate impact via simulation module
        sim_result = self._phase_simulate()
        self.results.append(sim_result)
        if sim_result.block:
            return self._build_response()

        # Phase 3: VERIFY — check invariants and policies via governance
        verify_result = self._phase_verify()
        self.results.append(verify_result)
        if verify_result.block:
            return self._build_response()

        # Phase 4: CONSTRAIN — match against intent constraints
        constrain_result = self._phase_constrain()
        self.results.append(constrain_result)
        if constrain_result.block:
            return self._build_response()

        return self._build_response()

    def _run_post_execute(self) -> dict:
        """Run post-execute phases: TEST → TRACE → SCORE."""
        self._phase_test()
        self._phase_trace()
        self._phase_score()
        return self._build_response()

    # ------------------------------------------------------------------
    # Phase implementations
    # ------------------------------------------------------------------

    def _phase_plan(self) -> VerificationResult:
        result = VerificationResult(phase=VerificationPhase.PLAN, passed=True)
        try:
            from .intent_planner import generate_execution_plan
            plan = generate_execution_plan(
                intent='edit', target_files=self.file_paths
            )
            result.details.append(
                f"Plan: target={plan.target_domain}, "
                f"risk={plan.risk_level}, "
                f"complexity={plan.estimated_complexity}"
            )
            for w in plan.warnings:
                result.recommendations.append(w)
            if plan.risk_level == 'critical':
                result.block = True
                result.passed = False
                result.details.append('Risk level critical — plan blocked')
            result.evidence.append({'plan': {
                'domain': plan.target_domain,
                'risk': plan.risk_level,
                'constraints': len(plan.constraints.applicable_invariants),
            }})
        except Exception as e:
            result.details.append(f'Plan phase skipped: {e}')
        return result

    def _phase_simulate(self) -> VerificationResult:
        result = VerificationResult(phase=VerificationPhase.SIMULATE, passed=True)
        if len(self.file_paths) <= 1:
            result.details.append('Single file change — simulation skipped')
            return result
        try:
            from .simulation import simulate_change, should_block
            sim = simulate_change(self.file_paths)
            grade = sim.get('grade', 'safe')
            result.details.append(
                f"Simulation grade: {grade} — {sim.get('reason', '')}"
            )
            result.evidence.append({'simulation': sim})
            if should_block(grade):
                result.block = True
                result.passed = False
            for rec in sim.get('recommendations', []):
                result.recommendations.append(rec)
        except Exception as e:
            result.details.append(f'Simulation phase skipped: {e}')
        return result

    def _phase_verify(self) -> VerificationResult:
        result = VerificationResult(phase=VerificationPhase.VERIFY, passed=True)
        try:
            from .governance import check_governance
            gov = check_governance(self.file_paths, self.session_id)
            result.evidence.append({'governance': gov})
            if gov.get('block'):
                result.block = True
                result.passed = False
                for err in gov.get('errors', []):
                    result.details.append(err)
            for warn in gov.get('warnings', []):
                result.recommendations.append(warn)
        except Exception as e:
            result.details.append(f'Verify phase skipped: {e}')
        return result

    def _phase_constrain(self) -> VerificationResult:
        result = VerificationResult(phase=VerificationPhase.CONSTRAIN, passed=True)
        try:
            from .intent_planner import generate_execution_plan
            plan = generate_execution_plan(
                intent='edit', target_files=self.file_paths
            )
            constraint_count = len(plan.constraints.applicable_invariants)
            result.details.append(
                f"Constraints applied: {constraint_count} invariants, "
                f"{len(plan.constraints.applicable_policies)} policies"
            )
            if plan.constraints.requires_tests:
                result.recommendations.append('Tests required for security boundaries')
        except Exception as e:
            result.details.append(f'Constrain phase skipped: {e}')
        return result

    def _phase_test(self) -> None:
        """Post-execute: detect test coverage gaps."""
        result = VerificationResult(phase=VerificationPhase.TEST, passed=True)
        try:
            from .manifest import get_connection
            conn = get_connection()
            try:
                placeholders = ','.join('?' for _ in self.file_paths)
                cur = conn.execute(
                    f"""SELECT s.name FROM symbols s
                       JOIN files f ON s.file_id = f.id
                       WHERE f.file_path IN ({placeholders})
                         AND s.security_sensitive = 1""",
                    self.file_paths
                )
                sec_syms = [r[0] for r in cur.fetchall()]
                if sec_syms:
                    result.details.append(
                        f"{len(sec_syms)} security-sensitive symbols changed"
                    )
                    result.recommendations.append(
                        'Verify test coverage for security-sensitive symbols'
                    )
            finally:
                conn.close()
        except Exception:
            pass
        self.results.append(result)

    def _phase_trace(self) -> None:
        """Post-execute: trace call graph impact breadth."""
        result = VerificationResult(phase=VerificationPhase.TRACE, passed=True)
        try:
            from .manifest import get_connection
            conn = get_connection()
            try:
                placeholders = ','.join('?' for _ in self.file_paths)
                cur = conn.execute(
                    f"""SELECT COUNT(DISTINCT f2.file_path)
                       FROM call_edges ce
                       JOIN symbols s ON s.name = ce.callee_name
                       JOIN files f ON s.file_id = f.id
                       JOIN symbols s2 ON ce.caller_id = s2.id
                       JOIN files f2 ON s2.file_id = f2.id
                       WHERE f.file_path IN ({placeholders})""",
                    self.file_paths
                )
                row = cur.fetchone()
                if row and row[0]:
                    result.details.append(
                        f"Change impacts callers across {row[0]} files"
                    )
                    result.evidence.append({'impact_breadth': row[0]})
            finally:
                conn.close()
        except Exception:
            pass
        self.results.append(result)

    def _phase_score(self) -> None:
        """Post-execute: compute aggregate quality score."""
        result = VerificationResult(phase=VerificationPhase.SCORE, passed=True)
        try:
            scores = []
            # Confidence
            try:
                from .confidence import get_confidence_summary
                conf = get_confidence_summary()
                scores.append(conf.get('avg_aggregate', 0.5))
            except Exception:
                scores.append(0.5)

            # Drift
            try:
                from .drift_detection import compute_file_drift
                drifts = []
                for fp in self.file_paths[:5]:
                    drifts.append(compute_file_drift(fp).drift_score)
                if drifts:
                    scores.append(1.0 - sum(drifts) / len(drifts))
            except Exception:
                pass

            # Minimalism
            try:
                from .minimalism import compute_simplicity_score
                for fp in self.file_paths[:3]:
                    scores.append(compute_simplicity_score(fp))
            except Exception:
                pass

            result.score = round(sum(scores) / len(scores), 3) if scores else 0.5
            result.evidence.append({'composite_score': result.score})
            if result.score < 0.4:
                result.passed = False
                result.details.append(f'Post-execute score degraded: {result.score}')
        except Exception:
            pass
        self.results.append(result)

    def _build_response(self) -> dict:
        """Build the final response dict from accumulated results."""
        block = any(r.block for r in self.results)
        all_details = []
        all_recommendations = []
        for r in self.results:
            all_details.extend(r.details)
            all_recommendations.extend(r.recommendations)

        return {
            'block': block,
            'phase_results': [
                {
                    'phase': r.phase.value,
                    'passed': r.passed,
                    'score': r.score,
                    'block': r.block,
                }
                for r in self.results
            ],
            'details': all_details,
            'recommendations': all_recommendations,
            'evidence': [e for r in self.results for e in r.evidence],
        }


def verify_change(file_paths: list[str], session_id: str = '',
                  old_content: dict[str, str] | None = None,
                  new_content: dict[str, str] | None = None,
                  post_execute: bool = False) -> dict:
    """Entry point: verify a proposed or completed change.

    Returns a dict with 'block' (bool) and supporting details.
    PreToolUse calls this with post_execute=False.
    PostToolUse calls this with post_execute=True (TEST + TRACE + SCORE only).
    """
    pipeline = VerificationPipeline(
        file_paths=file_paths,
        session_id=session_id,
        old_content=old_content,
        new_content=new_content,
    )
    return pipeline.run(post_execute=post_execute)


def get_verification_summary(file_paths: list[str]) -> dict:
    """Quick summary suitable for hook context injection."""
    result = verify_change(file_paths, post_execute=False)
    return {
        'block': result['block'],
        'phases': len(result['phase_results']),
        'recommendations': result['recommendations'][:5],
    }
