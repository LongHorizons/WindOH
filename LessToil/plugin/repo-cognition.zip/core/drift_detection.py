"""Architectural drift detection.

Detects naming divergence, framework creep, style drift, and anti-pattern
emergence. Computes a drift score per file (0.0 = conformant, 1.0 = drift).

Anti-patterns detected:
- Utility module creep (too many util/helper files)
- God objects (files/symbols with excessive responsibilities)
- Feature envy (excessive cross-module calls)
- Callback hell (deeply nested callbacks/indirection)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from .manifest import get_connection
from . import PROJECT_DIR

# Drift thresholds
UTIL_FILE_RATIO_THRESHOLD = 0.15       # >15% files are util/helper = creep
GOD_OBJECT_LINE_THRESHOLD = 800        # file length suggesting god object
GOD_OBJECT_SYMBOL_THRESHOLD = 30       # symbol count suggesting god object
NAMING_DIVERGENCE_THRESHOLD = 0.3      # proportion of files with different styles
CALLBACK_NESTING_THRESHOLD = 5         # max nesting depth before flagging


@dataclass
class DriftReport:
    file_path: str
    drift_score: float = 0.0
    naming_drift: float = 0.0
    style_drift: float = 0.0
    anti_pattern_score: float = 0.0
    framework_creep: float = 0.0
    flags: list[str] = None

    def __post_init__(self):
        if self.flags is None:
            self.flags = []


# ---------------------------------------------------------------------------
# Naming convention drift detection
# ---------------------------------------------------------------------------

def _detect_naming_convention(names: list[str], language: str) -> dict:
    """Detect the dominant naming convention in a list of symbol names."""
    snake_case = 0
    camelCase = 0
    PascalCase = 0
    kebab_case = 0
    SCREAMING_SNAKE = 0

    for name in names:
        if not name or len(name) < 2:
            continue
        if '_' in name and name == name.upper():
            SCREAMING_SNAKE += 1
        elif '_' in name:
            snake_case += 1
        elif '-' in name:
            kebab_case += 1
        elif name[0].isupper():
            PascalCase += 1
        elif name[0].islower():
            camelCase += 1

    total = snake_case + camelCase + PascalCase + kebab_case + SCREAMING_SNAKE
    if total == 0:
        return {'dominant': 'unknown', 'conformity': 0.0}

    counts = {
        'snake_case': snake_case / total,
        'camelCase': camelCase / total,
        'PascalCase': PascalCase / total,
        'kebab-case': kebab_case / total,
        'SCREAMING_SNAKE': SCREAMING_SNAKE / total,
    }
    dominant = max(counts, key=counts.get)
    return {'dominant': dominant, 'conformity': counts[dominant]}


def detect_naming_drift() -> list[dict]:
    """Detect naming convention inconsistency across the codebase.

    Returns files that deviate from the dominant naming convention.
    """
    conn = get_connection()
    try:
        # Get all symbol names grouped by file
        cur = conn.execute(
            """SELECT f.file_path, f.language, s.name
               FROM symbols s JOIN files f ON s.file_id = f.id
               ORDER BY f.file_path LIMIT 5000"""
        )
        file_names: dict[str, dict] = {}
        for file_path, language, name in cur.fetchall():
            if file_path not in file_names:
                file_names[file_path] = {'language': language, 'names': []}
            file_names[file_path]['names'].append(name)

        if not file_names:
            return []

        # Find global dominant convention per language
        lang_conventions: dict[str, str] = {}
        for lang in set(f['language'] for f in file_names.values()):
            all_names = []
            for f_info in file_names.values():
                if f_info['language'] == lang:
                    all_names.extend(f_info['names'])
            if all_names:
                result = _detect_naming_convention(all_names, lang)
                lang_conventions[lang] = result['dominant']

        # Find files that deviate
        drifters = []
        for file_path, f_info in file_names.items():
            lang = f_info['language']
            dominant = lang_conventions.get(lang)
            if not dominant or dominant == 'unknown':
                continue

            result = _detect_naming_convention(f_info['names'], lang)
            if result['dominant'] != dominant and result['conformity'] < 0.5:
                drifters.append({
                    'file_path': file_path,
                    'language': lang,
                    'dominant_convention': dominant,
                    'file_convention': result['dominant'],
                    'conformity': round(result['conformity'], 2),
                })

        return drifters[:20]
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Style drift detection
# ---------------------------------------------------------------------------

def detect_style_drift() -> list[dict]:
    """Detect style inconsistencies: indentation, file length outliers, comment density."""
    conn = get_connection()
    try:
        # Get line counts and find statistical outliers
        cur = conn.execute(
            "SELECT file_path, language, line_count FROM files WHERE line_count > 0"
        )
        files = list(cur.fetchall())

        if len(files) < 5:
            return []

        line_counts = [f[2] for f in files]
        avg_lines = sum(line_counts) / len(line_counts)
        std_lines = (
            sum((lc - avg_lines) ** 2 for lc in line_counts) / len(line_counts)
        ) ** 0.5

        outliers = []
        for file_path, language, line_count in files:
            if std_lines > 0 and line_count > avg_lines + 3 * std_lines:
                outliers.append({
                    'file_path': file_path,
                    'language': language,
                    'line_count': line_count,
                    'average': int(avg_lines),
                    'z_score': round((line_count - avg_lines) / std_lines, 2),
                    'issue': 'file_size_outlier',
                })

        return outliers[:15]
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Anti-pattern detection
# ---------------------------------------------------------------------------

def detect_utility_creep() -> list[dict]:
    """Detect excessive utility/helper module proliferation."""
    conn = get_connection()
    try:
        total_files = conn.execute("SELECT COUNT(*) FROM files").fetchone()[0]
        if total_files == 0:
            return []

        cur = conn.execute(
            """SELECT file_path, language FROM files
               WHERE file_path LIKE '%util%' OR file_path LIKE '%helper%'
                  OR file_path LIKE '%common%' OR file_path LIKE '%misc%'"""
        )
        util_files = list(cur.fetchall())

        ratio = len(util_files) / total_files
        if ratio > UTIL_FILE_RATIO_THRESHOLD:
            return [{
                'pattern': 'utility_creep',
                'util_file_count': len(util_files),
                'total_files': total_files,
                'ratio': round(ratio, 2),
                'threshold': UTIL_FILE_RATIO_THRESHOLD,
                'sample_files': [f[0] for f in util_files[:5]],
            }]
        return []
    finally:
        conn.close()


def detect_god_objects() -> list[dict]:
    """Detect god objects: files with excessive symbols or line count."""
    conn = get_connection()
    try:
        cur = conn.execute(
            """SELECT f.file_path, f.line_count, f.language,
                      COUNT(s.id) AS symbol_count
               FROM files f
               JOIN symbols s ON f.id = s.file_id
               GROUP BY f.id
               HAVING f.line_count > ? OR COUNT(s.id) > ?
               ORDER BY f.line_count DESC
               LIMIT 10""",
            (GOD_OBJECT_LINE_THRESHOLD, GOD_OBJECT_SYMBOL_THRESHOLD)
        )
        return [
            {
                'file_path': r[0], 'line_count': r[1], 'language': r[2],
                'symbol_count': r[3], 'pattern': 'god_object',
            }
            for r in cur.fetchall()
        ]
    finally:
        conn.close()


def detect_feature_envy() -> list[dict]:
    """Detect feature envy: excessive cross-module calls from a single symbol."""
    conn = get_connection()
    try:
        cur = conn.execute(
            """SELECT s.name, s.kind, f.file_path,
                      COUNT(DISTINCT ce.callee_name) AS external_calls,
                      GROUP_CONCAT(DISTINCT ce.callee_file) AS target_files
               FROM call_edges ce
               JOIN symbols s ON ce.caller_id = s.id
               JOIN files f ON s.file_id = f.id
               WHERE ce.callee_file IS NOT NULL AND ce.callee_file != f.file_path
               GROUP BY s.id
               HAVING COUNT(DISTINCT ce.callee_name) > 10
               ORDER BY COUNT(DISTINCT ce.callee_name) DESC
               LIMIT 10"""
        )
        return [
            {
                'symbol': r[0], 'kind': r[1], 'file': r[2],
                'external_calls': r[3], 'pattern': 'feature_envy',
            }
            for r in cur.fetchall()
        ]
    finally:
        conn.close()


def detect_callback_hell() -> list[dict]:
    """Detect callback hell: deeply nested call chains suggesting complex async code."""
    conn = get_connection()
    try:
        cur = conn.execute(
            """WITH RECURSIVE depth_check AS (
                SELECT ce.callee_name, 1 AS depth
                FROM call_edges ce
                UNION ALL
                SELECT ce2.callee_name, dc.depth + 1
                FROM call_edges ce2
                JOIN symbols s ON ce2.caller_id = s.id
                JOIN depth_check dc ON s.name = dc.callee_name
                WHERE dc.depth < 10
            )
            SELECT callee_name, MAX(depth) AS max_depth
            FROM depth_check
            GROUP BY callee_name
            HAVING MAX(depth) > ?
            ORDER BY MAX(depth) DESC
            LIMIT 10""",
            (CALLBACK_NESTING_THRESHOLD,)
        )
        return [
            {'symbol': r[0], 'max_depth': r[1], 'pattern': 'callback_hell'}
            for r in cur.fetchall()
        ]
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Framework creep detection
# ---------------------------------------------------------------------------

def detect_framework_creep() -> list[dict]:
    """Detect when too many frameworks/libraries are imported across the codebase."""
    conn = get_connection()
    try:
        cur = conn.execute(
            """SELECT s.name AS import_name, COUNT(DISTINCT f.id) AS file_count,
                      GROUP_CONCAT(DISTINCT f.file_path) AS sample_files
               FROM symbols s
               JOIN files f ON s.file_id = f.id
               WHERE s.kind = 'import' OR s.name LIKE 'import%'
               GROUP BY s.name
               HAVING COUNT(DISTINCT f.id) > 10
               ORDER BY COUNT(DISTINCT f.id) DESC
               LIMIT 15"""
        )
        return [
            {
                'import_name': r[0], 'file_count': r[1],
                'pattern': 'framework_creep',
            }
            for r in cur.fetchall()
        ]
    except Exception:
        return []


# ---------------------------------------------------------------------------
# Composite drift scoring
# ---------------------------------------------------------------------------

def compute_file_drift(file_path: str) -> DriftReport:
    """Compute the architectural drift score for a single file."""
    report = DriftReport(file_path=file_path)
    conn = get_connection()
    try:
        # Get file info
        cur = conn.execute(
            "SELECT line_count, language FROM files WHERE file_path = ?",
            (file_path,)
        )
        row = cur.fetchone()
        if row is None:
            return report
        line_count, language = row

        # 1. Naming drift: does this file use non-dominant convention?
        cur2 = conn.execute(
            "SELECT name FROM symbols s JOIN files f ON s.file_id = f.id "
            "WHERE f.file_path = ?",
            (file_path,)
        )
        names = [r[0] for r in cur2.fetchall()]
        if names:
            conv = _detect_naming_convention(names, language)
            report.naming_drift = 1.0 - conv['conformity']

        # 2. Style drift: file size outlier
        cur3 = conn.execute("SELECT AVG(line_count) FROM files").fetchone()[0]
        if cur3 and cur3 > 0 and line_count > cur3 * 3:
            report.style_drift = min(1.0, (line_count / (cur3 * 3) - 1.0))

        # 3. Anti-pattern score
        # God object check
        cur4 = conn.execute(
            "SELECT COUNT(*) FROM symbols WHERE file_id = "
            "(SELECT id FROM files WHERE file_path = ?)",
            (file_path,)
        )
        sym_count = cur4.fetchone()[0]
        if line_count > GOD_OBJECT_LINE_THRESHOLD or sym_count > GOD_OBJECT_SYMBOL_THRESHOLD:
            report.anti_pattern_score += 0.3
            report.flags.append('god_object_suspect')

        # Utility creep check
        path_lower = file_path.lower()
        if any(w in path_lower for w in ('util', 'helper', 'common', 'misc')):
            report.anti_pattern_score += 0.15
            report.flags.append('utility_creep_contributor')

        # Feature envy check
        cur5 = conn.execute(
            """SELECT COUNT(DISTINCT ce.callee_file)
               FROM call_edges ce
               JOIN symbols s ON ce.caller_id = s.id
               JOIN files f ON s.file_id = f.id
               WHERE f.file_path = ? AND ce.callee_file IS NOT NULL
                 AND ce.callee_file != f.file_path""",
            (file_path,)
        )
        external_modules = cur5.fetchone()[0]
        if external_modules > 5:
            report.anti_pattern_score += min(0.4, external_modules / 50.0)
            report.flags.append('feature_envy_suspect')

        # 4. Framework creep: count unique imports
        cur6 = conn.execute(
            """SELECT COUNT(*) FROM call_edges ce
               JOIN symbols s ON ce.caller_id = s.id
               JOIN files f ON s.file_id = f.id
               WHERE f.file_path = ?""",
            (file_path,)
        )
        call_count = cur6.fetchone()[0]
        if call_count > 30:
            report.framework_creep = min(0.3, call_count / 200.0)

    finally:
        conn.close()

    # Composite drift score
    report.drift_score = round(
        0.30 * report.naming_drift +
        0.20 * report.style_drift +
        0.35 * report.anti_pattern_score +
        0.15 * report.framework_creep,
        4
    )

    return report


def compute_domain_drift_scores() -> dict[str, float]:
    """Compute average drift scores per architectural domain."""
    conn = get_connection()
    try:
        cur = conn.execute(
            """SELECT d.name, f.file_path
               FROM domains d
               JOIN file_domains fd ON d.id = fd.domain_id
               JOIN files f ON fd.file_id = f.id"""
        )
        domain_files: dict[str, list[str]] = {}
        for domain_name, file_path in cur.fetchall():
            if domain_name not in domain_files:
                domain_files[domain_name] = []
            domain_files[domain_name].append(file_path)

        scores = {}
        for domain_name, files in domain_files.items():
            domain_scores = []
            for fp in files[:20]:  # limit per domain
                score = compute_file_drift(fp).drift_score
                domain_scores.append(score)
            scores[domain_name] = round(
                sum(domain_scores) / len(domain_scores), 4
            ) if domain_scores else 0.0

        return scores
    finally:
        conn.close()


def persist_file_drift_scores(limit: int = 100) -> dict:
    """Compute drift scores for files and persist to files.architectural_drift_score.

    Call from SessionStart after temporal compute. Limits to `limit` files
    for performance; processes the largest files first.
    """
    conn = get_connection()
    try:
        cur = conn.execute(
            "SELECT file_path FROM files ORDER BY line_count DESC LIMIT ?",
            (limit,)
        )
        files = [r[0] for r in cur.fetchall()]

        updated = 0
        high_drift = 0
        for fp in files:
            drift = compute_file_drift(fp).drift_score
            conn.execute(
                "UPDATE files SET architectural_drift_score = ? WHERE file_path = ?",
                (drift, fp)
            )
            updated += 1
            if drift > 0.5:
                high_drift += 1

        conn.commit()
        return {
            'files_processed': updated,
            'high_drift_files': high_drift,
            'average_drift': round(
                sum(compute_file_drift(fp).drift_score for fp in files) / len(files), 4
            ) if files else 0.0,
        }
    finally:
        conn.close()


def get_drift_summary() -> dict:
    """Return a summary of architectural drift across the codebase."""
    conn = get_connection()
    try:
        cur = conn.execute("SELECT file_path FROM files LIMIT 100")
        files = [r[0] for r in cur.fetchall()]

        if not files:
            return {'files_analyzed': 0, 'average_drift': 0.0}

        total_drift = 0.0
        high_drift = 0
        for fp in files:
            drift = compute_file_drift(fp).drift_score
            total_drift += drift
            if drift > 0.5:
                high_drift += 1

        # Detect anti-patterns
        god_objects = detect_god_objects()
        utility_creep = detect_utility_creep()
        feature_envy = detect_feature_envy()
        naming_drifters = detect_naming_drift()

        return {
            'files_analyzed': len(files),
            'average_drift': round(total_drift / len(files), 4),
            'high_drift_files': high_drift,
            'god_objects': len(god_objects),
            'utility_creep': len(utility_creep) > 0,
            'feature_envy_cases': len(feature_envy),
            'naming_drifters': len(naming_drifters),
        }
    finally:
        conn.close()
