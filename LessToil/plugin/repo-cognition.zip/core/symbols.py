"""Tree-sitter based symbol extraction for 45+ languages.

Extracts functions, classes, methods, imports, exports, and call expressions
from source files. Falls back to regex-based extraction when tree-sitter
grammars are not available or fail.

Robustness guarantees:
- Grammars are imported lazily per-language (one missing grammar doesn't
  disable all others)
- Files >1MB skip tree-sitter and go straight to regex
- Specific exception types are caught individually; unrecoverable errors
  (MemoryError, KeyboardInterrupt) propagate
- Multiple tree-sitter API version patterns are attempted for language
  object resolution
- Version mismatch between tree-sitter core and grammar packages handled
  via path-based library loading fallback
"""

from __future__ import annotations

import os
import re
import sys
from typing import Any

# Try importing tree-sitter core; gracefully degrade if unavailable
try:
    import tree_sitter
    HAS_TREE_SITTER = True
except ImportError:
    HAS_TREE_SITTER = False
    tree_sitter = None  # type: ignore

# Max file size for tree-sitter parsing (1 MB). Above this, regex only.
MAX_TREE_SITTER_BYTES = 1_000_000

# Which tree-sitter grammars are actually installed (populated lazily)
_GRAMMAR_CACHE: dict[str, Any] = {}
_GRAMMAR_CHECKED: set[str] = set()


# ===========================================================================
# Grammar import map — package name(s) per language
# ===========================================================================

_GRAMMAR_IMPORT_MAP = {
    'python':      ('tree_sitter_python',),
    'typescript':  ('tree_sitter_typescript',),
    'javascript':  ('tree_sitter_typescript',),
    'go':          ('tree_sitter_go',),
    'rust':        ('tree_sitter_rust',),
    'java':        ('tree_sitter_java',),
    'c':           ('tree_sitter_c',),
    'cpp':         ('tree_sitter_cpp',),
    'csharp':      ('tree_sitter_c_sharp',),
    'ruby':        ('tree_sitter_ruby',),
    'php':         ('tree_sitter_php',),
    'swift':       ('tree_sitter_swift',),
    'scala':       ('tree_sitter_scala',),
    'kotlin':      ('tree_sitter_kotlin',),
    'lua':         ('tree_sitter_lua',),
    'sql':         ('tree_sitter_sql',),
    'shell':       ('tree_sitter_bash',),
    'bash':        ('tree_sitter_bash',),
    'html':        ('tree_sitter_html',),
    'css':         ('tree_sitter_css',),
    'scss':        ('tree_sitter_css',),
    'less':        ('tree_sitter_css',),
    'json':        ('tree_sitter_json',),
    'yaml':        ('tree_sitter_yaml',),
    'toml':        ('tree_sitter_toml',),
    'markdown':    ('tree_sitter_markdown',),
    'dockerfile':  ('tree_sitter_dockerfile',),
    'terraform':   ('tree_sitter_hcl',),
    'hcl':         ('tree_sitter_hcl',),
    'graphql':     ('tree_sitter_graphql',),
    'haskell':     ('tree_sitter_haskell',),
    'ocaml':       ('tree_sitter_ocaml',),
    'elixir':      ('tree_sitter_elixir',),
    'dart':        ('tree_sitter_dart',),
    'zig':         ('tree_sitter_zig',),
    'solidity':    ('tree_sitter_solidity',),
    'svelte':      ('tree_sitter_svelte',),
    'makefile':    ('tree_sitter_make',),
    'cmake':       ('tree_sitter_cmake',),
    'powershell':  ('tree_sitter_powershell',),
    'nix':         ('tree_sitter_nix',),
}

# Regex-only languages (no tree-sitter grammar on PyPI, or grammar not yet available)
_REGEX_ONLY_LANGS = {
    'ini', 'env', 'xml', 'vue', 'astro', 'prisma', 'move', 'nim',
    'elm', 'erlang', 'clojure', 'r', 'bazel', 'just', 'protobuf',
}


# ===========================================================================
# Tree-sitter SCM queries per language
# ===========================================================================

_PYTHON_QUERY = """
(function_definition
  name: (identifier) @function.name
  parameters: (parameters) @function.params
  body: (block) @function.body
) @function.def

(class_definition
  name: (identifier) @class.name
  body: (block) @class.body
) @class.def

(import_statement
  name: (dotted_name) @import.module
) @import.stmt

(import_from_statement
  module_name: (dotted_name) @import.module
  name: (dotted_name) @import.name
) @import.from

(call
  function: (identifier) @call.name
) @call.expr

(call
  function: (attribute
    object: (_) @call.object
    attribute: (identifier) @call.method)
) @call.method
"""

_TYPESCRIPT_QUERY = """
(function_declaration
  name: (identifier) @function.name
) @function.def

(method_definition
  name: (property_identifier) @function.name
) @function.def

(arrow_function) @function.arrow

(class_declaration
  name: (type_identifier) @class.name
) @class.def

(export_statement) @export.stmt

(import_statement
  source: (string) @import.source
) @import.stmt

(call_expression
  function: (identifier) @call.name
) @call.expr

(call_expression
  function: (member_expression
    property: (property_identifier) @call.method)
) @call.method
"""

_JAVASCRIPT_QUERY = _TYPESCRIPT_QUERY

_GO_QUERY = """
(function_declaration
  name: (identifier) @function.name
  parameters: (parameter_list) @function.params
  body: (block) @function.body
) @function.def

(method_declaration
  name: (field_identifier) @function.name
  parameters: (parameter_list) @function.params
  body: (block) @function.body
) @function.def

(type_declaration
  name: (type_identifier) @class.name
  body: (type_spec) @class.body
) @class.def

(import_declaration
  path: (interpreted_string_literal) @import.path
) @import.stmt

(call_expression
  function: (identifier) @call.name
) @call.expr

(call_expression
  function: (selector_expression
    field: (field_identifier) @call.method)
) @call.method
"""

_RUST_QUERY = """
(function_item
  name: (identifier) @function.name
  parameters: (parameters) @function.params
  body: (block) @function.body
) @function.def

(struct_item
  name: (type_identifier) @class.name
) @class.def

(impl_item
  type: (type_identifier) @class.impl_name
  body: (declaration_list) @class.body
) @class.impl

(use_declaration
  path: (use_tree) @import.path
) @import.stmt

(call_expression
  function: (identifier) @call.name
) @call.expr

(call_expression
  function: (field_expression
    field: (field_identifier) @call.method)
) @call.method
"""

_JAVA_QUERY = """
(method_declaration
  name: (identifier) @function.name
) @function.def

(class_declaration
  name: (identifier) @class.name
) @class.def

(interface_declaration
  name: (identifier) @class.name
) @class.def

(import_declaration) @import.stmt

(method_invocation
  name: (identifier) @call.name
) @call.expr

(method_invocation
  object: (_) @call.object
  name: (identifier) @call.method
) @call.method
"""

_C_QUERY = """
(function_definition
  declarator: (function_declarator
    declarator: (identifier) @function.name)
) @function.def

(struct_specifier
  name: (type_identifier) @class.name
) @class.def

(preproc_include
  path: (string_literal) @import.path
) @import.stmt

(call_expression
  function: (identifier) @call.name
) @call.expr
"""

_CPP_QUERY = """
(function_definition
  declarator: (function_declarator
    declarator: (identifier) @function.name)
) @function.def

(class_specifier
  name: (type_identifier) @class.name
) @class.def

(preproc_include
  path: (string_literal) @import.path
) @import.stmt

(call_expression
  function: (identifier) @call.name
) @call.expr

(call_expression
  function: (field_expression
    field: (field_identifier) @call.method)
) @call.method
"""

_CSHARP_QUERY = """
(method_declaration
  name: (identifier) @function.name
) @function.def

(class_declaration
  name: (identifier) @class.name
) @class.def

(interface_declaration
  name: (identifier) @class.name
) @class.def

(using_directive) @import.stmt

(invocation_expression
  function: (identifier) @call.name
) @call.expr

(invocation_expression
  function: (member_access_expression
    name: (identifier) @call.method)
) @call.method
"""

_RUBY_QUERY = """
(method
  name: (identifier) @function.name
) @function.def

(class
  name: (constant) @class.name
) @class.def

(module
  name: (constant) @class.name
) @class.def

(call
  method: (identifier) @call.name
) @call.expr
"""

_PHP_QUERY = """
(function_definition
  name: (name) @function.name
) @function.def

(method_declaration
  name: (name) @function.name
) @function.def

(class_declaration
  name: (name) @class.name
) @class.def

(interface_declaration
  name: (name) @class.name
) @class.def

(use_declaration) @import.stmt

(function_call_expression
  function: (name) @call.name
) @call.expr

(member_call_expression
  name: (name) @call.method
) @call.method
"""

_SWIFT_QUERY = """
(function_declaration
  name: (simple_identifier) @function.name
) @function.def

(class_declaration
  name: (type_identifier) @class.name
) @class.def

(struct_declaration
  name: (type_identifier) @class.name
) @class.def

(protocol_declaration
  name: (type_identifier) @class.name
) @class.def

(import_declaration) @import.stmt

(call_expression
  function: (simple_identifier) @call.name
) @call.expr

(call_expression
  function: (navigation_expression
    target: (_) @call.object
    name: (simple_identifier) @call.method)
) @call.method
"""

_SCALA_QUERY = """
(function_declaration
  name: (identifier) @function.name
) @function.def

(class_declaration
  name: (identifier) @class.name
) @class.def

(object_definition
  name: (identifier) @class.name
) @class.def

(trait_declaration
  name: (identifier) @class.name
) @class.def

(import_declaration) @import.stmt

(call_expression
  function: (identifier) @call.name
) @call.expr
"""

_KOTLIN_QUERY = """
(function_declaration
  name: (simple_identifier) @function.name
) @function.def

(class_declaration
  name: (simple_identifier) @class.name
) @class.def

(import_header) @import.stmt

(call_expression
  simple_identifier: (simple_identifier) @call.name
) @call.expr

(call_expression
  navigation_expression: (navigation_expression
    name: (simple_identifier) @call.method)
) @call.method
"""

_LUA_QUERY = """
(function_declaration
  name: (identifier) @function.name
) @function.def

(variable_declaration
  (assignment_statement
    variable: (identifier) @function.name
    value: (function_definition))
) @function.def

(function_call
  function: (identifier) @call.name
) @call.expr
"""

_SQL_QUERY = """
(create_table_statement
  name: (object_reference) @class.name
) @class.def

(create_view_statement
  name: (object_reference) @class.name
) @class.def

(create_function_statement
  name: (object_reference) @function.name
) @function.def

(create_procedure_statement
  name: (object_reference) @function.name
) @function.def
"""

_BASH_QUERY = """
(function_definition
  name: (word) @function.name
) @function.def

(command
  name: (word) @call.name
) @call.expr
"""

_HTML_QUERY = """
(element
  start_tag: (start_tag
    name: (tag_name) @class.name)
) @class.def
"""

_CSS_QUERY = """
(rule_set
  selectors: (selectors) @class.name
) @class.def

(at_rule
  name: (at_keyword) @class.name
) @class.def
"""

_JSON_QUERY = """
(pair
  key: (string) @class.name
) @class.def
"""

_YAML_QUERY = """
(block_mapping_pair
  key: (flow_node) @class.name
) @class.def
"""

_TOML_QUERY = """
(table
  key: (bare_key) @class.name
) @class.def

(table_array_element
  key: (bare_key) @class.name
) @class.def

(pair
  key: (bare_key) @class.name
) @class.def
"""

_MARKDOWN_QUERY = """
(atx_heading
  heading_content: (inline) @class.name
) @class.def
"""

_DOCKERFILE_QUERY = """
(from_instruction
  image: (image_name) @import.module
) @import.stmt
"""

_HCL_QUERY = """
(block
  type: (identifier) @class.name
  label: (string_lit) @class.name
) @class.def
"""

_GRAPHQL_QUERY = """
(type_definition
  name: (name) @class.name
) @class.def

(enum_definition
  name: (name) @class.name
) @class.def

(query_definition
  name: (name) @function.name
) @function.def

(mutation_definition
  name: (name) @function.name
) @function.def
"""

_PROTOBUF_QUERY = """
(message_definition
  name: (identifier) @class.name
) @class.def

(service_definition
  name: (identifier) @class.name
) @class.def

(rpc_definition
  name: (identifier) @function.name
) @function.def

(import_statement) @import.stmt
"""

_HASKELL_QUERY = """
(function
  name: (variable) @function.name
) @function.def

(data_declaration
  name: (type) @class.name
) @class.def

(class_declaration
  name: (type) @class.name
) @class.def

(import_statement) @import.stmt
"""

_OCAML_QUERY = """
(value_definition
  name: (value_name) @function.name
) @function.def

(type_declaration
  name: (type_name) @class.name
) @class.def

(module_definition
  name: (module_name) @class.name
) @class.def
"""

_ELIXIR_QUERY = """
(function
  name: (identifier) @function.name
) @function.def

(defmodule
  name: (alias) @class.name
) @class.def

(call
  function: (identifier) @call.name
) @call.expr
"""

_DART_QUERY = """
(function_declaration
  name: (identifier) @function.name
) @function.def

(method_declaration
  name: (identifier) @function.name
) @function.def

(class_declaration
  name: (identifier) @class.name
) @class.def

(import_statement) @import.stmt

(function_expression_body
  (invocation_expression
    function: (identifier) @call.name)
) @call.expr
"""

_ZIG_QUERY = """
(function_declaration
  name: (identifier) @function.name
) @function.def

(struct_declaration
  name: (identifier) @class.name
) @class.def

(call_expression
  function: (identifier) @call.name
) @call.expr
"""

_SOLIDITY_QUERY = """
(function_definition
  name: (identifier) @function.name
) @function.def

(contract_declaration
  name: (identifier) @class.name
) @class.def

(import_directive) @import.stmt

(call_expression
  expression: (identifier) @call.name
) @call.expr
"""

_SVELTE_QUERY = """
(element
  start_tag: (start_tag
    name: (tag_name) @class.name)
) @class.def

(script_element) @function.def
"""

_POWERSHELL_QUERY = """
(function_definition
  name: (identifier) @function.name
) @function.def

(command_invocation
  command: (identifier) @call.name
) @call.expr
"""

_MAKE_QUERY = """
(target
  name: (word) @function.name
) @function.def
"""

_CMAKE_QUERY = """
(function_call
  function: (identifier) @call.name
) @call.expr
"""

_NIX_QUERY = """
(binding
  name: (identifier) @function.name
) @function.def

(function_expression
  (formal
    name: (identifier)) @function.name
) @function.def
"""


# ===========================================================================
# Master query registry
# ===========================================================================

LANGUAGE_QUERIES = {
    'python':      _PYTHON_QUERY,
    'typescript':  _TYPESCRIPT_QUERY,
    'javascript':  _JAVASCRIPT_QUERY,
    'go':          _GO_QUERY,
    'rust':        _RUST_QUERY,
    'java':        _JAVA_QUERY,
    'c':           _C_QUERY,
    'cpp':         _CPP_QUERY,
    'csharp':      _CSHARP_QUERY,
    'ruby':        _RUBY_QUERY,
    'php':         _PHP_QUERY,
    'swift':       _SWIFT_QUERY,
    'scala':       _SCALA_QUERY,
    'kotlin':      _KOTLIN_QUERY,
    'lua':         _LUA_QUERY,
    'sql':         _SQL_QUERY,
    'shell':       _BASH_QUERY,
    'html':        _HTML_QUERY,
    'css':         _CSS_QUERY,
    'scss':        _CSS_QUERY,
    'less':        _CSS_QUERY,
    'json':        _JSON_QUERY,
    'yaml':        _YAML_QUERY,
    'toml':        _TOML_QUERY,
    'markdown':    _MARKDOWN_QUERY,
    'dockerfile':  _DOCKERFILE_QUERY,
    'terraform':   _HCL_QUERY,
    'hcl':         _HCL_QUERY,
    'graphql':     _GRAPHQL_QUERY,
    'protobuf':    _PROTOBUF_QUERY,
    'haskell':     _HASKELL_QUERY,
    'ocaml':       _OCAML_QUERY,
    'elixir':      _ELIXIR_QUERY,
    'dart':        _DART_QUERY,
    'zig':         _ZIG_QUERY,
    'solidity':    _SOLIDITY_QUERY,
    'svelte':      _SVELTE_QUERY,
    'makefile':    _MAKE_QUERY,
    'cmake':       _CMAKE_QUERY,
    'powershell':  _POWERSHELL_QUERY,
    'nix':         _NIX_QUERY,
    'bash':        _BASH_QUERY,
}


# ===========================================================================
# Regex-based fallback extractors
# ===========================================================================

# --- Helpers ---

_C_LIKE_KEYWORDS = {
    'if', 'for', 'while', 'switch', 'return', 'goto', 'break', 'continue',
    'case', 'default', 'sizeof', 'typedef', 'struct', 'enum', 'union',
    'volatile', 'const', 'static', 'extern', 'register', 'auto',
    'void', 'char', 'short', 'int', 'long', 'float', 'double',
    'signed', 'unsigned', 'true', 'false', 'null', 'NULL', 'nullptr',
    'new', 'delete', 'class', 'namespace', 'using', 'template', 'typename',
    'public', 'private', 'protected', 'virtual', 'override', 'final',
    'try', 'catch', 'throw', 'throws', 'async', 'await',
}

_ML_KEYWORDS = {
    'let', 'in', 'match', 'with', 'fun', 'and', 'rec', 'type', 'module',
    'open', 'val', 'end', 'begin', 'struct', 'sig', 'mutable', 'ref',
    'as', 'of', 'when', 'then', 'else', 'if', 'do', 'done',
}

_FUNC_PATTERN = re.compile(
    r'(?:export\s+)?(?:async\s+)?(?:static\s+)?(?:def(?:ine)?|fun(?:c(?:tion)?)?|fn)\s+(\w+)',
    re.MULTILINE | re.IGNORECASE
)
_CLASS_PATTERN = re.compile(
    r'(?:export\s+)?(?:abstract\s+)?(?:class|interface|struct|enum|record|trait|object)\s+(\w+)',
    re.MULTILINE
)
_CALL_PATTERN = re.compile(
    r'(?:^|[^a-zA-Z0-9_\.])(\w+)\s*\(',
    re.MULTILINE
)

_SOURCE_CACHE: dict[str, str] = {}


def _get_lines(source: str, match: re.Match) -> int:
    return source[:match.start()].count('\n') + 1


def _is_exported(source: str, match: re.Match, keyword: str = 'export') -> bool:
    return keyword in source[max(0, match.start() - 60):match.start()]


def _filter_calls(calls: list[dict], keywords: set[str]) -> list[dict]:
    return [c for c in calls if c['callee_name'] not in keywords]


# --- Python ---

def _extract_python_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    symbols, calls = [], []
    for m in re.finditer(r'^\s*def\s+(\w+)\s*\(([^)]*)\)\s*(?:->.*?)?:', source, re.MULTILINE):
        name = m.group(1)
        ln = _get_lines(source, m)
        symbols.append({'name': name, 'kind': 'function', 'signature': f"def {name}({m.group(2)})",
                        'start_line': ln, 'end_line': ln, 'is_exported': not name.startswith('_')})
    for m in re.finditer(r'^\s*class\s+(\w+)\s*(?:\(([^)]*)\))?\s*:', source, re.MULTILINE):
        name = m.group(1)
        ln = _get_lines(source, m)
        symbols.append({'name': name, 'kind': 'class', 'signature': f"class {name}",
                        'start_line': ln, 'end_line': ln, 'is_exported': not name.startswith('_')})
    py_kw = {'if','for','while','with','return','yield','assert','print','len','range',
             'int','str','float','bool','list','dict','set','tuple','type','isinstance',
             'hasattr','getattr','setattr','super','not','and','or','True','False','None',
             'elif','else','except','try','raise','import','from','def','class','lambda',
             'pass','break','continue','del','global','nonlocal'}
    for m in _CALL_PATTERN.finditer(source):
        name = m.group(1)
        if name not in py_kw:
            calls.append({'callee_name': name, 'call_line': _get_lines(source, m),
                          'is_dynamic': False, 'confidence': 0.7})
    return symbols, calls


# --- C-like languages ---

def _extract_c_like_regex(source: str, file_path: str, lang: str = 'c') -> tuple[list[dict], list[dict]]:
    """Generic C-family regex extractor: C, C++, C#, Java, Kotlin, Dart, Zig, Solidity, etc."""
    symbols, calls = [], []

    # Function definitions — language-specific patterns
    if lang in ('c', 'cpp', 'csharp', 'java', 'kotlin', 'dart', 'zig', 'solidity', 'nim', 'swift', 'scala'):
        func_pats = [
            (rf'(?:public|private|protected|static|virtual|override|abstract|async|unsafe|extern|inline|final|open|sealed|\s)*'
             rf'(?:[\w<>\[\],\s]+\s+)?(\w+)\s*\(([^)]*)\)'
             rf'(?:\s*(?:->|:)?\s*[\w<>\[\],\s]+)?'  # return type: void, -> Type, :Type
             rf'\s*\{{', 'function'),
        ]
        if lang == 'go':
            func_pats = [
                (r'func\s+(?:\(\w+\s+\*?\w+\)\s+)?(\w+)\s*\(([^)]*)\)', 'function'),
            ]
        elif lang == 'rust':
            func_pats = [
                (r'(?:pub\s+)?fn\s+(\w+)\s*(?:<[^>]*>)?\s*\(([^)]*)\)', 'function'),
            ]
        for pat, kind in func_pats:
            for m in re.finditer(pat, source, re.MULTILINE):
                name = m.group(1)
                ln = _get_lines(source, m)
                symbols.append({'name': name, 'kind': kind,
                                'signature': source[m.start():m.start()+min(100, m.end()-m.start())].split('\n')[0].strip(),
                                'start_line': ln, 'end_line': ln,
                                'is_exported': name[0].isupper() if lang in ('go',) else not name.startswith('_')})

    # Class/struct/interface
    if lang == 'rust':
        for m in re.finditer(r'(?:pub\s+)?(?:struct|enum|trait)\s+(\w+)', source, re.MULTILINE):
            name = m.group(1)
            ln = _get_lines(source, m)
            symbols.append({'name': name, 'kind': 'class', 'signature': source[m.start():m.start()+min(80, m.end()-m.start())].split('\n')[0].strip(),
                            'start_line': ln, 'end_line': ln, 'is_exported': 'pub' in source[max(0, m.start()-20):m.start()]})
    else:
        for m in _CLASS_PATTERN.finditer(source):
            name = m.group(1)
            ln = _get_lines(source, m)
            symbols.append({'name': name, 'kind': 'class', 'signature': source[m.start():m.start()+min(80, m.end()-m.start())].split('\n')[0].strip(),
                            'start_line': ln, 'end_line': ln, 'is_exported': not name.startswith('_')})

    # Calls
    for m in _CALL_PATTERN.finditer(source):
        name = m.group(1)
        if name not in _C_LIKE_KEYWORDS:
            calls.append({'callee_name': name, 'call_line': _get_lines(source, m),
                          'is_dynamic': False, 'confidence': 0.6})
    return symbols, calls


def _extract_c_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    return _extract_c_like_regex(source, file_path, 'c')

def _extract_cpp_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    return _extract_c_like_regex(source, file_path, 'cpp')

def _extract_csharp_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    return _extract_c_like_regex(source, file_path, 'csharp')

def _extract_java_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    return _extract_c_like_regex(source, file_path, 'java')

def _extract_kotlin_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    return _extract_c_like_regex(source, file_path, 'kotlin')

def _extract_dart_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    return _extract_c_like_regex(source, file_path, 'dart')

def _extract_zig_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    return _extract_c_like_regex(source, file_path, 'zig')

def _extract_solidity_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    return _extract_c_like_regex(source, file_path, 'solidity')

def _extract_swift_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    return _extract_c_like_regex(source, file_path, 'swift')

def _extract_scala_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    return _extract_c_like_regex(source, file_path, 'scala')

def _extract_nim_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    return _extract_c_like_regex(source, file_path, 'nim')


# --- TypeScript/JavaScript ---

def _extract_ts_js_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    symbols, calls = [], []
    for m in re.finditer(r'(?:export\s+)?(?:async\s+)?function\s+(\w+)\s*\(([^)]*)\)', source, re.MULTILINE):
        name = m.group(1)
        ln = _get_lines(source, m)
        symbols.append({'name': name, 'kind': 'function', 'signature': f"function {name}({m.group(2)})",
                        'start_line': ln, 'end_line': ln, 'is_exported': _is_exported(source, m)})
    for m in re.finditer(r'(?:export\s+)?(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s+)?\(([^)]*)\)\s*=>', source, re.MULTILINE):
        name = m.group(1)
        ln = _get_lines(source, m)
        symbols.append({'name': name, 'kind': 'function', 'signature': f"const {name} = ({m.group(2)}) =>",
                        'start_line': ln, 'end_line': ln, 'is_exported': _is_exported(source, m)})
    for m in re.finditer(r'(?:export\s+)?(?:abstract\s+)?class\s+(\w+)\s*(?:extends\s+(\w+))?', source, re.MULTILINE):
        name = m.group(1)
        ln = _get_lines(source, m)
        symbols.append({'name': name, 'kind': 'class', 'signature': f"class {name}",
                        'start_line': ln, 'end_line': ln, 'is_exported': _is_exported(source, m)})
    js_kw = {'if','for','while','switch','return','yield','await','typeof','instanceof','new','delete',
             'void','throw','import','export','default','function','class','const','let','var','async',
             'true','false','null','undefined','console','require','super','this','break','continue',
             'else','catch','finally','try','do','in','of'}
    for m in _CALL_PATTERN.finditer(source):
        name = m.group(1)
        if name not in js_kw:
            calls.append({'callee_name': name, 'call_line': _get_lines(source, m),
                          'is_dynamic': False, 'confidence': 0.6})
    return symbols, calls


# --- Go ---

def _extract_go_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    symbols, calls = [], []
    for m in re.finditer(r'func\s+(?:\((\w+)\s+\*?(\w+)\)\s+)?(\w+)\s*\(([^)]*)\)', source, re.MULTILINE):
        receiver, name = m.group(2), m.group(3)
        full_name = f"{receiver}.{name}" if receiver else name
        ln = _get_lines(source, m)
        symbols.append({'name': full_name, 'kind': 'method' if receiver else 'function',
                        'signature': f"func {full_name}({m.group(4)})",
                        'start_line': ln, 'end_line': ln, 'is_exported': name[0].isupper() if name else False})
    for m in re.finditer(r'type\s+(\w+)\s+struct\s*{', source, re.MULTILINE):
        name = m.group(1)
        ln = _get_lines(source, m)
        symbols.append({'name': name, 'kind': 'class', 'signature': f"type {name} struct",
                        'start_line': ln, 'end_line': ln, 'is_exported': name[0].isupper()})
    go_kw = {'if','for','range','switch','return','go','defer','make','new','append','len','cap',
             'copy','delete','close','panic','recover','print','println','func','type','var','const',
             'import','package','struct','interface','map','chan','select','case','default','break',
             'continue','goto','fallthrough','true','false','nil','iota','error','string','int','bool',
             'byte','float64','float32','int64','int32','uint','uint64'}
    for m in _CALL_PATTERN.finditer(source):
        name = m.group(1)
        if name not in go_kw:
            calls.append({'callee_name': name, 'call_line': _get_lines(source, m),
                          'is_dynamic': False, 'confidence': 0.6})
    return symbols, calls


# --- Rust ---

def _extract_rust_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    symbols, calls = [], []
    for m in re.finditer(r'(?:pub\s+)?fn\s+(\w+)\s*(?:<[^>]*>)?\s*\(([^)]*)\)', source, re.MULTILINE):
        name = m.group(1)
        ln = _get_lines(source, m)
        symbols.append({'name': name, 'kind': 'function', 'signature': f"fn {name}({m.group(2)})",
                        'start_line': ln, 'end_line': ln, 'is_exported': _is_exported(source, m, 'pub')})
    for m in re.finditer(r'(?:pub\s+)?(?:struct|enum|trait)\s+(\w+)', source, re.MULTILINE):
        name = m.group(1)
        ln = _get_lines(source, m)
        symbols.append({'name': name, 'kind': 'class', 'signature': source[m.start():m.start()+min(60, m.end()-m.start())].strip(),
                        'start_line': ln, 'end_line': ln, 'is_exported': _is_exported(source, m, 'pub')})
    rust_kw = {'if','for','while','loop','match','return','yield','let','mut','ref','use','mod','pub',
               'crate','self','super','extern','fn','struct','enum','trait','impl','where','as','in',
               'move','async','await','dyn','true','false','Some','None','Ok','Err','Vec','String',
               'Option','Result','Box','panic','assert','println','print','format','vec','clone','copy',
               'into','from','unwrap','expect','map','and_then'}
    for m in _CALL_PATTERN.finditer(source):
        name = m.group(1)
        if name not in rust_kw:
            calls.append({'callee_name': name, 'call_line': _get_lines(source, m),
                          'is_dynamic': False, 'confidence': 0.6})
    return symbols, calls


# --- Ruby ---

def _extract_ruby_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    symbols, calls = [], []
    for m in re.finditer(r'^\s*def\s+(\w+(?:[?!])?)\s*(?:\(([^)]*)\))?', source, re.MULTILINE):
        name = m.group(1)
        ln = _get_lines(source, m)
        symbols.append({'name': name, 'kind': 'function', 'signature': f"def {name}",
                        'start_line': ln, 'end_line': ln, 'is_exported': True})
    for m in re.finditer(r'^\s*class\s+(\w+)\s*(?:<\s*(\w+))?', source, re.MULTILINE):
        name = m.group(1)
        ln = _get_lines(source, m)
        symbols.append({'name': name, 'kind': 'class', 'signature': f"class {name}",
                        'start_line': ln, 'end_line': ln, 'is_exported': True})
    for m in re.finditer(r'^\s*module\s+(\w+)', source, re.MULTILINE):
        name = m.group(1)
        ln = _get_lines(source, m)
        symbols.append({'name': name, 'kind': 'class', 'signature': f"module {name}",
                        'start_line': ln, 'end_line': ln, 'is_exported': True})
    rb_kw = {'if','unless','while','until','for','return','yield','raise','begin','rescue',
             'ensure','end','do','def','class','module','include','extend','require','load',
             'true','false','nil','puts','print','p','puts','gets','attr_accessor','attr_reader',
             'attr_writer','private','protected','public','new','super','self'}
    for m in re.finditer(r'(?:^|[^a-zA-Z0-9_\.])(\w+)\s*\(' , source, re.MULTILINE):
        name = m.group(1)
        if name not in rb_kw and not name[0].isupper():  # skip constants used as calls
            calls.append({'callee_name': name, 'call_line': _get_lines(source, m),
                          'is_dynamic': False, 'confidence': 0.6})
    return symbols, calls


# --- PHP ---

def _extract_php_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    symbols, calls = [], []
    for m in re.finditer(r'(?:public\s+|private\s+|protected\s+|static\s+)*function\s+(\w+)\s*\(([^)]*)\)', source, re.MULTILINE):
        name = m.group(1)
        ln = _get_lines(source, m)
        is_exported = not name.startswith('_')
        symbols.append({'name': name, 'kind': 'function', 'signature': f"function {name}({m.group(2)}))",
                        'start_line': ln, 'end_line': ln, 'is_exported': is_exported})
    for m in re.finditer(r'(?:abstract\s+)?class\s+(\w+)', source, re.MULTILINE):
        name = m.group(1)
        ln = _get_lines(source, m)
        symbols.append({'name': name, 'kind': 'class', 'signature': f"class {name}",
                        'start_line': ln, 'end_line': ln, 'is_exported': True})
    php_kw = {'if','else','elseif','for','foreach','while','do','switch','case','return','echo',
              'print','require','require_once','include','include_once','function','class','new',
              'throw','try','catch','finally','die','exit','isset','empty','unset','array','list',
              'true','false','null','namespace','use','as','extends','implements','abstract',
              'public','private','protected','static','final','parent','self'}
    for m in _CALL_PATTERN.finditer(source):
        name = m.group(1)
        if name not in php_kw:
            calls.append({'callee_name': name, 'call_line': _get_lines(source, m),
                          'is_dynamic': False, 'confidence': 0.6})
    return symbols, calls


# --- Shell / Bash ---

def _extract_shell_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    symbols, calls = [], []
    for m in re.finditer(r'^\s*(?:function\s+)?(\w+)\s*\(\s*\)\s*{', source, re.MULTILINE):
        name = m.group(1)
        ln = _get_lines(source, m)
        symbols.append({'name': name, 'kind': 'function', 'signature': f"{name}()",
                        'start_line': ln, 'end_line': ln, 'is_exported': True})
    for m in re.finditer(r'^\s*(\w+)\s*\(\s*\)', source, re.MULTILINE):
        name = m.group(1)
        ln = _get_lines(source, m)
        symbols.append({'name': name, 'kind': 'function', 'signature': f"{name}()",
                        'start_line': ln, 'end_line': ln, 'is_exported': True})
    sh_kw = {'if','then','else','elif','fi','for','while','do','done','case','esac','in',
             'return','exit','echo','printf','read','source','export','declare','local',
             'function','alias','unalias','cd','ls','cat','grep','sed','awk','true','false'}
    for m in re.finditer(r'(?:^|[^a-zA-Z0-9_\-])(\w[\w\-]*)\s+', source, re.MULTILINE):
        name = m.group(1)
        if name not in sh_kw and not name.startswith('-'):
            calls.append({'callee_name': name, 'call_line': _get_lines(source, m),
                          'is_dynamic': False, 'confidence': 0.5})
    return symbols, calls


# --- PowerShell ---

def _extract_powershell_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    symbols, calls = [], []
    for m in re.finditer(r'function\s+(\w+(?:-\w+)*)\s*{', source, re.MULTILINE | re.IGNORECASE):
        name = m.group(1)
        ln = _get_lines(source, m)
        symbols.append({'name': name, 'kind': 'function', 'signature': f"function {name}",
                        'start_line': ln, 'end_line': ln, 'is_exported': True})
    for m in re.finditer(r'(?:^|\s)(\w+(?:-\w+)+)\s', source, re.MULTILINE):
        name = m.group(1)
        if '-' in name:
            calls.append({'callee_name': name, 'call_line': _get_lines(source, m),
                          'is_dynamic': False, 'confidence': 0.5})
    return symbols, calls


# --- Lua ---

def _extract_lua_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    symbols, calls = [], []
    for m in re.finditer(r'(?:local\s+)?function\s+(\w+(?:\.\w+)?)\s*\(([^)]*)\)', source, re.MULTILINE):
        name = m.group(1)
        ln = _get_lines(source, m)
        symbols.append({'name': name, 'kind': 'function', 'signature': f"function {name}({m.group(2)})",
                        'start_line': ln, 'end_line': ln, 'is_exported': not name.startswith('_')})
    lua_kw = {'if','then','else','elseif','for','while','do','repeat','until','return',
              'local','function','end','nil','true','false','and','or','not','break','goto',
              'print','require','module','package','string','table','math','io','os'}
    for m in _CALL_PATTERN.finditer(source):
        name = m.group(1)
        if name not in lua_kw:
            calls.append({'callee_name': name, 'call_line': _get_lines(source, m),
                          'is_dynamic': False, 'confidence': 0.6})
    return symbols, calls


# --- SQL ---

def _extract_sql_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    symbols, calls = [], []
    for m in re.finditer(r'CREATE\s+(?:OR\s+REPLACE\s+)?(TABLE|VIEW|INDEX|FUNCTION|PROCEDURE|TRIGGER)\s+(?:IF\s+NOT\s+EXISTS\s+)?(\w+)',
                         source, re.MULTILINE | re.IGNORECASE):
        obj_type = m.group(1).upper()
        name = m.group(2)
        ln = _get_lines(source, m)
        kind = 'function' if obj_type in ('FUNCTION', 'PROCEDURE', 'TRIGGER') else 'class'
        symbols.append({'name': name, 'kind': kind, 'signature': f"CREATE {obj_type} {name}",
                        'start_line': ln, 'end_line': ln, 'is_exported': True})
    for m in re.finditer(r'(?:FROM|JOIN|INTO|UPDATE|TABLE)\s+(\w+)', source, re.MULTILINE | re.IGNORECASE):
        name = m.group(1)
        calls.append({'callee_name': name, 'call_line': _get_lines(source, m),
                      'is_dynamic': False, 'confidence': 0.5})
    return symbols, calls


# --- GraphQL ---

def _extract_graphql_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    symbols, calls = [], []
    for m in re.finditer(r'(type|input|enum|interface|union|query|mutation|subscription|fragment)\s+(\w+)',
                         source, re.MULTILINE):
        kind = m.group(1)
        name = m.group(2)
        ln = _get_lines(source, m)
        sym_kind = 'function' if kind in ('query', 'mutation', 'subscription') else 'class'
        symbols.append({'name': name, 'kind': sym_kind, 'signature': f"{kind} {name}",
                        'start_line': ln, 'end_line': ln, 'is_exported': True})
    return symbols, calls


# --- Protobuf ---

def _extract_protobuf_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    symbols, calls = [], []
    for m in re.finditer(r'(message|service|enum)\s+(\w+)', source, re.MULTILINE):
        kind, name = m.group(1), m.group(2)
        ln = _get_lines(source, m)
        symbols.append({'name': name, 'kind': 'class', 'signature': f"{kind} {name}",
                        'start_line': ln, 'end_line': ln, 'is_exported': True})
    for m in re.finditer(r'rpc\s+(\w+)\s*\(', source, re.MULTILINE):
        name = m.group(1)
        ln = _get_lines(source, m)
        symbols.append({'name': name, 'kind': 'function', 'signature': f"rpc {name}",
                        'start_line': ln, 'end_line': ln, 'is_exported': True})
    return symbols, calls


# --- YAML ---

def _extract_yaml_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    symbols, calls = [], []
    for m in re.finditer(r'^(\w[\w\-_]*)\s*:', source, re.MULTILINE):
        name = m.group(1)
        if name not in ('true', 'false', 'yes', 'no', 'on', 'off', 'null', '~'):
            ln = _get_lines(source, m)
            symbols.append({'name': name, 'kind': 'field', 'signature': f"{name}:",
                            'start_line': ln, 'end_line': ln, 'is_exported': True})
    return symbols, calls


# --- JSON ---

def _extract_json_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    symbols, calls = [], []
    for m in re.finditer(r'"(\\"|[^"])+"\s*:', source, re.MULTILINE):
        key = m.group(0).split('"')[1]
        ln = _get_lines(source, m)
        symbols.append({'name': key, 'kind': 'field', 'signature': f'"{key}":',
                        'start_line': ln, 'end_line': ln, 'is_exported': True})
    return symbols, calls


# --- TOML ---

def _extract_toml_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    symbols, calls = [], []
    for m in re.finditer(r'\[([^\]]+)\]', source, re.MULTILINE):
        name = m.group(1)
        ln = _get_lines(source, m)
        symbols.append({'name': name, 'kind': 'section', 'signature': f"[{name}]",
                        'start_line': ln, 'end_line': ln, 'is_exported': True})
    for m in re.finditer(r'^(\w[\w\-_]*)\s*=', source, re.MULTILINE):
        name = m.group(1)
        ln = _get_lines(source, m)
        symbols.append({'name': name, 'kind': 'field', 'signature': f"{name} =",
                        'start_line': ln, 'end_line': ln, 'is_exported': True})
    return symbols, calls


# --- INI / ENV ---

def _extract_ini_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    symbols, calls = [], []
    for m in re.finditer(r'^\[([^\]]+)\]', source, re.MULTILINE):
        name = m.group(1)
        ln = _get_lines(source, m)
        symbols.append({'name': name, 'kind': 'section', 'signature': f"[{name}]",
                        'start_line': ln, 'end_line': ln, 'is_exported': True})
    for m in re.finditer(r'^(\w[\w\-_]*)\s*[=:]\s*.+', source, re.MULTILINE):
        name = m.group(1)
        ln = _get_lines(source, m)
        symbols.append({'name': name, 'kind': 'field', 'signature': f"{name} =",
                        'start_line': ln, 'end_line': ln, 'is_exported': True})
    return symbols, calls


def _extract_env_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    symbols, calls = [], []
    for m in re.finditer(r'^(\w[\w\-_]*)\s*=\s*.+', source, re.MULTILINE):
        name = m.group(1)
        if not name.startswith('#'):
            ln = _get_lines(source, m)
            symbols.append({'name': name, 'kind': 'field', 'signature': f"{name} =",
                            'start_line': ln, 'end_line': ln, 'is_exported': True})
    return symbols, calls


# --- HTML ---

def _extract_html_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    symbols, calls = [], []
    for m in re.finditer(r'<(?![/!])(\w+)[^>]*>', source, re.MULTILINE):
        name = m.group(1).lower()
        if name not in ('html', 'head', 'body', 'meta', 'link', 'br', 'hr', 'img', 'input', '!doctype'):
            ln = _get_lines(source, m)
            symbols.append({'name': name, 'kind': 'element', 'signature': f"<{name}>",
                            'start_line': ln, 'end_line': ln, 'is_exported': True})
    return symbols, calls


# --- XML ---

def _extract_xml_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    symbols, calls = [], []
    for m in re.finditer(r'<(?![/?!])([\w:]+)[^>]*>', source, re.MULTILINE):
        name = m.group(1)
        if not name.startswith('?'):
            ln = _get_lines(source, m)
            symbols.append({'name': name, 'kind': 'element', 'signature': f"<{name}>",
                            'start_line': ln, 'end_line': ln, 'is_exported': True})
    return symbols, calls


# --- CSS / SCSS / Less ---

def _extract_css_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    symbols, calls = [], []
    for m in re.finditer(r'([.#@]?[\w\-_:]+)\s*{', source, re.MULTILINE):
        name = m.group(1).strip()
        if name and name not in ('from', 'to', '0%', '50%', '100%'):
            ln = _get_lines(source, m)
            kind = 'at-rule' if name.startswith('@') else 'selector'
            symbols.append({'name': name, 'kind': kind, 'signature': f"{name} {{",
                            'start_line': ln, 'end_line': ln, 'is_exported': True})
    return symbols, calls


# --- Markdown ---

def _extract_markdown_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    symbols, calls = [], []
    for m in re.finditer(r'^(#{1,6})\s+(.+)', source, re.MULTILINE):
        level = len(m.group(1))
        name = m.group(2).strip()
        ln = _get_lines(source, m)
        symbols.append({'name': name[:60], 'kind': 'heading', 'signature': f"{'#'*level} {name[:40]}",
                        'start_line': ln, 'end_line': ln, 'is_exported': True})
    return symbols, calls


# --- Dockerfile ---

def _extract_dockerfile_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    symbols, calls = [], []
    for m in re.finditer(r'^(FROM|RUN|CMD|COPY|ADD|ENV|ARG|LABEL|EXPOSE|VOLUME|WORKDIR|USER|ENTRYPOINT|HEALTHCHECK)\s+',
                         source, re.MULTILINE | re.IGNORECASE):
        instruction = m.group(1).upper()
        ln = _get_lines(source, m)
        symbols.append({'name': instruction, 'kind': 'instruction',
                        'signature': source[m.start():m.start()+min(80, m.end()-m.start())].strip(),
                        'start_line': ln, 'end_line': ln, 'is_exported': True})
    return symbols, calls


# --- Terraform / HCL ---

def _extract_terraform_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    symbols, calls = [], []
    for m in re.finditer(r'(resource|data|module|variable|output|provider|terraform|locals)\s+"(\w+)"\s+"(\w+)"',
                         source, re.MULTILINE):
        block_type, provider, name = m.group(1), m.group(2), m.group(3)
        ln = _get_lines(source, m)
        full_name = f"{provider}.{name}"
        symbols.append({'name': full_name, 'kind': block_type,
                        'signature': f'{block_type} "{provider}" "{name}"',
                        'start_line': ln, 'end_line': ln, 'is_exported': True})
    return symbols, calls


# --- Make ---

def _extract_makefile_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    symbols, calls = [], []
    for m in re.finditer(r'^([\w\-_/.]+)\s*:', source, re.MULTILINE):
        name = m.group(1)
        if name not in ('.PHONY', '.DEFAULT', '.SILENT', '.SUFFIXES', '.INTERMEDIATE', '.PRECIOUS'):
            ln = _get_lines(source, m)
            symbols.append({'name': name, 'kind': 'target', 'signature': f"{name}:",
                            'start_line': ln, 'end_line': ln, 'is_exported': True})
    return symbols, calls


# --- CMake ---

def _extract_cmake_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    symbols, calls = [], []
    for m in re.finditer(r'(add_executable|add_library|add_test|project|target_link_libraries|find_package)\s*\(\s*(\w+)',
                         source, re.MULTILINE):
        func, name = m.group(1), m.group(2)
        ln = _get_lines(source, m)
        symbols.append({'name': name, 'kind': 'target', 'signature': f'{func}({name}',
                        'start_line': ln, 'end_line': ln, 'is_exported': True})
    return symbols, calls


# --- Haskell ---

def _extract_haskell_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    symbols, calls = [], []
    for m in re.finditer(r'^(\w+)\s*::\s*', source, re.MULTILINE):
        name = m.group(1)
        ln = _get_lines(source, m)
        symbols.append({'name': name, 'kind': 'function', 'signature': f"{name} ::",
                        'start_line': ln, 'end_line': ln, 'is_exported': True})
    for m in re.finditer(r'(data|newtype|type|class)\s+(\w+)', source, re.MULTILINE):
        keyword, name = m.group(1), m.group(2)
        ln = _get_lines(source, m)
        symbols.append({'name': name, 'kind': 'class', 'signature': f"{keyword} {name}",
                        'start_line': ln, 'end_line': ln, 'is_exported': True})
    return symbols, calls


# --- OCaml ---

def _extract_ocaml_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    symbols, calls = [], []
    for m in re.finditer(r'(?:let|let\s+rec)\s+(\w+)\s', source, re.MULTILINE):
        name = m.group(1)
        ln = _get_lines(source, m)
        symbols.append({'name': name, 'kind': 'function', 'signature': f"let {name}",
                        'start_line': ln, 'end_line': ln, 'is_exported': True})
    for m in re.finditer(r'(?:type|module)\s+(\w+)', source, re.MULTILINE):
        name = m.group(1)
        ln = _get_lines(source, m)
        symbols.append({'name': name, 'kind': 'class', 'signature': f"type/module {name}",
                        'start_line': ln, 'end_line': ln, 'is_exported': True})
    return symbols, calls


# --- Elixir ---

def _extract_elixir_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    symbols, calls = [], []
    for m in re.finditer(r'(?:def|defp)\s+(\w+)\s*\(', source, re.MULTILINE):
        name = m.group(1)
        ln = _get_lines(source, m)
        symbols.append({'name': name, 'kind': 'function', 'signature': f"def {name}",
                        'start_line': ln, 'end_line': ln, 'is_exported': not name.startswith('_')})
    for m in re.finditer(r'defmodule\s+(\w+(?:\.\w+)*)', source, re.MULTILINE):
        name = m.group(1)
        ln = _get_lines(source, m)
        symbols.append({'name': name, 'kind': 'class', 'signature': f"defmodule {name}",
                        'start_line': ln, 'end_line': ln, 'is_exported': True})
    return symbols, calls


# --- Erlang ---

def _extract_erlang_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    symbols, calls = [], []
    for m in re.finditer(r'^(\w+)\s*\(', source, re.MULTILINE):
        name = m.group(1)
        ln = _get_lines(source, m)
        symbols.append({'name': name, 'kind': 'function', 'signature': f"{name}()",
                        'start_line': ln, 'end_line': ln, 'is_exported': True})
    return symbols, calls


# --- Elm ---

def _extract_elm_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    symbols, calls = [], []
    for m in re.finditer(r'^(\w+)\s*:\s*', source, re.MULTILINE):
        name = m.group(1)
        ln = _get_lines(source, m)
        symbols.append({'name': name, 'kind': 'function', 'signature': f"{name} :",
                        'start_line': ln, 'end_line': ln, 'is_exported': True})
    for m in re.finditer(r'type\s+(?:alias\s+)?(\w+)', source, re.MULTILINE):
        name = m.group(1)
        ln = _get_lines(source, m)
        symbols.append({'name': name, 'kind': 'class', 'signature': f"type {name}",
                        'start_line': ln, 'end_line': ln, 'is_exported': True})
    return symbols, calls


# --- Clojure ---

def _extract_clojure_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    symbols, calls = [], []
    for m in re.finditer(r'\((?:def|defn|defn-|defmacro|defprotocol|defrecord|deftype)\s+([\w\-?!]+)',
                         source, re.MULTILINE):
        form = m.group(0).split()[0].lstrip('(')
        name = m.group(1)
        ln = _get_lines(source, m)
        kind = 'class' if form in ('defprotocol', 'defrecord', 'deftype') else 'function'
        symbols.append({'name': name, 'kind': kind, 'signature': f"({form} {name}",
                        'start_line': ln, 'end_line': ln, 'is_exported': not name.startswith('-')})
    return symbols, calls


# --- R ---

def _extract_r_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    symbols, calls = [], []
    for m in re.finditer(r'(?:^|\n)\s*(\w+)\s*(?:<-\s*function|=\s*function)\s*\(', source, re.MULTILINE):
        name = m.group(1)
        ln = _get_lines(source, m)
        symbols.append({'name': name, 'kind': 'function', 'signature': f"{name} <- function()",
                        'start_line': ln, 'end_line': ln, 'is_exported': True})
    return symbols, calls


# --- Vue / Svelte / Astro (component frameworks) ---

def _extract_vue_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    symbols, calls = [], []
    # Extract script section
    script_match = re.search(r'<script[^>]*>(.*?)</script>', source, re.DOTALL)
    if script_match:
        js_src = script_match.group(1)
        # Standard TS/JS patterns
        js_syms, js_calls = _extract_ts_js_regex(js_src, file_path)
        symbols.extend(js_syms)
        calls.extend(js_calls)
        # Options API: data(), methods: {}, computed: {}
        for m in re.finditer(r'(\w+)\s*\(\s*\)\s*\{', js_src, re.MULTILINE):
            name = m.group(1)
            ln = _get_lines(source, m)
            symbols.append({'name': name, 'kind': 'function', 'signature': f"{name}()",
                            'start_line': ln, 'end_line': ln, 'is_exported': True})
        for methods_match in re.finditer(r'(?:methods|computed)\s*:\s*\{([^}]+(?:\{[^}]*\}[^}]*)*)\}',
                                          js_src, re.DOTALL):
            block = methods_match.group(1)
            for m in re.finditer(r'(\w+)\s*\(', block):
                name = m.group(1)
                ln = _get_lines(source, m)
                symbols.append({'name': name, 'kind': 'function', 'signature': f"{name}()",
                                'start_line': ln, 'end_line': ln, 'is_exported': True})
        # setup() function
        for m in re.finditer(r'(?:const|let|var)\s+(\w+)\s*=\s*\(', js_src, re.MULTILINE):
            name = m.group(1)
            ln = _get_lines(source, m)
            symbols.append({'name': name, 'kind': 'function', 'signature': f"const {name} = ()",
                            'start_line': ln, 'end_line': ln, 'is_exported': True})
        # defineComponent / component name
        for m in re.finditer(r"(?:export\s+default\s+)?(?:name\s*:\s*['\"]([^'\"]+)['\"]|defineComponent\s*\()",
                              js_src, re.MULTILINE):
            if m.group(1):
                ln = _get_lines(source, m)
                symbols.append({'name': m.group(1), 'kind': 'component', 'signature': f"component {m.group(1)}",
                                'start_line': ln, 'end_line': ln, 'is_exported': True})
    # Template components
    for m in re.finditer(r'<([A-Z]\w+)', source, re.MULTILINE):
        name = m.group(1)
        ln = _get_lines(source, m)
        symbols.append({'name': name, 'kind': 'component', 'signature': f"<{name}>",
                        'start_line': ln, 'end_line': ln, 'is_exported': True})
    return symbols, calls


def _extract_svelte_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    symbols, calls = [], []
    script_match = re.search(r'<script[^>]*>(.*?)</script>', source, re.DOTALL)
    if script_match:
        js_syms, js_calls = _extract_ts_js_regex(script_match.group(1), file_path)
        symbols.extend(js_syms)
        calls.extend(js_calls)
    return symbols, calls


def _extract_astro_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    symbols, calls = [], []
    # Frontmatter
    fm_match = re.search(r'^---\s*\n(.*?)\n---', source, re.DOTALL)
    if fm_match:
        js_syms, js_calls = _extract_ts_js_regex(fm_match.group(1), file_path)
        symbols.extend(js_syms)
        calls.extend(js_calls)
    return symbols, calls


# --- Prisma ---

def _extract_prisma_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    symbols, calls = [], []
    for m in re.finditer(r'(model|enum|view)\s+(\w+)', source, re.MULTILINE):
        keyword, name = m.group(1), m.group(2)
        ln = _get_lines(source, m)
        symbols.append({'name': name, 'kind': 'model', 'signature': f"{keyword} {name}",
                        'start_line': ln, 'end_line': ln, 'is_exported': True})
    return symbols, calls


# --- Move ---

def _extract_move_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    symbols, calls = [], []
    for m in re.finditer(r'(?:public\s+)?(?:native\s+)?fun\s+(\w+)\s*\(', source, re.MULTILINE):
        name = m.group(1)
        ln = _get_lines(source, m)
        symbols.append({'name': name, 'kind': 'function', 'signature': f"fun {name}",
                        'start_line': ln, 'end_line': ln, 'is_exported': 'public' in source[max(0, m.start()-40):m.start()]})
    for m in re.finditer(r'(?:module|struct|resource)\s+(\w+(?:::\w+)*)', source, re.MULTILINE):
        name = m.group(1)
        ln = _get_lines(source, m)
        symbols.append({'name': name, 'kind': 'class', 'signature': source[m.start():m.start()+min(60, m.end()-m.start())].strip(),
                        'start_line': ln, 'end_line': ln, 'is_exported': True})
    return symbols, calls


# --- Bazel / Starlark ---

def _extract_bazel_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    symbols, calls = [], []
    # Rule definitions: name = rule(...)
    for m in re.finditer(r'(?:^|\n)\s*(\w+)\s*=\s*rule\s*\(', source, re.MULTILINE):
        name = m.group(1)
        ln = _get_lines(source, m)
        symbols.append({'name': name, 'kind': 'function', 'signature': f"{name} = rule(",
                        'start_line': ln, 'end_line': ln, 'is_exported': True})
    # Named dicts/structs: name = { ... }
    for m in re.finditer(r'(?:^|\n)\s*(\w+)\s*=\s*\{', source, re.MULTILINE):
        name = m.group(1)
        ln = _get_lines(source, m)
        symbols.append({'name': name, 'kind': 'target', 'signature': f"{name} =",
                        'start_line': ln, 'end_line': ln, 'is_exported': True})
    # Macro/rules calls: rule_name(name = "target", ...)
    for m in re.finditer(r'(?:^|\n)\s*(\w+)\s*\(\s*name\s*=\s*"([^"]+)"', source, re.MULTILINE):
        name = m.group(2)
        ln = _get_lines(source, m)
        symbols.append({'name': name, 'kind': 'target', 'signature': f'{m.group(1)}(name = "{name}")',
                        'start_line': ln, 'end_line': ln, 'is_exported': True})
    return symbols, calls


# --- Just ---

def _extract_just_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    symbols, calls = [], []
    for m in re.finditer(r'^([\w\-_]+)\s*:', source, re.MULTILINE):
        name = m.group(1)
        ln = _get_lines(source, m)
        symbols.append({'name': name, 'kind': 'target', 'signature': f"{name}:",
                        'start_line': ln, 'end_line': ln, 'is_exported': True})
    return symbols, calls


# --- Nix ---

def _extract_nix_regex(source: str, file_path: str) -> tuple[list[dict], list[dict]]:
    symbols, calls = [], []
    for m in re.finditer(r'(?:^|\n)\s*(\w+)\s*=\s*', source, re.MULTILINE):
        name = m.group(1)
        if name not in ('let', 'in', 'rec', 'with', 'if', 'then', 'else', 'or', 'and', 'true', 'false', 'null'):
            ln = _get_lines(source, m)
            symbols.append({'name': name, 'kind': 'function', 'signature': f"{name} =",
                            'start_line': ln, 'end_line': ln, 'is_exported': True})
    return symbols, calls


# ===========================================================================
# Regex fallback registry — maps language → extractor function
# ===========================================================================

_REGEX_EXTRACTORS = {
    'python':      _extract_python_regex,
    'typescript':  _extract_ts_js_regex,
    'javascript':  _extract_ts_js_regex,
    'go':          _extract_go_regex,
    'rust':        _extract_rust_regex,
    'java':        _extract_java_regex,
    'c':           _extract_c_regex,
    'cpp':         _extract_cpp_regex,
    'csharp':      _extract_csharp_regex,
    'ruby':        _extract_ruby_regex,
    'php':         _extract_php_regex,
    'swift':       _extract_swift_regex,
    'scala':       _extract_scala_regex,
    'kotlin':      _extract_kotlin_regex,
    'lua':         _extract_lua_regex,
    'sql':         _extract_sql_regex,
    'shell':       _extract_shell_regex,
    'bash':        _extract_shell_regex,
    'powershell':  _extract_powershell_regex,
    'html':        _extract_html_regex,
    'xml':         _extract_xml_regex,
    'css':         _extract_css_regex,
    'scss':        _extract_css_regex,
    'less':        _extract_css_regex,
    'json':        _extract_json_regex,
    'yaml':        _extract_yaml_regex,
    'toml':        _extract_toml_regex,
    'ini':         _extract_ini_regex,
    'env':         _extract_env_regex,
    'markdown':    _extract_markdown_regex,
    'dockerfile':  _extract_dockerfile_regex,
    'terraform':   _extract_terraform_regex,
    'hcl':         _extract_terraform_regex,
    'graphql':     _extract_graphql_regex,
    'protobuf':    _extract_protobuf_regex,
    'haskell':     _extract_haskell_regex,
    'ocaml':       _extract_ocaml_regex,
    'elixir':      _extract_elixir_regex,
    'erlang':      _extract_erlang_regex,
    'elm':         _extract_elm_regex,
    'clojure':     _extract_clojure_regex,
    'dart':        _extract_dart_regex,
    'zig':         _extract_zig_regex,
    'solidity':    _extract_solidity_regex,
    'svelte':      _extract_svelte_regex,
    'vue':         _extract_vue_regex,
    'astro':       _extract_astro_regex,
    'prisma':      _extract_prisma_regex,
    'move':        _extract_move_regex,
    'nim':         _extract_nim_regex,
    'r':           _extract_r_regex,
    'makefile':    _extract_makefile_regex,
    'cmake':       _extract_cmake_regex,
    'bazel':       _extract_bazel_regex,
    'just':        _extract_just_regex,
    'nix':         _extract_nix_regex,
}


# ===========================================================================
# Public API
# ===========================================================================

SUPPORTED_LANGUAGES = set(_REGEX_EXTRACTORS.keys())


def _get_grammar(language: str):
    """Lazily import and cache a tree-sitter grammar for a language.

    Returns the grammar module or None if not installed / import failed.
    Each language is attempted independently — a missing Go grammar
    does not prevent Python parsing.
    """
    if language in _GRAMMAR_CACHE:
        return _GRAMMAR_CACHE[language]

    if language in _GRAMMAR_CHECKED:
        return None

    _GRAMMAR_CHECKED.add(language)
    packages = _GRAMMAR_IMPORT_MAP.get(language)
    if not packages:
        return None

    for pkg in packages:
        try:
            mod = __import__(pkg)
            _GRAMMAR_CACHE[language] = mod
            # Share cache for aliases
            if language == 'typescript':
                _GRAMMAR_CACHE['javascript'] = mod
            elif language == 'javascript':
                _GRAMMAR_CACHE['typescript'] = mod
            elif language == 'shell':
                _GRAMMAR_CACHE['bash'] = mod
            elif language == 'bash':
                _GRAMMAR_CACHE['shell'] = mod
            elif language in ('scss', 'less'):
                _GRAMMAR_CACHE['css'] = mod
            elif language == 'hcl':
                _GRAMMAR_CACHE['terraform'] = mod
            elif language == 'terraform':
                _GRAMMAR_CACHE['hcl'] = mod
            return mod
        except ImportError:
            continue

    return None


def _resolve_language_obj(grammar_mod, language: str = '') -> Any:
    """Resolve the tree-sitter Language object from a grammar module.

    Tries multiple API patterns across tree-sitter versions.
    """
    # Pattern 1: language() function (tree-sitter 0.22+ grammars)
    lang_callable = getattr(grammar_mod, 'language', None)
    if callable(lang_callable):
        try:
            result = lang_callable()
            if result is not None:
                return result
        except Exception:
            pass

    # Pattern 1.5: language_{name}() named callable
    if language:
        for attr_name in (f'language_{language}',):
            named_fn = getattr(grammar_mod, attr_name, None)
            if callable(named_fn):
                try:
                    result = named_fn()
                    if result is not None:
                        return result
                except Exception:
                    pass

    # Pattern 2: .language as an attribute (not callable)
    lang_attr = getattr(grammar_mod, 'language', None)
    if lang_attr is not None and not callable(lang_attr):
        return lang_attr

    # Pattern 3: tree_sitter.Language constructor
    if tree_sitter and hasattr(tree_sitter, 'Language'):
        try:
            return tree_sitter.Language(grammar_mod)
        except Exception:
            pass

    return None


def parse_file(file_path: str, language: str) -> tuple[list[dict], list[dict]]:
    """Parse a source file and extract symbols and call edges.

    Returns:
        (symbols, calls) where:
        - symbols: list of dicts with name, kind, signature, start_line, end_line,
          is_exported, security_sensitive, has_side_effects
        - calls: list of dicts with callee_name, call_line, is_dynamic, confidence
    """
    if language not in SUPPORTED_LANGUAGES:
        return [], []

    # Read the file — try UTF-8 first, fall back to latin-1
    source = None
    for encoding in ('utf-8', 'latin-1'):
        try:
            with open(file_path, 'r', encoding=encoding, errors='replace') as f:
                source = f.read()
            break
        except (OSError, IOError, UnicodeError):
            continue

    if source is None:
        return [], []

    if not source.strip():
        return [], []

    # Tree-sitter parse (with size guard)
    file_size = os.path.getsize(file_path) if os.path.exists(file_path) else len(source)
    if HAS_TREE_SITTER and file_size <= MAX_TREE_SITTER_BYTES:
        try:
            symbols, calls = _parse_with_tree_sitter(source, language)
            if symbols or calls:
                return symbols, calls
        except MemoryError:
            raise
        except KeyboardInterrupt:
            raise
        except Exception:
            pass

    # Regex fallback
    extractor = _REGEX_EXTRACTORS.get(language)
    if extractor:
        try:
            symbols, calls = extractor(source, file_path)
            symbols = _annotate_symbols(symbols, source, language)
            return symbols, calls
        except MemoryError:
            raise
        except KeyboardInterrupt:
            raise
        except Exception:
            return [], []

    return [], []


def _parse_with_tree_sitter(source: str, language: str) -> tuple[list[dict], list[dict]]:
    """Parse source using tree-sitter. Returns empty lists on any failure.

    All exceptions except MemoryError/KeyboardInterrupt are caught and
    result in empty return (caller falls back to regex).
    """
    if tree_sitter is None:
        return [], []

    grammar_mod = _get_grammar(language)
    if grammar_mod is None:
        return [], []

    lang_obj = _resolve_language_obj(grammar_mod, language)
    if lang_obj is None:
        return [], []

    # Build parser — try multiple API patterns for version mismatch tolerance
    parser = None
    ts_language = None

    # Attempt 1: use lang_obj directly
    try:
        parser = tree_sitter.Parser()
        parser.set_language(lang_obj)
        ts_language = lang_obj
    except Exception:
        pass

    # Attempt 2: wrap as tree_sitter.Language(ptr, name) if lang_obj is int-like
    if parser is None:
        try:
            ptr_int = int(lang_obj)  # type: ignore
            ts_language = tree_sitter.Language(ptr_int, language)
            parser = tree_sitter.Parser()
            parser.set_language(ts_language)
        except Exception:
            pass

    # Attempt 3: load from the grammar package's shared library
    if parser is None:
        try:
            pkg_dir = os.path.dirname(grammar_mod.__file__)
            for entry in os.listdir(pkg_dir):
                if entry.endswith(('.pyd', '.so', '.dll', '.dylib')):
                    binding_path = os.path.join(pkg_dir, entry)
                    ts_language = tree_sitter.Language(binding_path, language)
                    parser = tree_sitter.Parser()
                    parser.set_language(ts_language)
                    break
        except Exception:
            pass

    if parser is None or ts_language is None:
        return [], []

    # Parse
    try:
        source_bytes = source.encode('utf-8')
    except (UnicodeEncodeError, UnicodeDecodeError):
        return [], []

    if len(source_bytes) > MAX_TREE_SITTER_BYTES:
        return [], []

    try:
        tree = parser.parse(source_bytes)
    except Exception:
        return [], []

    # Run query
    query_str = LANGUAGE_QUERIES.get(language)
    if not query_str:
        return [], []

    try:
        query = tree_sitter.Query(ts_language, query_str)
        captures = query.captures(tree.root_node)
    except Exception:
        return [], []

    try:
        return _process_tree_sitter_captures(captures, source, tree)
    except MemoryError:
        raise
    except KeyboardInterrupt:
        raise
    except Exception:
        return [], []


def _process_tree_sitter_captures(
    captures: list, source: str, tree: Any
) -> tuple[list[dict], list[dict]]:
    """Process tree-sitter query captures into symbol and call lists."""
    symbols = {}
    calls = []

    for capture_name, nodes in _group_captures(captures).items():
        for node in nodes:
            start_line = node.start_point[0] + 1
            end_line = node.end_point[0] + 1

            if capture_name in ('function.def', 'function.arrow'):
                name_node = node.child_by_field_name('name')
                name = source[name_node.start_byte:name_node.end_byte] if name_node else 'anonymous'
                symbols[f"func:{name}:{start_line}"] = {
                    'name': name, 'kind': 'function',
                    'signature': source[node.start_byte:node.start_byte + min(100, node.end_byte - node.start_byte)].split('\n')[0].strip(),
                    'start_line': start_line, 'end_line': end_line,
                    'is_exported': not name.startswith('_'),
                }

            elif capture_name == 'class.def':
                name_node = node.child_by_field_name('name')
                name = source[name_node.start_byte:name_node.end_byte] if name_node else 'anonymous'
                symbols[f"class:{name}:{start_line}"] = {
                    'name': name, 'kind': 'class',
                    'signature': source[node.start_byte:node.start_byte + min(80, node.end_byte - node.start_byte)].split('\n')[0].strip(),
                    'start_line': start_line, 'end_line': end_line,
                    'is_exported': not name.startswith('_'),
                }

            elif capture_name in ('call.expr', 'call.method'):
                name = source[node.start_byte:node.end_byte]
                callee = None
                if capture_name == 'call.expr':
                    name_child = node.child_by_field_name('function')
                    if name_child:
                        callee = source[name_child.start_byte:name_child.end_byte]
                else:
                    method_child = node.child_by_field_name('field') or node.child_by_field_name('property')
                    if method_child:
                        callee = source[method_child.start_byte:method_child.end_byte]

                if callee:
                    calls.append({
                        'callee_name': callee, 'call_line': start_line,
                        'is_dynamic': False, 'confidence': 0.9,
                    })

    return list(symbols.values()), calls


def _group_captures(captures: list) -> dict[str, list]:
    """Group tree-sitter captures by capture name."""
    groups = {}
    for capture in captures:
        if isinstance(capture, tuple) and len(capture) == 2:
            node, name = capture
        else:
            continue
        if name not in groups:
            groups[name] = []
        groups[name].append(node)
    return groups


def _annotate_symbols(symbols: list[dict], source: str, language: str) -> list[dict]:
    """Annotate symbols with security sensitivity and side effect heuristics."""
    security_keywords = {
        'auth', 'token', 'password', 'secret', 'credential', 'api_key',
        'session', 'jwt', 'oauth', 'login', 'logout', 'permission',
        'encrypt', 'decrypt', 'hash', 'salt', 'private_key', 'certificate',
        'csrf', 'cors', 'sanitize', 'validate_input', 'authorization',
    }
    side_effect_keywords = {
        'write', 'save', 'create', 'update', 'delete', 'remove', 'insert',
        'send', 'post', 'put', 'patch', 'dispatch', 'emit', 'publish',
        'commit', 'rollback', 'execute', 'mutate', 'modify',
    }
    io_keywords = {
        'read', 'open', 'close', 'connect', 'fetch', 'request', 'download',
        'upload', 'stream', 'pipe', 'listen', 'accept', 'dial',
    }

    for sym in symbols:
        name_lower = sym['name'].lower()
        sym['security_sensitive'] = any(kw in name_lower for kw in security_keywords)
        sym['has_side_effects'] = (
            any(kw in name_lower for kw in side_effect_keywords) or
            any(kw in name_lower for kw in io_keywords)
        )

    return symbols


def get_security_sensitive_symbols(symbols: list[dict]) -> list[dict]:
    """Filter symbols that are security-sensitive."""
    return [s for s in symbols if s.get('security_sensitive')]


def get_exported_symbols(symbols: list[dict]) -> list[dict]:
    """Filter symbols that are exported/public."""
    return [s for s in symbols if s.get('is_exported')]
