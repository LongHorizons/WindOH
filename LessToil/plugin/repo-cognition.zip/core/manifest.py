"""SQLite schema and CRUD operations for the repository cognition index."""

from __future__ import annotations

import sqlite3
import os
import json
from datetime import datetime, timezone

from . import DB_PATH, INDEX_DIR

SCHEMA_VERSION = 3

DDL = """
CREATE TABLE IF NOT EXISTS files (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    file_path TEXT UNIQUE NOT NULL,
    sha256 TEXT NOT NULL,
    language TEXT NOT NULL,
    file_size INTEGER NOT NULL,
    line_count INTEGER DEFAULT 0,
    last_indexed_at TEXT NOT NULL,
    index_version INTEGER DEFAULT 1,
    domain_confidence_sum REAL DEFAULT 0.0,
    architectural_drift_score REAL DEFAULT 0.0
);

CREATE TABLE IF NOT EXISTS symbols (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    file_id INTEGER NOT NULL REFERENCES files(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    kind TEXT NOT NULL,
    signature TEXT,
    start_line INTEGER,
    end_line INTEGER,
    docstring TEXT,
    is_exported INTEGER DEFAULT 0,
    security_sensitive INTEGER DEFAULT 0,
    has_side_effects INTEGER DEFAULT 0,
    confidence_score REAL DEFAULT 0.5,
    UNIQUE(file_id, name, kind, start_line)
);

CREATE TABLE IF NOT EXISTS call_edges (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    caller_id INTEGER NOT NULL REFERENCES symbols(id) ON DELETE CASCADE,
    callee_name TEXT NOT NULL,
    callee_symbol_id INTEGER REFERENCES symbols(id),
    callee_file TEXT,
    call_line INTEGER,
    is_dynamic INTEGER DEFAULT 0,
    confidence REAL DEFAULT 1.0
);

CREATE TABLE IF NOT EXISTS domains (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    description TEXT,
    entry_points TEXT,
    security_boundary INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS file_domains (
    file_id INTEGER NOT NULL REFERENCES files(id) ON DELETE CASCADE,
    domain_id INTEGER NOT NULL REFERENCES domains(id) ON DELETE CASCADE,
    confidence REAL DEFAULT 0.5,
    PRIMARY KEY (file_id, domain_id)
);

CREATE TABLE IF NOT EXISTS similarity_groups (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    simhash TEXT NOT NULL,
    file_path TEXT NOT NULL,
    symbol_name TEXT,
    start_line INTEGER,
    end_line INTEGER,
    normalized_code TEXT,
    language TEXT
);

CREATE TABLE IF NOT EXISTS confidence_scores (
    symbol_id INTEGER PRIMARY KEY REFERENCES symbols(id) ON DELETE CASCADE,
    parser_confidence REAL DEFAULT 0.0,
    type_confidence REAL DEFAULT 0.0,
    runtime_confidence REAL DEFAULT 0.0,
    inferred_purpose_confidence REAL DEFAULT 0.0,
    aggregate_confidence REAL DEFAULT 0.0,
    assessed_at TEXT,
    assessed_by TEXT
);

CREATE TABLE IF NOT EXISTS temporal_metadata (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    head_hash TEXT NOT NULL,
    computed_at TEXT
);

CREATE TABLE IF NOT EXISTS temporal_metrics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    file_path TEXT UNIQUE NOT NULL,
    total_commits INTEGER DEFAULT 0,
    bug_fix_commits INTEGER DEFAULT 0,
    security_patch_commits INTEGER DEFAULT 0,
    distinct_authors INTEGER DEFAULT 0,
    first_commit_date TEXT,
    last_commit_date TEXT,
    churn_rate REAL DEFAULT 0.0,
    bug_density REAL DEFAULT 0.0,
    security_density REAL DEFAULT 0.0,
    ownership_volatility REAL DEFAULT 0.0,
    instability REAL DEFAULT 0.0,
    risk_score REAL DEFAULT 0.0
);

CREATE TABLE IF NOT EXISTS temporal_change_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    file_path TEXT NOT NULL,
    changed_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS invariants (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    description TEXT,
    query TEXT NOT NULL,
    severity TEXT DEFAULT 'error',
    enabled INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS invariant_violations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    invariant_id INTEGER NOT NULL REFERENCES invariants(id) ON DELETE CASCADE,
    file_path TEXT,
    detail TEXT,
    detected_at TEXT DEFAULT (datetime('now')),
    resolved_at TEXT,
    session_id TEXT
);

CREATE TABLE IF NOT EXISTS policies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    category TEXT DEFAULT 'general',
    description TEXT,
    threshold_value REAL DEFAULT 0,
    severity TEXT DEFAULT 'warning',
    enabled INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS policy_violations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    policy_id INTEGER NOT NULL REFERENCES policies(id) ON DELETE CASCADE,
    file_path TEXT,
    detail TEXT,
    detected_at TEXT DEFAULT (datetime('now')),
    resolved_at TEXT,
    session_id TEXT
);

CREATE TABLE IF NOT EXISTS taint_sources (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    file_id INTEGER NOT NULL REFERENCES files(id) ON DELETE CASCADE,
    line_number INTEGER,
    category TEXT DEFAULT 'other',
    source_text TEXT,
    matched_text TEXT
);

CREATE TABLE IF NOT EXISTS taint_flows (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_id INTEGER NOT NULL REFERENCES symbols(id) ON DELETE CASCADE,
    target_id INTEGER NOT NULL REFERENCES symbols(id) ON DELETE CASCADE,
    depth INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS profile_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    label TEXT DEFAULT 'manual',
    profile_data TEXT,
    captured_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS stewardship_suggestions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    category TEXT NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    file_path TEXT,
    severity TEXT DEFAULT 'medium',
    estimated_effort TEXT DEFAULT 'medium',
    justification TEXT,
    detected_at TEXT DEFAULT (datetime('now')),
    resolved_at TEXT
);

CREATE TABLE IF NOT EXISTS evidence_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    inference_id TEXT NOT NULL,
    inference_type TEXT NOT NULL,
    target TEXT NOT NULL,
    source_method TEXT,
    source_data_hash TEXT,
    confidence REAL DEFAULT 0.5,
    assumptions TEXT,
    contradictions TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    expires_at TEXT
);

CREATE TABLE IF NOT EXISTS evidence_dependencies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    inference_id TEXT NOT NULL,
    depends_on_inference_id TEXT NOT NULL,
    relationship TEXT DEFAULT 'supports'
);

CREATE TABLE IF NOT EXISTS contradictions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    inference_a_id TEXT NOT NULL,
    inference_b_id TEXT NOT NULL,
    target TEXT,
    detail TEXT,
    detected_at TEXT DEFAULT (datetime('now')),
    resolved_at TEXT
);

CREATE TABLE IF NOT EXISTS intent_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol_name TEXT NOT NULL,
    intent_category TEXT NOT NULL,
    rationale TEXT,
    constraints TEXT,
    created_by TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT
);

CREATE TABLE IF NOT EXISTS toolchain_audit (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tool_name TEXT NOT NULL,
    file_paths TEXT,
    session_id TEXT,
    verification_result TEXT,
    consensus_result TEXT,
    approved INTEGER DEFAULT 0,
    overridden INTEGER DEFAULT 0,
    recorded_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS immune_baselines (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    label TEXT NOT NULL,
    baseline_data TEXT,
    captured_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS immune_alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    signal_type TEXT NOT NULL,
    severity TEXT DEFAULT 'medium',
    affected_scope TEXT,
    description TEXT,
    baseline_value TEXT,
    current_value TEXT,
    detected_at TEXT DEFAULT (datetime('now')),
    resolved_at TEXT
);

CREATE TABLE IF NOT EXISTS schema_version (
    version INTEGER PRIMARY KEY
);

CREATE INDEX IF NOT EXISTS idx_files_language ON files(language);
CREATE INDEX IF NOT EXISTS idx_files_sha256 ON files(sha256);
CREATE INDEX IF NOT EXISTS idx_files_path ON files(file_path);
CREATE INDEX IF NOT EXISTS idx_symbols_name ON symbols(name);
CREATE INDEX IF NOT EXISTS idx_symbols_file ON symbols(file_id);
CREATE INDEX IF NOT EXISTS idx_symbols_kind ON symbols(kind);
CREATE INDEX IF NOT EXISTS idx_call_edges_caller ON call_edges(caller_id);
CREATE INDEX IF NOT EXISTS idx_call_edges_callee ON call_edges(callee_name);
CREATE INDEX IF NOT EXISTS idx_similarity_simhash ON similarity_groups(simhash);
CREATE INDEX IF NOT EXISTS idx_similarity_path ON similarity_groups(file_path);
CREATE INDEX IF NOT EXISTS idx_file_domains_file ON file_domains(file_id);
CREATE INDEX IF NOT EXISTS idx_file_domains_domain ON file_domains(domain_id);
CREATE INDEX IF NOT EXISTS idx_confidence_symbol ON confidence_scores(symbol_id);
CREATE INDEX IF NOT EXISTS idx_confidence_aggregate ON confidence_scores(aggregate_confidence);
CREATE INDEX IF NOT EXISTS idx_symbols_confidence ON symbols(confidence_score);
CREATE INDEX IF NOT EXISTS idx_call_edges_callee_sym ON call_edges(callee_symbol_id);
CREATE INDEX IF NOT EXISTS idx_temporal_risk ON temporal_metrics(risk_score);
CREATE INDEX IF NOT EXISTS idx_temporal_path ON temporal_metrics(file_path);
CREATE INDEX IF NOT EXISTS idx_temporal_change_log_path ON temporal_change_log(file_path);
CREATE INDEX IF NOT EXISTS idx_invariants_enabled ON invariants(enabled);
CREATE INDEX IF NOT EXISTS idx_invariant_violations_unresolved ON invariant_violations(resolved_at);
CREATE INDEX IF NOT EXISTS idx_policies_enabled ON policies(enabled);
CREATE INDEX IF NOT EXISTS idx_policy_violations_unresolved ON policy_violations(resolved_at);
CREATE INDEX IF NOT EXISTS idx_taint_sources_file ON taint_sources(file_id);
CREATE INDEX IF NOT EXISTS idx_taint_flows_source ON taint_flows(source_id);
CREATE INDEX IF NOT EXISTS idx_taint_flows_target ON taint_flows(target_id);
CREATE INDEX IF NOT EXISTS idx_stewardship_category ON stewardship_suggestions(category);
CREATE INDEX IF NOT EXISTS idx_stewardship_severity ON stewardship_suggestions(severity);
CREATE INDEX IF NOT EXISTS idx_stewardship_resolved ON stewardship_suggestions(resolved_at);
CREATE INDEX IF NOT EXISTS idx_evidence_inference ON evidence_records(inference_id);
CREATE INDEX IF NOT EXISTS idx_evidence_target ON evidence_records(target);
CREATE INDEX IF NOT EXISTS idx_evidence_type ON evidence_records(inference_type);
CREATE INDEX IF NOT EXISTS idx_evidence_dep_inference ON evidence_dependencies(inference_id);
CREATE INDEX IF NOT EXISTS idx_contradictions_target ON contradictions(target);
CREATE INDEX IF NOT EXISTS idx_contradictions_resolved ON contradictions(resolved_at);
CREATE INDEX IF NOT EXISTS idx_immune_alerts_type ON immune_alerts(signal_type);
CREATE INDEX IF NOT EXISTS idx_immune_alerts_severity ON immune_alerts(severity);
CREATE INDEX IF NOT EXISTS idx_immune_alerts_resolved ON immune_alerts(resolved_at);
CREATE INDEX IF NOT EXISTS idx_intent_records_symbol ON intent_records(symbol_name);
CREATE INDEX IF NOT EXISTS idx_intent_records_category ON intent_records(intent_category);
CREATE INDEX IF NOT EXISTS idx_toolchain_audit_tool ON toolchain_audit(tool_name);
CREATE INDEX IF NOT EXISTS idx_toolchain_audit_session ON toolchain_audit(session_id);
"""


def get_connection() -> sqlite3.Connection:
    """Get a connection to the index database with WAL mode enabled."""
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db() -> None:
    """Initialize the database schema. Idempotent with migration support."""
    conn = get_connection()
    try:
        conn.executescript(DDL)
        cur = conn.execute("SELECT version FROM schema_version")
        row = cur.fetchone()
        if row is None:
            conn.execute("INSERT INTO schema_version (version) VALUES (?)", (SCHEMA_VERSION,))
            conn.commit()
        else:
            current_version = row[0]
            if current_version < SCHEMA_VERSION:
                _migrate_schema(conn, current_version)
        conn.commit()
    finally:
        conn.close()


def _migrate_schema(conn, from_version: int) -> None:
    """Migrate schema from an older version to current."""
    if from_version < 2:
        # v1 → v2: add confidence_scores, temporal, governance tables, new columns
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS confidence_scores (
                symbol_id INTEGER PRIMARY KEY REFERENCES symbols(id) ON DELETE CASCADE,
                parser_confidence REAL DEFAULT 0.0,
                type_confidence REAL DEFAULT 0.0,
                runtime_confidence REAL DEFAULT 0.0,
                inferred_purpose_confidence REAL DEFAULT 0.0,
                aggregate_confidence REAL DEFAULT 0.0,
                assessed_at TEXT,
                assessed_by TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_confidence_symbol ON confidence_scores(symbol_id);
            CREATE INDEX IF NOT EXISTS idx_confidence_aggregate ON confidence_scores(aggregate_confidence);
            CREATE INDEX IF NOT EXISTS idx_symbols_confidence ON symbols(confidence_score);
            CREATE INDEX IF NOT EXISTS idx_call_edges_callee_sym ON call_edges(callee_symbol_id);
            CREATE TABLE IF NOT EXISTS temporal_metadata (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                head_hash TEXT NOT NULL,
                computed_at TEXT
            );
            CREATE TABLE IF NOT EXISTS temporal_metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                file_path TEXT UNIQUE NOT NULL,
                total_commits INTEGER DEFAULT 0,
                bug_fix_commits INTEGER DEFAULT 0,
                security_patch_commits INTEGER DEFAULT 0,
                distinct_authors INTEGER DEFAULT 0,
                first_commit_date TEXT,
                last_commit_date TEXT,
                churn_rate REAL DEFAULT 0.0,
                bug_density REAL DEFAULT 0.0,
                security_density REAL DEFAULT 0.0,
                ownership_volatility REAL DEFAULT 0.0,
                instability REAL DEFAULT 0.0,
                risk_score REAL DEFAULT 0.0
            );
            CREATE TABLE IF NOT EXISTS temporal_change_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                file_path TEXT NOT NULL,
                changed_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_temporal_risk ON temporal_metrics(risk_score);
            CREATE INDEX IF NOT EXISTS idx_temporal_path ON temporal_metrics(file_path);
            CREATE INDEX IF NOT EXISTS idx_temporal_change_log_path ON temporal_change_log(file_path);
            CREATE TABLE IF NOT EXISTS invariants (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL,
                description TEXT,
                query TEXT NOT NULL,
                severity TEXT DEFAULT 'error',
                enabled INTEGER DEFAULT 1
            );
            CREATE TABLE IF NOT EXISTS invariant_violations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                invariant_id INTEGER NOT NULL REFERENCES invariants(id) ON DELETE CASCADE,
                file_path TEXT,
                detail TEXT,
                detected_at TEXT DEFAULT (datetime('now')),
                resolved_at TEXT,
                session_id TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_invariants_enabled ON invariants(enabled);
            CREATE INDEX IF NOT EXISTS idx_invariant_violations_unresolved ON invariant_violations(resolved_at);
            CREATE TABLE IF NOT EXISTS policies (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL,
                category TEXT DEFAULT 'general',
                description TEXT,
                threshold_value REAL DEFAULT 0,
                severity TEXT DEFAULT 'warning',
                enabled INTEGER DEFAULT 1
            );
            CREATE TABLE IF NOT EXISTS policy_violations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                policy_id INTEGER NOT NULL REFERENCES policies(id) ON DELETE CASCADE,
                file_path TEXT,
                detail TEXT,
                detected_at TEXT DEFAULT (datetime('now')),
                resolved_at TEXT,
                session_id TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_policies_enabled ON policies(enabled);
            CREATE INDEX IF NOT EXISTS idx_policy_violations_unresolved ON policy_violations(resolved_at);
            CREATE TABLE IF NOT EXISTS taint_sources (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                file_id INTEGER NOT NULL REFERENCES files(id) ON DELETE CASCADE,
                line_number INTEGER,
                category TEXT DEFAULT 'other',
                source_text TEXT,
                matched_text TEXT
            );
            CREATE TABLE IF NOT EXISTS taint_flows (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_id INTEGER NOT NULL REFERENCES symbols(id) ON DELETE CASCADE,
                target_id INTEGER NOT NULL REFERENCES symbols(id) ON DELETE CASCADE,
                depth INTEGER DEFAULT 0
            );
            CREATE INDEX IF NOT EXISTS idx_taint_sources_file ON taint_sources(file_id);
            CREATE INDEX IF NOT EXISTS idx_taint_flows_source ON taint_flows(source_id);
            CREATE INDEX IF NOT EXISTS idx_taint_flows_target ON taint_flows(target_id);
            CREATE TABLE IF NOT EXISTS profile_snapshots (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                label TEXT DEFAULT 'manual',
                profile_data TEXT,
                captured_at TEXT DEFAULT (datetime('now'))
            );
        """)
        # Add new columns (SQLite ALTER TABLE only supports ADD COLUMN)
        _add_column_if_missing(conn, 'symbols', 'confidence_score', 'REAL DEFAULT 0.5')
        _add_column_if_missing(conn, 'files', 'domain_confidence_sum', 'REAL DEFAULT 0.0')
        _add_column_if_missing(conn, 'files', 'architectural_drift_score', 'REAL DEFAULT 0.0')
        _add_column_if_missing(conn, 'call_edges', 'callee_symbol_id', 'INTEGER REFERENCES symbols(id)')

    if from_version < 3:
        # v2 → v3: add stewardship, evidence, and epistemic tables
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS stewardship_suggestions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                category TEXT NOT NULL,
                title TEXT NOT NULL,
                description TEXT,
                file_path TEXT,
                severity TEXT DEFAULT 'medium',
                estimated_effort TEXT DEFAULT 'medium',
                justification TEXT,
                detected_at TEXT DEFAULT (datetime('now')),
                resolved_at TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_stewardship_category ON stewardship_suggestions(category);
            CREATE INDEX IF NOT EXISTS idx_stewardship_severity ON stewardship_suggestions(severity);
            CREATE INDEX IF NOT EXISTS idx_stewardship_resolved ON stewardship_suggestions(resolved_at);
            CREATE TABLE IF NOT EXISTS evidence_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                inference_id TEXT NOT NULL,
                inference_type TEXT NOT NULL,
                target TEXT NOT NULL,
                source_method TEXT,
                source_data_hash TEXT,
                confidence REAL DEFAULT 0.5,
                assumptions TEXT,
                contradictions TEXT,
                created_at TEXT DEFAULT (datetime('now')),
                expires_at TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_evidence_inference ON evidence_records(inference_id);
            CREATE INDEX IF NOT EXISTS idx_evidence_target ON evidence_records(target);
            CREATE INDEX IF NOT EXISTS idx_evidence_type ON evidence_records(inference_type);
            CREATE TABLE IF NOT EXISTS evidence_dependencies (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                inference_id TEXT NOT NULL,
                depends_on_inference_id TEXT NOT NULL,
                relationship TEXT DEFAULT 'supports'
            );
            CREATE INDEX IF NOT EXISTS idx_evidence_dep_inference ON evidence_dependencies(inference_id);
            CREATE TABLE IF NOT EXISTS contradictions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                inference_a_id TEXT NOT NULL,
                inference_b_id TEXT NOT NULL,
                target TEXT,
                detail TEXT,
                detected_at TEXT DEFAULT (datetime('now')),
                resolved_at TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_contradictions_target ON contradictions(target);
            CREATE INDEX IF NOT EXISTS idx_contradictions_resolved ON contradictions(resolved_at);
            CREATE TABLE IF NOT EXISTS immune_baselines (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                label TEXT NOT NULL,
                baseline_data TEXT,
                captured_at TEXT DEFAULT (datetime('now'))
            );
            CREATE TABLE IF NOT EXISTS immune_alerts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                signal_type TEXT NOT NULL,
                severity TEXT DEFAULT 'medium',
                affected_scope TEXT,
                description TEXT,
                baseline_value TEXT,
                current_value TEXT,
                detected_at TEXT DEFAULT (datetime('now')),
                resolved_at TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_immune_alerts_type ON immune_alerts(signal_type);
            CREATE INDEX IF NOT EXISTS idx_immune_alerts_severity ON immune_alerts(severity);
            CREATE INDEX IF NOT EXISTS idx_immune_alerts_resolved ON immune_alerts(resolved_at);
            CREATE TABLE IF NOT EXISTS intent_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                symbol_name TEXT NOT NULL,
                intent_category TEXT NOT NULL,
                rationale TEXT,
                constraints TEXT,
                created_by TEXT,
                created_at TEXT DEFAULT (datetime('now')),
                updated_at TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_intent_records_symbol ON intent_records(symbol_name);
            CREATE INDEX IF NOT EXISTS idx_intent_records_category ON intent_records(intent_category);
            CREATE TABLE IF NOT EXISTS toolchain_audit (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                tool_name TEXT NOT NULL,
                file_paths TEXT,
                session_id TEXT,
                verification_result TEXT,
                consensus_result TEXT,
                approved INTEGER DEFAULT 0,
                overridden INTEGER DEFAULT 0,
                recorded_at TEXT DEFAULT (datetime('now'))
            );
            CREATE INDEX IF NOT EXISTS idx_toolchain_audit_tool ON toolchain_audit(tool_name);
            CREATE INDEX IF NOT EXISTS idx_toolchain_audit_session ON toolchain_audit(session_id);
        """)

    conn.execute("UPDATE schema_version SET version = ?", (SCHEMA_VERSION,))


def _add_column_if_missing(conn, table: str, column: str, col_type: str) -> None:
    """Add a column if it does not already exist in the table."""
    cur = conn.execute(f"PRAGMA table_info({table})")
    existing = {row[1] for row in cur.fetchall()}
    if column not in existing:
        conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {col_type}")


def upsert_file(file_path: str, sha256: str, language: str, file_size: int,
                line_count: int = 0) -> int:
    """Insert or update a file entry. Returns the file's row id."""
    conn = get_connection()
    try:
        now = datetime.now(timezone.utc).isoformat()
        cur = conn.execute(
            """INSERT INTO files (file_path, sha256, language, file_size, line_count, last_indexed_at)
               VALUES (?, ?, ?, ?, ?, ?)
               ON CONFLICT(file_path) DO UPDATE SET
                   sha256=excluded.sha256,
                   language=excluded.language,
                   file_size=excluded.file_size,
                   line_count=excluded.line_count,
                   last_indexed_at=excluded.last_indexed_at,
                   index_version=excluded.index_version + 1""",
            (file_path, sha256, language, file_size, line_count, now)
        )
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


def delete_file(file_path: str) -> None:
    """Remove a file and all its associated data (cascading)."""
    conn = get_connection()
    try:
        conn.execute("DELETE FROM files WHERE file_path = ?", (file_path,))
        conn.commit()
    finally:
        conn.close()


def get_file(file_path: str) -> dict | None:
    """Retrieve a single file entry by path."""
    conn = get_connection()
    try:
        cur = conn.execute(
            "SELECT id, file_path, sha256, language, file_size, line_count, last_indexed_at "
            "FROM files WHERE file_path = ?", (file_path,)
        )
        row = cur.fetchone()
        if row is None:
            return None
        return {
            "id": row[0], "file_path": row[1], "sha256": row[2],
            "language": row[3], "file_size": row[4], "line_count": row[5],
            "last_indexed_at": row[6]
        }
    finally:
        conn.close()


def get_files_by_language(language: str) -> list[dict]:
    """Return all files of a given language."""
    conn = get_connection()
    try:
        cur = conn.execute(
            "SELECT file_path, sha256, language, file_size, line_count, last_indexed_at "
            "FROM files WHERE language = ? ORDER BY file_path", (language,)
        )
        return [
            {"file_path": r[0], "sha256": r[1], "language": r[2],
             "file_size": r[3], "line_count": r[4], "last_indexed_at": r[5]}
            for r in cur.fetchall()
        ]
    finally:
        conn.close()


def get_stats() -> dict:
    """Return overall index statistics."""
    conn = get_connection()
    try:
        file_count = conn.execute("SELECT COUNT(*) FROM files").fetchone()[0]
        total_size = conn.execute("SELECT COALESCE(SUM(file_size), 0) FROM files").fetchone()[0]
        symbol_count = conn.execute("SELECT COUNT(*) FROM symbols").fetchone()[0]
        edge_count = conn.execute("SELECT COUNT(*) FROM call_edges").fetchone()[0]
        lang_counts = {}
        for row in conn.execute(
            "SELECT language, COUNT(*) FROM files GROUP BY language ORDER BY COUNT(*) DESC"
        ):
            lang_counts[row[0]] = row[1]
        last_index = None
        row = conn.execute("SELECT MAX(last_indexed_at) FROM files").fetchone()
        if row:
            last_index = row[0]
        return {
            "file_count": file_count,
            "total_size_bytes": total_size,
            "symbol_count": symbol_count,
            "edge_count": edge_count,
            "languages": lang_counts,
            "last_full_index": last_index
        }
    finally:
        conn.close()


def get_files_needing_reindex() -> list[str]:
    """Return paths of files whose SHA256 no longer matches (deleted or changed on disk).

    Uses PROJECT_DIR (not fragile relative paths) to reconstruct full file paths.
    """
    from . import PROJECT_DIR
    conn = get_connection()
    try:
        cur = conn.execute("SELECT file_path, sha256 FROM files")
        stale = []
        for file_path, stored_hash in cur.fetchall():
            # Use PROJECT_DIR instead of fragile INDEX_DIR/../.. navigation
            full_path = os.path.normpath(os.path.join(PROJECT_DIR, file_path))
            if not os.path.exists(full_path):
                stale.append(file_path)
                continue
            # Re-check hash for changed files
            import hashlib
            try:
                with open(full_path, 'rb') as f:
                    current_hash = hashlib.sha256(f.read()).hexdigest()
                if current_hash != stored_hash:
                    stale.append(file_path)
            except (OSError, IOError):
                stale.append(file_path)
        return stale
    finally:
        conn.close()


def upsert_symbols_batch(file_id: int, symbols: list[dict]) -> None:
    """Batch insert symbols for a file. Deletes existing symbols for the file first.

    Wrapped in a single transaction so a crash between DELETE and INSERT
    cannot leave the file with zero symbols (which would appear as empty index).
    """
    conn = get_connection()
    try:
        conn.execute("BEGIN IMMEDIATE")
        conn.execute("DELETE FROM symbols WHERE file_id = ?", (file_id,))
        conn.execute("DELETE FROM call_edges WHERE caller_id IN "
                      "(SELECT id FROM symbols WHERE file_id = ?)", (file_id,))
        for sym in symbols:
            conn.execute(
                """INSERT INTO symbols (file_id, name, kind, signature, start_line, end_line,
                   docstring, is_exported, security_sensitive, has_side_effects)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (file_id, sym.get("name"), sym.get("kind"), sym.get("signature"),
                 sym.get("start_line"), sym.get("end_line"), sym.get("docstring"),
                 int(sym.get("is_exported", False)), int(sym.get("security_sensitive", False)),
                 int(sym.get("has_side_effects", False)))
            )
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def insert_call_edges_batch(edges: list[dict]) -> None:
    """Batch insert call edges. Wrapped in a single transaction for atomicity."""
    if not edges:
        return
    conn = get_connection()
    try:
        conn.execute("BEGIN IMMEDIATE")
        for edge in edges:
            conn.execute(
                """INSERT INTO call_edges (caller_id, callee_name, callee_file, call_line,
                   is_dynamic, confidence)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (edge.get("caller_id"), edge.get("callee_name"), edge.get("callee_file"),
                 edge.get("call_line"), int(edge.get("is_dynamic", False)),
                 edge.get("confidence", 1.0))
            )
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def upsert_domain(name: str, description: str = "", entry_points: str = "[]",
                  security_boundary: bool = False) -> int:
    """Insert or update an architectural domain. Returns the domain id."""
    conn = get_connection()
    try:
        cur = conn.execute(
            """INSERT INTO domains (name, description, entry_points, security_boundary)
               VALUES (?, ?, ?, ?)
               ON CONFLICT(name) DO UPDATE SET
                   description=excluded.description,
                   entry_points=excluded.entry_points,
                   security_boundary=excluded.security_boundary""",
            (name, description, entry_points, int(security_boundary))
        )
        conn.commit()
        # Get the id
        cur = conn.execute("SELECT id FROM domains WHERE name = ?", (name,))
        return cur.fetchone()[0]
    finally:
        conn.close()


def set_file_domain(file_id: int, domain_id: int, confidence: float = 0.5) -> None:
    """Assign a file to a domain."""
    conn = get_connection()
    try:
        conn.execute(
            """INSERT OR REPLACE INTO file_domains (file_id, domain_id, confidence)
               VALUES (?, ?, ?)""",
            (file_id, domain_id, confidence)
        )
        conn.commit()
    finally:
        conn.close()


def get_files_by_domain(domain_name: str) -> list[dict]:
    """Return all files assigned to a domain."""
    conn = get_connection()
    try:
        cur = conn.execute(
            """SELECT f.file_path, f.language, fd.confidence
               FROM files f
               JOIN file_domains fd ON f.id = fd.file_id
               JOIN domains d ON fd.domain_id = d.id
               WHERE d.name = ?
               ORDER BY fd.confidence DESC""",
            (domain_name,)
        )
        return [
            {"file_path": r[0], "language": r[1], "confidence": r[2]}
            for r in cur.fetchall()
        ]
    finally:
        conn.close()


def get_all_domains() -> list[dict]:
    """Return all registered domains."""
    conn = get_connection()
    try:
        cur = conn.execute(
            "SELECT name, description, entry_points, security_boundary FROM domains ORDER BY name"
        )
        return [
            {"name": r[0], "description": r[1], "entry_points": json.loads(r[2]),
             "security_boundary": bool(r[3])}
            for r in cur.fetchall()
        ]
    finally:
        conn.close()


def export_manifest_json() -> list[dict]:
    """Export the file manifest as a list of dicts for file_manifest.json."""
    conn = get_connection()
    try:
        cur = conn.execute(
            "SELECT file_path, sha256, language, file_size, line_count, last_indexed_at FROM files"
        )
        return [
            {"path": r[0], "sha256": r[1], "language": r[2],
             "file_size": r[3], "line_count": r[4], "last_indexed_at": r[5]}
            for r in cur.fetchall()
        ]
    finally:
        conn.close()


def clear_all() -> None:
    """Drop and recreate all tables. Used for full rebuilds."""
    conn = get_connection()
    try:
        conn.execute("DROP TABLE IF EXISTS toolchain_audit")
        conn.execute("DROP TABLE IF EXISTS intent_records")
        conn.execute("DROP TABLE IF EXISTS immune_alerts")
        conn.execute("DROP TABLE IF EXISTS immune_baselines")
        conn.execute("DROP TABLE IF EXISTS contradictions")
        conn.execute("DROP TABLE IF EXISTS evidence_dependencies")
        conn.execute("DROP TABLE IF EXISTS evidence_records")
        conn.execute("DROP TABLE IF EXISTS stewardship_suggestions")
        conn.execute("DROP TABLE IF EXISTS profile_snapshots")
        conn.execute("DROP TABLE IF EXISTS taint_flows")
        conn.execute("DROP TABLE IF EXISTS taint_sources")
        conn.execute("DROP TABLE IF EXISTS policy_violations")
        conn.execute("DROP TABLE IF EXISTS policies")
        conn.execute("DROP TABLE IF EXISTS invariant_violations")
        conn.execute("DROP TABLE IF EXISTS invariants")
        conn.execute("DROP TABLE IF EXISTS temporal_change_log")
        conn.execute("DROP TABLE IF EXISTS temporal_metrics")
        conn.execute("DROP TABLE IF EXISTS temporal_metadata")
        conn.execute("DROP TABLE IF EXISTS confidence_scores")
        conn.execute("DROP TABLE IF EXISTS similarity_groups")
        conn.execute("DROP TABLE IF EXISTS file_domains")
        conn.execute("DROP TABLE IF EXISTS call_edges")
        conn.execute("DROP TABLE IF EXISTS symbols")
        conn.execute("DROP TABLE IF EXISTS domains")
        conn.execute("DROP TABLE IF EXISTS files")
        conn.execute("DROP TABLE IF EXISTS schema_version")
        conn.commit()
    finally:
        conn.close()
    init_db()


def verify_index_integrity() -> dict:
    """Check index integrity: foreign key consistency, orphan detection, core counts.

    Returns a dict with:
        'ok': bool — True if no issues found
        'issues': list[str] — descriptions of any problems detected
    """
    issues = []
    conn = get_connection()
    try:
        # Check schema_version table exists
        tables = conn.execute(
            "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='schema_version'"
        ).fetchone()[0]
        if tables == 0:
            return {'ok': False, 'issues': ['Schema not initialized — no tables found.']}

        # Check core tables exist
        for table in ['files', 'symbols', 'call_edges']:
            count = conn.execute(
                "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name=?", (table,)
            ).fetchone()[0]
            if count == 0:
                issues.append(f'Core table "{table}" is missing.')

        # Check foreign key consistency: symbols without valid file_id
        orphan_symbols = conn.execute(
            """SELECT COUNT(*) FROM symbols s
               WHERE NOT EXISTS (SELECT 1 FROM files f WHERE f.id = s.file_id)"""
        ).fetchone()[0]
        if orphan_symbols > 0:
            issues.append(f'{orphan_symbols} symbols reference missing files (orphan symbols).')

        # Check call edges with missing callers
        orphan_edges = conn.execute(
            """SELECT COUNT(*) FROM call_edges ce
               WHERE NOT EXISTS (SELECT 1 FROM symbols s WHERE s.id = ce.caller_id)"""
        ).fetchone()[0]
        if orphan_edges > 0:
            issues.append(f'{orphan_edges} call edges reference missing caller symbols.')

        # Check file_domains orphan references
        orphan_fd = conn.execute(
            """SELECT COUNT(*) FROM file_domains fd
               WHERE NOT EXISTS (SELECT 1 FROM files f WHERE f.id = fd.file_id)
                  OR NOT EXISTS (SELECT 1 FROM domains d WHERE d.id = fd.domain_id)"""
        ).fetchone()[0]
        if orphan_fd > 0:
            issues.append(f'{orphan_fd} file-domain assignments reference missing files or domains.')

        # Check confidence_scores orphan references
        orphan_conf = conn.execute(
            """SELECT COUNT(*) FROM confidence_scores cs
               WHERE NOT EXISTS (SELECT 1 FROM symbols s WHERE s.id = cs.symbol_id)"""
        ).fetchone()[0]
        if orphan_conf > 0:
            issues.append(f'{orphan_conf} confidence scores reference missing symbols.')

        # File count vs symbol count sanity check
        file_count = conn.execute("SELECT COUNT(*) FROM files").fetchone()[0]
        symbol_count = conn.execute("SELECT COUNT(*) FROM symbols").fetchone()[0]
        if file_count > 0 and symbol_count == 0:
            issues.append(
                f'{file_count} files indexed but 0 symbols. '
                'Indexing may have been interrupted — run /index-rebuild.'
            )

    except sqlite3.Error as e:
        return {'ok': False, 'issues': [f'SQLite error during integrity check: {e}']}
    finally:
        conn.close()

    return {'ok': len(issues) == 0, 'issues': issues}


def repair_index() -> dict:
    """Attempt to repair integrity issues. Cleans orphan records.

    Returns a dict with:
        'repaired': bool — True if any issues were repaired
        'actions': list[str] — actions taken
    """
    actions = []
    conn = get_connection()
    try:
        # Remove orphan symbols
        cur = conn.execute(
            """DELETE FROM symbols WHERE id IN (
                SELECT s.id FROM symbols s
                WHERE NOT EXISTS (SELECT 1 FROM files f WHERE f.id = s.file_id)
            )"""
        )
        if cur.rowcount > 0:
            actions.append(f'Removed {cur.rowcount} orphan symbols (missing file reference).')

        # Remove orphan call edges
        cur = conn.execute(
            """DELETE FROM call_edges WHERE id IN (
                SELECT ce.id FROM call_edges ce
                WHERE NOT EXISTS (SELECT 1 FROM symbols s WHERE s.id = ce.caller_id)
            )"""
        )
        if cur.rowcount > 0:
            actions.append(f'Removed {cur.rowcount} orphan call edges (missing caller).')

        # Remove orphan file_domains
        cur = conn.execute(
            """DELETE FROM file_domains WHERE id IN (
                SELECT fd.rowid FROM file_domains fd
                WHERE NOT EXISTS (SELECT 1 FROM files f WHERE f.id = fd.file_id)
                   OR NOT EXISTS (SELECT 1 FROM domains d WHERE d.id = fd.domain_id)
            )"""
        )
        if cur.rowcount > 0:
            actions.append(f'Removed {cur.rowcount} orphan file-domain assignments.')

        # Remove orphan confidence scores
        cur = conn.execute(
            """DELETE FROM confidence_scores WHERE symbol_id IN (
                SELECT cs.symbol_id FROM confidence_scores cs
                WHERE NOT EXISTS (SELECT 1 FROM symbols s WHERE s.id = cs.symbol_id)
            )"""
        )
        if cur.rowcount > 0:
            actions.append(f'Removed {cur.rowcount} orphan confidence scores.')

        conn.commit()
    except sqlite3.Error as e:
        conn.rollback()
        actions.append(f'Repair failed: {e}')
    finally:
        conn.close()

    return {
        'repaired': len(actions) > 0 and not any(a.startswith('Repair failed') for a in actions),
        'actions': actions,
    }
