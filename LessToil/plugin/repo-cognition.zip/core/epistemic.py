"""Epistemic Awareness — evidence provenance and contradiction tracking.

Every inference tracks: what evidence supports it, what method produced it,
what assumptions it depends on, what contradicts it. This enables the system
to know not just WHAT it believes, but WHY — and to detect when beliefs conflict.
"""

from __future__ import annotations

import json
import uuid
from dataclasses import dataclass, field
from typing import Optional

from .manifest import get_connection


@dataclass
class EvidenceRecord:
    inference_id: str = ''
    inference_type: str = ''
    target: str = ''
    source_method: str = ''
    source_data_hash: str = ''
    confidence: float = 0.5
    assumptions: list[str] = field(default_factory=list)
    contradictions: list[str] = field(default_factory=list)
    created_at: str = ''
    expires_at: str = ''


def track_inference(inference_type: str, target: str, source_method: str,
                    source_data: str = '', confidence: float = 0.5,
                    assumptions: list[str] | None = None,
                    dependencies: list[str] | None = None) -> str:
    """Record an inference with full evidence provenance. Returns inference_id."""
    import hashlib
    inference_id = str(uuid.uuid4())[:12]
    source_hash = ''
    if source_data:
        source_hash = hashlib.sha256(source_data.encode()).hexdigest()[:16]

    conn = get_connection()
    try:
        conn.execute(
            """INSERT INTO evidence_records
               (inference_id, inference_type, target, source_method,
                source_data_hash, confidence, assumptions, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))""",
            (inference_id, inference_type, target, source_method,
             source_hash, confidence,
             json.dumps(assumptions or []))
        )
        if dependencies:
            for dep_id in dependencies:
                conn.execute(
                    """INSERT INTO evidence_dependencies
                       (inference_id, depends_on_inference_id)
                       VALUES (?, ?)""",
                    (inference_id, dep_id)
                )
        conn.commit()
    finally:
        conn.close()
    return inference_id


def check_contradictions(target: str) -> list[dict]:
    """Find conflicting inference pairs for a target.

    Two inferences contradict if they have the same target and type
    but conflicting conclusions (e.g., one says 'safe', one says 'dangerous').
    """
    conn = get_connection()
    try:
        cur = conn.execute(
            """SELECT a.inference_id AS id_a, b.inference_id AS id_b,
                      a.inference_type, a.confidence AS conf_a,
                      b.confidence AS conf_b
               FROM evidence_records a
               JOIN evidence_records b ON a.target = b.target
                 AND a.inference_type = b.inference_type
                 AND a.inference_id < b.inference_id
               WHERE a.target = ?""",
            (target,)
        )
        conflicts = []
        for row in cur.fetchall():
            detail = (
                f"Conflicting {row[2]} inferences for {target}: "
                f"{row[0]} (conf={row[3]:.2f}) vs {row[1]} (conf={row[4]:.2f})"
            )
            conflicts.append({
                'inference_a': row[0],
                'inference_b': row[1],
                'type': row[2],
                'confidence_a': row[3],
                'confidence_b': row[4],
                'detail': detail,
            })
            # Persist contradiction
            conn.execute(
                """INSERT OR IGNORE INTO contradictions
                   (inference_a_id, inference_b_id, target, detail)
                   VALUES (?, ?, ?, ?)""",
                (row[0], row[1], target, detail)
            )
        conn.commit()
        return conflicts
    finally:
        conn.close()


def get_evidence_chain(inference_id: str) -> list[dict]:
    """Trace dependency chain from an inference back to root evidence.

    Uses recursive CTE to follow evidence_dependencies edges.
    """
    conn = get_connection()
    try:
        cur = conn.execute(
            """WITH RECURSIVE chain AS (
                SELECT inference_id, depends_on_inference_id, 0 AS depth
                FROM evidence_dependencies
                WHERE inference_id = ?
                UNION ALL
                SELECT ed.inference_id, ed.depends_on_inference_id, c.depth + 1
                FROM evidence_dependencies ed
                JOIN chain c ON ed.inference_id = c.depends_on_inference_id
                WHERE c.depth < 20
            )
            SELECT DISTINCT e.inference_id, e.inference_type, e.target,
                   e.source_method, e.confidence, c.depth
            FROM chain c
            JOIN evidence_records e ON e.inference_id = c.depends_on_inference_id
            ORDER BY c.depth""",
            (inference_id,)
        )
        return [
            {
                'inference_id': r[0],
                'type': r[1],
                'target': r[2],
                'source_method': r[3],
                'confidence': r[4],
                'depth': r[5],
            }
            for r in cur.fetchall()
        ]
    finally:
        conn.close()


def stale_belief_check() -> list[dict]:
    """Find inferences past their expiry or with stale source data."""
    conn = get_connection()
    try:
        cur = conn.execute(
            """SELECT inference_id, inference_type, target, created_at, expires_at
               FROM evidence_records
               WHERE expires_at IS NOT NULL
                 AND datetime(expires_at) < datetime('now')
               ORDER BY expires_at
               LIMIT 50"""
        )
        return [
            {
                'inference_id': r[0],
                'type': r[1],
                'target': r[2],
                'created_at': r[3],
                'expires_at': r[4],
            }
            for r in cur.fetchall()
        ]
    finally:
        conn.close()


def get_epistemic_summary() -> dict:
    """Return summary of epistemic state."""
    conn = get_connection()
    try:
        total = conn.execute("SELECT COUNT(*) FROM evidence_records").fetchone()[0]
        stale = conn.execute(
            "SELECT COUNT(*) FROM evidence_records WHERE expires_at IS NOT NULL AND datetime(expires_at) < datetime('now')"
        ).fetchone()[0]
        unresolved = conn.execute(
            "SELECT COUNT(*) FROM contradictions WHERE resolved_at IS NULL"
        ).fetchone()[0]

        avg_conf = conn.execute(
            "SELECT AVG(confidence) FROM evidence_records"
        ).fetchone()[0] if total > 0 else 0.0

        return {
            'total_inferences': total,
            'stale_beliefs': stale,
            'unresolved_contradictions': unresolved,
            'average_confidence': round(avg_conf, 3),
        }
    finally:
        conn.close()
