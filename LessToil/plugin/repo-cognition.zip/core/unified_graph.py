"""Runtime + Static Unified Graph.

Merges AST graph + type graph + runtime traces + profiling +
temporal co-change data into a single weighted multi-edge graph.

Exports as JSON and DOT for visualization and analysis.
"""

from __future__ import annotations

import json
import os

from .manifest import get_connection
from . import INDEX_DIR


def build_unified_graph(limit_symbols: int = 200, include_temporal: bool = True,
                          include_profiling: bool = True) -> dict:
    """Build a unified graph from all available data sources.

    Returns a dict with nodes and edges suitable for JSON export.
    """
    conn = get_connection()
    try:
        # Nodes: symbols with metadata
        cur = conn.execute(
            """SELECT s.id, s.name, s.kind, f.file_path, f.language,
                      s.confidence_score, s.security_sensitive
               FROM symbols s JOIN files f ON s.file_id = f.id
               LIMIT ?""",
            (limit_symbols,)
        )
        nodes = []
        node_ids = set()
        for row in cur.fetchall():
            node = {
                'id': row[0],
                'name': row[1],
                'kind': row[2],
                'file': row[3],
                'language': row[4],
                'confidence': row[5],
                'security_sensitive': bool(row[6]),
            }
            nodes.append(node)
            node_ids.add(str(row[1]))  # symbol name as string key

        # Edges: call graph weighted by multiple signals
        edges = []
        cur2 = conn.execute(
            "SELECT caller_id, callee_name, confidence, is_dynamic FROM call_edges LIMIT 5000"
        )
        for caller_id, callee_name, confidence, is_dynamic in cur2.fetchall():
            if callee_name not in node_ids:
                continue
            edge = {
                'source': caller_id,
                'target': callee_name,
                'static_confidence': confidence,
                'is_dynamic': bool(is_dynamic),
            }

            # Layer temporal co-change data if available
            if include_temporal:
                cur3 = conn.execute(
                    """SELECT risk_score FROM temporal_metrics
                       WHERE file_path IN (
                           SELECT f.file_path FROM symbols s
                           JOIN files f ON s.file_id = f.id
                           WHERE s.id = ?
                       )""",
                    (caller_id,)
                )
                row = cur3.fetchone()
                if row:
                    edge['temporal_risk'] = row[0]

            edges.append(edge)

        # Domain nodes
        cur4 = conn.execute("SELECT id, name, security_boundary FROM domains")
        domain_nodes = [
            {'id': f'domain_{r[0]}', 'name': r[1], 'type': 'domain',
             'security_boundary': bool(r[2])}
            for r in cur4.fetchall()
        ]

        return {
            'nodes': nodes + domain_nodes,
            'edges': edges,
            'node_count': len(nodes) + len(domain_nodes),
            'edge_count': len(edges),
        }
    finally:
        conn.close()


def export_unified_graph_json(output_path: str = '', limit: int = 200) -> str:
    """Export the unified graph as JSON. Returns the file path."""
    graph = build_unified_graph(limit_symbols=limit)

    if not output_path:
        output_path = os.path.join(INDEX_DIR, 'unified_graph.json')

    try:
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
    except OSError:
        pass

    with open(output_path, 'w') as f:
        json.dump(graph, f, indent=2)

    return output_path


def export_unified_graph_dot(output_path: str = '', limit: int = 200) -> str:
    """Export the unified graph as DOT format. Returns the file path."""
    graph = build_unified_graph(limit_symbols=limit)

    if not output_path:
        output_path = os.path.join(INDEX_DIR, 'unified_graph.dot')

    lines = ['digraph UnifiedGraph {']
    lines.append('  rankdir=LR;')
    lines.append('  node [shape=box, style=rounded];')

    # Write nodes
    for node in graph['nodes']:
        label = node.get('name', str(node.get('id', '')))
        node_type = node.get('type', 'symbol')
        if node_type == 'domain':
            lines.append(f'  "{node["id"]}" [label="{label}", shape=component, style=filled, fillcolor=lightblue];')
        elif node.get('security_sensitive'):
            lines.append(f'  "{node["id"]}" [label="{label}", fillcolor=red, style="filled,rounded"];')
        else:
            conf = node.get('confidence', 0.5)
            color = 'gray' + str(int(100 - conf * 80))
            lines.append(f'  "{node["id"]}" [label="{label}", color={color}];')

    # Write edges
    for edge in graph['edges']:
        weight = edge.get('static_confidence', 0.5)
        style = 'dashed' if edge.get('is_dynamic') else 'solid'
        temporal_risk = edge.get('temporal_risk', None)
        color = 'red' if temporal_risk and temporal_risk > 0.7 else 'black'
        lines.append(
            f'  "{edge["source"]}" -> "{edge["target"]}" '
            f'[weight={weight:.2f}, style={style}, color={color}];'
        )

    lines.append('}')

    try:
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
    except OSError:
        pass

    with open(output_path, 'w') as f:
        f.write('\n'.join(lines))

    return output_path


def get_unified_summary() -> dict:
    """Return a summary of the unified graph."""
    conn = get_connection()
    try:
        node_count = conn.execute("SELECT COUNT(*) FROM symbols").fetchone()[0]
        edge_count = conn.execute("SELECT COUNT(*) FROM call_edges").fetchone()[0]
        domain_count = conn.execute("SELECT COUNT(*) FROM domains").fetchone()[0]

        temporal_count = 0
        try:
            temporal_count = conn.execute(
                "SELECT COUNT(*) FROM temporal_metrics"
            ).fetchone()[0]
        except Exception:
            pass

        return {
            'nodes': node_count,
            'edges': edge_count,
            'domains': domain_count,
            'temporal_files': temporal_count,
            'has_temporal': temporal_count > 0,
            'json_export': os.path.join(INDEX_DIR, 'unified_graph.json'),
            'dot_export': os.path.join(INDEX_DIR, 'unified_graph.dot'),
        }
    finally:
        conn.close()
