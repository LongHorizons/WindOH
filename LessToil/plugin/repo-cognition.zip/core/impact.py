"""Impact analysis for code changes.

Uses the call graph and domain assignments to predict what will be
affected by changes to files or symbols.
"""

from __future__ import annotations

from .manifest import get_connection


def analyze_file_impact(file_paths: list[str]) -> dict:
    """Analyze the impact of changing the given files.

    Returns a dict with:
        - affected_callers: count of direct callers
        - affected_files: count of files with callers
        - affected_domains: list of domain names
        - security_sensitive: list of security-sensitive symbols
        - affected_tests: list of test files that may need updates
        - transitive_dependents: list of {file, symbol, depth}
    """
    if not file_paths:
        return {
            'affected_callers': 0,
            'affected_files': 0,
            'affected_domains': [],
            'security_sensitive': [],
            'affected_tests': [],
            'transitive_dependents': [],
        }

    conn = get_connection()
    try:
        # Find symbols in the target files
        placeholders = ','.join('?' for _ in file_paths)
        cur = conn.execute(
            f"""SELECT s.name, s.kind, s.security_sensitive, f.file_path
                FROM symbols s
                JOIN files f ON s.file_id = f.id
                WHERE f.file_path IN ({placeholders})
                LIMIT 100""",
            file_paths
        )
        affected_symbols = [
            {"name": r[0], "kind": r[1],
             "security_sensitive": bool(r[2]), "file": r[3]}
            for r in cur.fetchall()
        ]

        if not affected_symbols:
            return {
                'affected_callers': 0,
                'affected_files': 0,
                'affected_domains': [],
                'security_sensitive': [],
                'affected_tests': [],
                'transitive_dependents': [],
            }

        sym_names = [s['name'] for s in affected_symbols]
        security_syms = [s for s in affected_symbols if s['security_sensitive']]

        # Count direct callers
        name_placeholders = ','.join('?' for _ in sym_names)
        cur2 = conn.execute(
            f"""SELECT COUNT(DISTINCT ce.caller_id), COUNT(DISTINCT f2.file_path)
                FROM call_edges ce
                JOIN symbols s2 ON ce.caller_id = s2.id
                JOIN files f2 ON s2.file_id = f2.id
                WHERE ce.callee_name IN ({name_placeholders})""",
            sym_names
        )
        row = cur2.fetchone()
        caller_count = row[0] if row else 0
        affected_file_count = row[1] if row else 0

        # Affected domains
        cur3 = conn.execute(
            f"""SELECT DISTINCT d.name, d.security_boundary
                FROM domains d
                JOIN file_domains fd ON d.id = fd.domain_id
                JOIN files f ON fd.file_id = f.id
                WHERE f.file_path IN ({placeholders})""",
            file_paths
        )
        affected_domains = [
            {"name": r[0], "security_boundary": bool(r[1])}
            for r in cur3.fetchall()
        ]

        # Test files that test the affected symbols
        cur4 = conn.execute(
            f"""SELECT DISTINCT f2.file_path
                FROM call_edges ce
                JOIN symbols s2 ON ce.caller_id = s2.id
                JOIN files f2 ON s2.file_id = f2.id
                WHERE ce.callee_name IN ({name_placeholders})
                  AND (f2.file_path LIKE '%test%'
                       OR f2.file_path LIKE '%spec%'
                       OR f2.file_path LIKE '%__tests__%')
                LIMIT 20""",
            sym_names
        )
        affected_tests = [r[0] for r in cur4.fetchall()]

        # Transitive dependents (limited to depth 5)
        transitive = []
        for sym_name in sym_names[:10]:
            cur5 = conn.execute(
                """WITH RECURSIVE dependents AS (
                    SELECT s.id, s.name, f.file_path, 1 AS depth
                    FROM call_edges ce
                    JOIN symbols s ON ce.caller_id = s.id
                    JOIN files f ON s.file_id = f.id
                    WHERE ce.callee_name = ?
                    UNION ALL
                    SELECT s.id, s.name, f.file_path, d.depth + 1
                    FROM call_edges ce
                    JOIN symbols s ON ce.caller_id = s.id
                    JOIN files f ON s.file_id = f.id
                    JOIN dependents d ON ce.callee_name = d.name
                    WHERE d.depth < 5
                )
                SELECT DISTINCT name, file_path, depth FROM dependents
                ORDER BY depth, file_path
                LIMIT 50""",
                (sym_name,)
            )
            for row in cur5.fetchall():
                entry = {"symbol": row[0], "file": row[1], "depth": row[2]}
                if entry not in transitive:
                    transitive.append(entry)

        return {
            'affected_callers': caller_count,
            'affected_files': affected_file_count,
            'affected_domains': [d['name'] for d in affected_domains],
            'security_sensitive': [s['name'] for s in security_syms],
            'affected_tests': affected_tests,
            'transitive_dependents': transitive[:50],
        }
    finally:
        conn.close()


def get_domain_impact(file_paths: list[str]) -> list[dict]:
    """Get domain-level impact information for changed files."""
    impact = analyze_file_impact(file_paths)
    domains = impact.get('affected_domains', [])

    if not domains:
        return []

    conn = get_connection()
    try:
        results = []
        for domain_name in domains:
            cur = conn.execute(
                "SELECT description, security_boundary FROM domains WHERE name = ?",
                (domain_name,)
            )
            row = cur.fetchone()
            if row:
                results.append({
                    'domain': domain_name,
                    'description': row[0],
                    'security_boundary': bool(row[1]),
                })
        return results
    finally:
        conn.close()


def get_test_coverage(file_paths: list[str]) -> dict[str, list[str]]:
    """Map files to their associated test files.

    Returns a dict of {file_path: [test_file_paths]}.
    """
    coverage = {}
    conn = get_connection()
    try:
        for file_path in file_paths:
            # Find symbols in the file
            cur = conn.execute(
                "SELECT name FROM symbols s JOIN files f ON s.file_id = f.id "
                "WHERE f.file_path = ?",
                (file_path,)
            )
            symbols = [r[0] for r in cur.fetchall()]

            if not symbols:
                continue

            # Find callers in test files
            placeholders = ','.join('?' for _ in symbols)
            cur2 = conn.execute(
                f"""SELECT DISTINCT f2.file_path
                    FROM call_edges ce
                    JOIN symbols s2 ON ce.caller_id = s2.id
                    JOIN files f2 ON s2.file_id = f2.id
                    WHERE ce.callee_name IN ({placeholders})
                      AND (f2.file_path LIKE '%test%'
                           OR f2.file_path LIKE '%spec%'
                           OR f2.file_path LIKE '%__tests__%')""",
                symbols
            )
            tests = [r[0] for r in cur2.fetchall()]
            if tests:
                coverage[file_path] = tests

        return coverage
    finally:
        conn.close()


def summarize_impact(file_paths: list[str]) -> str:
    """Produce a human-readable impact summary for the given files."""
    impact = analyze_file_impact(file_paths)

    parts = []

    if impact['affected_callers'] > 0:
        parts.append(
            f"Editing {len(file_paths)} file(s) affects "
            f"{impact['affected_callers']} callers in "
            f"{impact['affected_files']} files"
        )

    if impact['affected_domains']:
        parts.append(
            f"across domains: {', '.join(impact['affected_domains'])}"
        )

    if impact['security_sensitive']:
        parts.append(
            f"Security-sensitive symbols affected: "
            f"{', '.join(impact['security_sensitive'][:5])}"
        )

    if impact['affected_tests']:
        test_count = len(impact['affected_tests'])
        parts.append(f"{test_count} test file(s) may need updates")

    return '. '.join(parts) + '.' if parts else "No significant impact detected."
