"""Precision refactor scoring and recommendation engine.

Wires SimHash duplicate detection into the indexing pipeline and computes
refactor priority scores based on duplication severity, maintenance cost,
dependency reduction, and migration risk.

Score: 0.35*duplication_severity + 0.25*maintenance_cost +
       0.25*dependency_reduction - 0.15*migration_risk
"""

from __future__ import annotations

from .manifest import get_connection


def compute_duplication_severity(file_path: str) -> float:
    """Compute how severely a file suffers from duplication (0-1)."""
    conn = get_connection()
    try:
        # Find simhash entries for this file
        cur = conn.execute(
            "SELECT simhash FROM similarity_groups WHERE file_path = ?",
            (file_path,)
        )
        hashes = [r[0] for r in cur.fetchall()]

        if not hashes:
            return 0.0

        # Count how many other files have similar simhashes
        duplicate_count = 0
        checked = set()
        for h in hashes[:10]:  # check first 10 hashes
            target_int = int(h, 16)
            cur2 = conn.execute(
                "SELECT simhash, file_path FROM similarity_groups WHERE file_path != ?"
            )
            for other_hash, other_path in cur2.fetchall():
                if other_path in checked:
                    continue
                other_int = int(other_hash, 16)
                distance = (target_int ^ other_int).bit_count()
                if 0 < distance <= 6:
                    duplicate_count += 1
                    checked.add(other_path)

        return min(1.0, duplicate_count / 10.0)
    except Exception:
        return 0.0
    finally:
        conn.close()


def compute_maintenance_cost(file_path: str) -> float:
    """Estimate the maintenance cost of a file from temporal + complexity data."""
    conn = get_connection()
    try:
        # Get temporal risk
        cur = conn.execute(
            "SELECT risk_score, bug_fix_commits, total_commits FROM temporal_metrics "
            "WHERE file_path = ?",
            (file_path,)
        )
        row = cur.fetchone()
        if row is None:
            temporal_score = 0.2
        else:
            temporal_score = row[0] or 0.2

        # Get file size/complexity
        cur2 = conn.execute(
            "SELECT line_count FROM files WHERE file_path = ?", (file_path,)
        )
        row2 = cur2.fetchone()
        size_score = min(1.0, (row2[0] or 100) / 1000.0) if row2 else 0.2

        # Get symbol count
        cur3 = conn.execute(
            """SELECT COUNT(*) FROM symbols s
               JOIN files f ON s.file_id = f.id
               WHERE f.file_path = ?""",
            (file_path,)
        )
        sym_count = cur3.fetchone()[0]
        sym_score = min(1.0, sym_count / 50.0)

        return round(0.4 * temporal_score + 0.3 * size_score + 0.3 * sym_score, 4)
    except Exception:
        return 0.3
    finally:
        conn.close()


def compute_dependency_reduction_potential(file_path: str) -> float:
    """Estimate how much dependency reduction refactoring would yield."""
    conn = get_connection()
    try:
        # Count incoming callers (how many depend on this file's symbols)
        cur = conn.execute(
            """SELECT COUNT(DISTINCT ce.caller_id)
               FROM call_edges ce
               JOIN symbols s ON s.name = ce.callee_name
               JOIN files f ON s.file_id = f.id
               WHERE f.file_path = ?""",
            (file_path,)
        )
        caller_count = cur.fetchone()[0]

        # Count outgoing calls
        cur2 = conn.execute(
            """SELECT COUNT(*)
               FROM call_edges ce
               JOIN symbols s ON ce.caller_id = s.id
               JOIN files f ON s.file_id = f.id
               WHERE f.file_path = ?""",
            (file_path,)
        )
        outgoing_count = cur2.fetchone()[0]

        total = caller_count + outgoing_count
        return min(1.0, total / 100.0) if total > 0 else 0.0
    except Exception:
        return 0.0
    finally:
        conn.close()


def compute_migration_risk(file_path: str) -> float:
    """Estimate the risk of refactoring this file.

    Uses confidence scores, test coverage, and caller count.
    """
    conn = get_connection()
    try:
        # Average confidence of symbols in this file
        cur = conn.execute(
            """SELECT AVG(s.confidence_score)
               FROM symbols s JOIN files f ON s.file_id = f.id
               WHERE f.file_path = ?""",
            (file_path,)
        )
        row = cur.fetchone()
        avg_confidence = row[0] if row and row[0] else 0.5

        # Test coverage
        cur2 = conn.execute(
            """SELECT COUNT(*) FROM call_edges ce
               JOIN symbols s2 ON ce.caller_id = s2.id
               JOIN files f2 ON s2.file_id = f2.id
               WHERE ce.callee_name IN (
                   SELECT s.name FROM symbols s
                   JOIN files f ON s.file_id = f.id
                   WHERE f.file_path = ?
               )
               AND (f2.file_path LIKE '%test%'
                    OR f2.file_path LIKE '%spec%'
                    OR f2.file_path LIKE '%__tests__%')""",
            (file_path,)
        )
        test_count = cur2.fetchone()[0]

        # Caller breadth
        cur3 = conn.execute(
            """SELECT COUNT(DISTINCT f2.file_path)
               FROM call_edges ce
               JOIN symbols s ON s.name = ce.callee_name
               JOIN files f ON s.file_id = f.id
               JOIN symbols s2 ON ce.caller_id = s2.id
               JOIN files f2 ON s2.file_id = f2.id
               WHERE f.file_path = ? AND f2.file_path != ?""",
            (file_path, file_path)
        )
        caller_breadth = cur3.fetchone()[0]

        # Risk = low confidence + few tests + many callers
        conf_risk = 1.0 - avg_confidence
        test_risk = 1.0 - min(1.0, test_count / 5.0)
        breadth_risk = min(1.0, caller_breadth / 20.0)

        return round(0.4 * conf_risk + 0.3 * test_risk + 0.3 * breadth_risk, 4)
    except Exception:
        return 0.5
    finally:
        conn.close()


def score_refactor_candidate(file_path: str) -> dict:
    """Compute a comprehensive refactor score for a file.

    Returns a dict with scores and recommendation level.
    """
    dup_severity = compute_duplication_severity(file_path)
    maint_cost = compute_maintenance_cost(file_path)
    dep_reduction = compute_dependency_reduction_potential(file_path)
    mig_risk = compute_migration_risk(file_path)

    score = round(
        0.35 * dup_severity +
        0.25 * maint_cost +
        0.25 * dep_reduction -
        0.15 * mig_risk,
        4
    )

    # Recommendation levels
    if score > 0.6:
        recommendation = 'strong_candidate'
    elif score > 0.3:
        recommendation = 'consider'
    else:
        recommendation = 'low_priority'

    return {
        'file_path': file_path,
        'refactor_score': score,
        'duplication_severity': dup_severity,
        'maintenance_cost': maint_cost,
        'dependency_reduction_potential': dep_reduction,
        'migration_risk': mig_risk,
        'recommendation': recommendation,
    }


def get_top_refactor_candidates(limit: int = 10) -> list[dict]:
    """Return the top-N refactor candidates across the codebase."""
    conn = get_connection()
    try:
        cur = conn.execute(
            "SELECT file_path FROM files ORDER BY line_count DESC LIMIT 100"
        )
        candidates = []
        for (file_path,) in cur.fetchall():
            result = score_refactor_candidate(file_path)
            if result['recommendation'] != 'low_priority':
                candidates.append(result)

        candidates.sort(key=lambda x: x['refactor_score'], reverse=True)
        return candidates[:limit]
    finally:
        conn.close()


def summarize_refactoring() -> dict:
    """Return a summary of refactoring opportunities."""
    conn = get_connection()
    try:
        file_count = conn.execute("SELECT COUNT(*) FROM files").fetchone()[0]
        dup_pairs = conn.execute(
            "SELECT COUNT(*) FROM similarity_groups"
        ).fetchone()[0]
    finally:
        conn.close()

    candidates = get_top_refactor_candidates(10)
    strong = [c for c in candidates if c['recommendation'] == 'strong_candidate']
    consider = [c for c in candidates if c['recommendation'] == 'consider']

    return {
        'files_analyzed': min(file_count, 100),
        'strong_candidates': len(strong),
        'consider_candidates': len(consider),
        'top_candidates': candidates[:5],
        'duplicate_pairs_indexed': dup_pairs,
    }
