"""Architectural domain inference and management.

Uses heuristic pattern matching against file paths and symbol names to assign
files to architectural domains (auth, payments, caching, etc.). Supports
import/export of domain data via .local.md files for cross-session persistence.
"""

from __future__ import annotations

import os
import re
import yaml

from . import PROJECT_DIR, DOMAINS_STATE_PATH
from .manifest import (
    get_connection, upsert_domain, set_file_domain, get_files_by_domain,
    get_all_domains
)


# Domain definitions: name -> (path_patterns, symbol_patterns, description)
DOMAIN_DEFINITIONS = {
    'authentication': {
        'description': 'User authentication, authorization, sessions, tokens, OAuth',
        'path_patterns': [
            r'auth', r'login', r'signin', r'signup', r'register',
            r'session', r'token', r'oauth', r'sso', r'saml',
            r'permission', r'rbac', r'ACL', r'access-control',
            r'credential', r'identity', r'jwt',
        ],
        'symbol_patterns': [
            r'auth', r'login', r'logout', r'signin', r'signup',
            r'token', r'jwt', r'oauth', r'session', r'credential',
            r'permission', r'role', r'rbac', r'authorize', r'authenticate',
            r'verifyPassword', r'hashPassword', r'validateToken',
        ],
        'security_boundary': True,
    },
    'payments': {
        'description': 'Payment processing, billing, invoicing, subscriptions',
        'path_patterns': [
            r'billing', r'payment', r'invoice', r'checkout',
            r'stripe', r'paypal', r'subscription', r'plan',
            r'charge', r'refund', r'transaction', r'pricing',
        ],
        'symbol_patterns': [
            r'payment', r'billing', r'invoice', r'checkout',
            r'stripe', r'paypal', r'subscription', r'charge',
            r'refund', r'transaction', r'pricing', r'plan',
        ],
        'security_boundary': True,
    },
    'caching': {
        'description': 'Caching layer, Redis, Memcached, in-memory caches',
        'path_patterns': [
            r'cache', r'redis', r'memcache', r'memoize',
            r'cache-control', r'etag',
        ],
        'symbol_patterns': [
            r'cache', r'redis', r'memcache', r'memoize',
            r'getCached', r'setCache', r'invalidate',
        ],
        'security_boundary': False,
    },
    'data-access': {
        'description': 'Database access, ORM, repositories, DAOs, queries',
        'path_patterns': [
            r'repository', r'repos', r'dao', r'database', r'db',
            r'query', r'model', r'schema', r'migration', r'seed',
            r'entity', r'persistence', r'store', r'datastore',
        ],
        'symbol_patterns': [
            r'repository', r'dao', r'findBy', r'save', r'create',
            r'update', r'delete', r'query', r'migrate',
            r'insert', r'upsert', r'findAll', r'findOne',
        ],
        'security_boundary': False,
    },
    'api': {
        'description': 'REST/GraphQL/gRPC API layer, controllers, handlers, routes',
        'path_patterns': [
            r'controller', r'handler', r'route', r'router',
            r'middleware', r'api', r'endpoint', r'resource',
            r'graphql', r'grpc', r'rest', r'request', r'response',
        ],
        'symbol_patterns': [
            r'controller', r'handler', r'middleware', r'route',
            r'endpoint', r'get[A-Z]', r'post[A-Z]', r'put[A-Z]',
            r'patch[A-Z]', r'delete[A-Z]', r'handle[A-Z]',
        ],
        'security_boundary': True,
    },
    'ui': {
        'description': 'User interface components, views, templates, rendering',
        'path_patterns': [
            r'component', r'view', r'template', r'render',
            r'page', r'screen', r'modal', r'widget',
            r'jsx', r'css', r'style', r'theme', r'layout',
            r'component', r'ui', r'frontend',
        ],
        'symbol_patterns': [
            r'component', r'render', r'view', r'template',
            r'props', r'state', r'useState', r'useEffect',
            r'onClick', r'onChange', r'onSubmit',
        ],
        'security_boundary': False,
    },
    'config': {
        'description': 'Configuration, environment variables, settings, feature flags',
        'path_patterns': [
            r'config', r'setting', r'environment', r'\.env',
            r'feature-flag', r'featureflag', r'toggle',
            r'constant', r'option',
        ],
        'symbol_patterns': [
            r'config', r'setting', r'env', r'environment',
            r'getEnv', r'isEnabled', r'getConfig',
        ],
        'security_boundary': True,
    },
    'logging': {
        'description': 'Logging, monitoring, telemetry, audit trails',
        'path_patterns': [
            r'log', r'logger', r'logging', r'audit',
            r'telemetry', r'metric', r'monitor', r'trace',
            r'alert', r'event', r'dashboard',
        ],
        'symbol_patterns': [
            r'log', r'logger', r'audit', r'telemetry',
            r'metric', r'trace', r'span', r'monitor',
            r'info', r'warn', r'error', r'debug',
        ],
        'security_boundary': False,
    },
    'messaging': {
        'description': 'Message queues, event buses, pub/sub, notifications',
        'path_patterns': [
            r'queue', r'message', r'event', r'pubsub',
            r'kafka', r'rabbit', r'sqs', r'sns',
            r'notification', r'email', r'webhook',
            r'bus', r'stream', r'broker',
        ],
        'symbol_patterns': [
            r'publish', r'subscribe', r'emit', r'dispatch',
            r'queue', r'message', r'event', r'notification',
            r'send', r'receive', r'consume', r'produce',
        ],
        'security_boundary': False,
    },
    'testing': {
        'description': 'Tests, test fixtures, test utilities, mocks',
        'path_patterns': [
            r'test', r'spec', r'__tests__', r'mock',
            r'fixture', r'stub', r'fake',
        ],
        'symbol_patterns': [
            r'test', r'spec', r'it\(', r'describe\(',
            r'beforeEach', r'afterEach', r'expect\(', r'assert',
            r'mock', r'stub', r'spy', r'fixture',
        ],
        'security_boundary': False,
    },
    'build': {
        'description': 'Build system, CI/CD, Docker, packaging, deployment',
        'path_patterns': [
            r'Dockerfile', r'docker-compose', r'Makefile',
            r'\.github/workflows', r'\.circleci', r'\.gitlab-ci',
            r'Jenkinsfile', r'build', r'deploy', r'release',
            r'package', r'bundle', r'webpack', r'vite', r'esbuild',
        ],
        'symbol_patterns': [
            r'build', r'deploy', r'release', r'package',
        ],
        'security_boundary': False,
    },
    'crypto': {
        'description': 'Cryptography, encryption, hashing, key derivation, PKI',
        'path_patterns': [
            r'crypto', r'encrypt', r'decrypt', r'cipher',
            r'hash', r'aes', r'hmac', r'key', r'cert',
            r'tls', r'signature', r'secret',
        ],
        'symbol_patterns': [
            r'encrypt', r'decrypt', r'hash', r'cipher',
            r'aes', r'hmac', r'key', r'cert', r'tls',
            r'sign', r'verify', r'digest', r'random',
            r'seal', r'unseal',
        ],
        'security_boundary': True,
    },
    'networking': {
        'description': 'Network protocols, DNS, HTTP clients, sockets, connections',
        'path_patterns': [
            r'network', r'networking', r'socket', r'tcp', r'udp',
            r'http', r'dns', r'proxy', r'connect', r'bind',
            r'packet', r'transport', r'protocol',
        ],
        'symbol_patterns': [
            r'network', r'socket', r'connect', r'bind', r'listen',
            r'dns', r'http', r'tcp', r'udp', r'proxy',
            r'send', r'receive', r'resolve', r'fetch',
        ],
        'security_boundary': False,
    },
    'system': {
        'description': 'OS-level operations, process management, system calls, services',
        'path_patterns': [
            r'system', r'process', r'service', r'daemon',
            r'kernel', r'driver', r'syscall', r'registry',
            r'wmi', r'win32', r'windows', r'nt',
        ],
        'symbol_patterns': [
            r'process', r'service', r'system', r'kernel',
            r'daemon', r'registry', r'wmi', r'win32',
            r'start', r'stop', r'spawn', r'create_process',
        ],
        'security_boundary': False,
    },
}


def _match_patterns(text: str, patterns: list[str]) -> float:
    """Return a confidence score (0.0-1.0) based on pattern matches."""
    if not text:
        return 0.0
    text_lower = text.lower()
    matches = 0
    for pattern in patterns:
        if re.search(pattern, text_lower, re.IGNORECASE):
            matches += 1
    if not patterns:
        return 0.0
    return min(1.0, matches / max(1, len(patterns) * 0.3))


def _detect_workspace_crates() -> dict[str, str]:
    """Detect Rust workspace crate directories from Cargo.toml.

    Returns dict of {crate_name: directory_path}.
    """
    try:
        root_toml = os.path.join(PROJECT_DIR, 'Cargo.toml')
        if not os.path.exists(root_toml):
            return {}
        with open(root_toml, 'r', encoding='utf-8', errors='replace') as f:
            content = f.read()
        # Look for [workspace] members (handles both inline and multi-line arrays)
        members = []
        in_workspace = False
        in_members = False
        for line in content.split('\n'):
            stripped = line.strip()
            if stripped == '[workspace]':
                in_workspace = True
            elif stripped.startswith('[') and stripped != '[workspace]':
                in_workspace = False
                in_members = False
            elif in_workspace and stripped.startswith('members'):
                in_members = True
                for match in re.finditer(r'"([^"]+)"', stripped):
                    members.append(match.group(1))
                if ']' in stripped:
                    in_members = False
            elif in_members:
                for match in re.finditer(r'"([^"]+)"', stripped):
                    members.append(match.group(1))
                if ']' in stripped:
                    in_members = False
        result = {}
        for member in members:
            # member is a relative path like "agent-core"
            crate_dir = os.path.join(PROJECT_DIR, member)
            crate_toml = os.path.join(crate_dir, 'Cargo.toml')
            if os.path.exists(crate_toml):
                try:
                    with open(crate_toml, 'r', encoding='utf-8', errors='replace') as f:
                        for line in f:
                            m = re.match(r'^name\s*=\s*"([^"]+)"', line.strip())
                            if m:
                                result[m.group(1)] = member
                                break
                except Exception:
                    pass
        return result
    except Exception:
        return {}


# Cache workspace crates (computed once per session)
_WORKSPACE_CRATES: dict[str, str] | None = None


def _get_workspace_crates() -> dict[str, str]:
    global _WORKSPACE_CRATES
    if _WORKSPACE_CRATES is None:
        _WORKSPACE_CRATES = _detect_workspace_crates()
    return _WORKSPACE_CRATES


def infer_domains_for_file(file_path: str) -> list[tuple[str, float]]:
    """Infer architectural domains for a single file path.

    Returns list of (domain_name, confidence) tuples sorted by confidence desc.
    """
    results = []
    filename = os.path.basename(file_path)
    dirname = os.path.dirname(file_path)

    # Rust workspace crate detection: if file is inside a known crate directory,
    # assign a domain based on the crate name with moderate confidence
    path_parts = file_path.replace('\\', '/').split('/')
    crates = _get_workspace_crates()
    for crate_name, crate_dir in crates.items():
        # Check if file_path starts with crate_dir/
        norm_path = file_path.replace('\\', '/')
        norm_crate = crate_dir.replace('\\', '/')
        if norm_path.startswith(norm_crate + '/') or norm_path.startswith(norm_crate + '\\'):
            results.append((crate_name, 0.55))
            break

    for domain_name, definition in DOMAIN_DEFINITIONS.items():
        path_score = _match_patterns(file_path, definition['path_patterns'])
        filename_score = _match_patterns(filename, definition['path_patterns'])

        # Direct path matches get higher confidence
        confidence = max(path_score * 0.7, filename_score * 0.5)

        # Boost for exact directory name matches
        path_parts = file_path.replace('\\', '/').split('/')
        for pattern in definition['path_patterns']:
            for part in path_parts:
                if re.fullmatch(pattern, part, re.IGNORECASE):
                    confidence = max(confidence, 0.9)
                    break

        if confidence >= 0.2:
            results.append((domain_name, confidence))

    # Always assign 'testing' domain to test files
    if 'test' in file_path.lower() or 'spec' in file_path.lower() or '__tests__' in file_path:
        results.append(('testing', 0.95))

    results.sort(key=lambda x: x[1], reverse=True)
    return results[:3]  # Top 3 domains per file


def classify_all_files() -> dict[str, int]:
    """Run domain inference on all indexed files and store results.

    Returns count of files classified per domain.
    """
    conn = get_connection()
    try:
        # Ensure all domains exist in the DB (built-in + workspace crates)
        for domain_name, definition in DOMAIN_DEFINITIONS.items():
            upsert_domain(
                name=domain_name,
                description=definition['description'],
                entry_points='[]',
                security_boundary=definition['security_boundary'],
            )

        # Seed workspace crate domains (Rust monorepo support)
        for crate_name, crate_dir in _get_workspace_crates().items():
            upsert_domain(
                name=crate_name,
                description=f'Rust crate: {crate_dir}',
                entry_points='[]',
                security_boundary=False,
            )

        # Process all files
        cur = conn.execute("SELECT id, file_path FROM files")
        files = cur.fetchall()

        domain_counts = {}
        for file_id, file_path in files:
            domains = infer_domains_for_file(file_path)
            for domain_name, confidence in domains:
                cur2 = conn.execute("SELECT id FROM domains WHERE name = ?", (domain_name,))
                row = cur2.fetchone()
                if row:
                    set_file_domain(file_id, row[0], confidence)
                    domain_counts[domain_name] = domain_counts.get(domain_name, 0) + 1

        conn.commit()
        return domain_counts
    finally:
        conn.close()


def export_domains_to_md() -> str:
    """Export domain data to a .local.md file for cross-session persistence.

    Returns the markdown content.
    """
    domains = get_all_domains()
    if not domains:
        return ''

    frontmatter = {'domains': [], 'last_updated': ''}
    from datetime import datetime, timezone
    frontmatter['last_updated'] = datetime.now(timezone.utc).isoformat()

    lines = []
    for d in domains:
        entry = {
            'name': d['name'],
            'description': d.get('description', ''),
            'entry_points': d.get('entry_points', []),
            'security_boundary': d.get('security_boundary', False),
        }

        # Get files in this domain
        try:
            domain_files = get_files_by_domain(d['name'])
            entry['file_count'] = len(domain_files)
            entry['top_files'] = [f['file_path'] for f in domain_files[:10]]
        except Exception:
            entry['file_count'] = 0
            entry['top_files'] = []

        frontmatter['domains'].append(entry)
        lines.append(f"### {d['name']}")
        lines.append(f"_{d.get('description', '')}_")
        if d.get('security_boundary'):
            lines.append('- **SECURITY BOUNDARY**')
        lines.append(f"- {entry['file_count']} files")
        if entry['top_files']:
            lines.append('- Key files:')
            for f in entry['top_files'][:5]:
                lines.append(f"  - `{f}`")
        lines.append('')

    # Write to file
    os.makedirs(os.path.dirname(DOMAINS_STATE_PATH), exist_ok=True)
    with open(DOMAINS_STATE_PATH, 'w') as f:
        f.write('---\n')
        f.write(yaml.dump(frontmatter, default_flow_style=False, sort_keys=False))
        f.write('---\n\n')
        f.write('\n'.join(lines))

    return '\n'.join(lines)


def import_domains_from_md() -> int:
    """Import domain data from the .local.md file into the SQLite database.

    Returns the number of domains imported.
    """
    if not os.path.exists(DOMAINS_STATE_PATH):
        return 0

    try:
        with open(DOMAINS_STATE_PATH) as f:
            content = f.read()
    except (OSError, IOError):
        return 0

    # Parse YAML frontmatter
    if not content.startswith('---'):
        return 0

    parts = content.split('---', 2)
    if len(parts) < 3:
        return 0

    try:
        frontmatter = yaml.safe_load(parts[1])
    except yaml.YAMLError:
        return 0

    if not frontmatter or 'domains' not in frontmatter:
        return 0

    count = 0
    for domain_data in frontmatter['domains']:
        name = domain_data.get('name', '')
        if not name:
            continue
        upsert_domain(
            name=name,
            description=domain_data.get('description', ''),
            entry_points=str(domain_data.get('entry_points', [])),
            security_boundary=domain_data.get('security_boundary', False),
        )
        count += 1

    return count
