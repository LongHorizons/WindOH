"""Repository Cognition Engine - core constants and path configuration.

All path constants are resolved lazily via resolve_project_dir() which tries
multiple strategies: CLAUDE_PROJECT_DIR env → git root → CWD. This ensures
hooks and commands work correctly regardless of invocation context.
"""

from __future__ import annotations

import os
import sys
import subprocess

# -- Project root resolution ----------------------------------------------

_resolved_project_dir: str | None = None
_resolved_index_dir: str | None = None


def resolve_project_dir() -> str:
    """Resolve the project root directory using a fallback chain.

    1. CLAUDE_PROJECT_DIR environment variable (set by Claude Code)
    2. `git rev-parse --show-toplevel` (finds git root from any subdirectory)
    3. Current working directory

    Returns:
        Absolute path to the project root directory.

    Raises:
        RuntimeError: If no valid project directory can be resolved.
    """
    global _resolved_project_dir

    if _resolved_project_dir is not None:
        return _resolved_project_dir

    # Strategy 1: Environment variable
    env_dir = os.environ.get('CLAUDE_PROJECT_DIR', '')
    if env_dir and os.path.isdir(env_dir):
        _resolved_project_dir = os.path.abspath(env_dir)
        return _resolved_project_dir

    # Strategy 2: Git root (works from any subdirectory of a git repo)
    try:
        result = subprocess.run(
            ['git', 'rev-parse', '--show-toplevel'],
            capture_output=True, text=True, timeout=10,
            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0)
        )
        if result.returncode == 0:
            git_root = result.stdout.strip()
            if git_root and os.path.isdir(git_root):
                _resolved_project_dir = os.path.abspath(git_root)
                return _resolved_project_dir
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        pass

    # Strategy 3: Current working directory
    cwd = os.getcwd()
    if os.path.isdir(cwd):
        _resolved_project_dir = os.path.abspath(cwd)
        return _resolved_project_dir

    raise RuntimeError(
        'Cannot resolve project directory. '
        'Set CLAUDE_PROJECT_DIR or run from within a git repository.'
    )


def reset_project_dir(new_path: str) -> None:
    """Explicitly override the resolved project directory.

    Call this when CLAUDE_PROJECT_DIR is set after module import (e.g., in hooks).
    """
    global _resolved_project_dir, _resolved_index_dir
    _resolved_project_dir = os.path.abspath(new_path)
    _resolved_index_dir = None  # Force re-resolution


# Lazy constants — call resolve_project_dir() at first access
_LAZY_PROJECT_DIR = None
_LAZY_INDEX_DIR = None


def _get_project_dir():
    global _LAZY_PROJECT_DIR
    if _LAZY_PROJECT_DIR is None:
        _LAZY_PROJECT_DIR = resolve_project_dir()
    # If reset_project_dir was called externally, use that
    if _resolved_project_dir is not None:
        return _resolved_project_dir
    return _LAZY_PROJECT_DIR


def _get_index_dir():
    global _LAZY_INDEX_DIR
    if _LAZY_INDEX_DIR is None:
        _LAZY_INDEX_DIR = os.path.join(_get_project_dir(), '.claude', 'index', 'repo-cognition')
    if _resolved_index_dir is not None:
        return _resolved_index_dir
    return _LAZY_INDEX_DIR


# -- Public path constants (lazily resolved) -----------------------------

def _p(name):
    """Property-like accessor for lazy path constants."""
    return property(lambda self: globals()[f'_get_{name}']()) if False else None

# Direct module-level access: these use the lazy functions
PROJECT_DIR = property(lambda _: _get_project_dir())
INDEX_DIR = property(lambda _: _get_index_dir())
# For backwards compatibility with imports that expect strings, we use __getattr__
# But actually, the hooks import these as module-level constants and use them directly.
# We need to keep them as properties or use module __getattr__.


# Instead, let's just compute them once and allow override:
_raw_project = os.environ.get('CLAUDE_PROJECT_DIR', os.getcwd())
_raw_index = os.path.join(_raw_project, '.claude', 'index', 'repo-cognition')

# These are the module-level constants used by all imports.
# They can be overridden by calling set_project_dir() before any DB operations.
PROJECT_DIR = _raw_project
INDEX_DIR = _raw_index
DB_PATH = os.path.join(INDEX_DIR, 'index.db')
MANIFEST_PATH = os.path.join(INDEX_DIR, 'file_manifest.json')
SYMBOL_GRAPH_PATH = os.path.join(INDEX_DIR, 'symbol_graph.json')
CALL_GRAPH_PATH = os.path.join(INDEX_DIR, 'call_graph.json')
TAXONOMY_PATH = os.path.join(INDEX_DIR, 'project_taxonomy.md')
CLAUDE_MD_PATH = os.path.join(INDEX_DIR, 'CLAUDE.md')
DOMAINS_STATE_PATH = os.path.join(PROJECT_DIR, '.claude', 'repo-cognition.domains.local.md')
PATTERNS_STATE_PATH = os.path.join(PROJECT_DIR, '.claude', 'repo-cognition.patterns.local.md')
LOCK_PATH = os.path.join(INDEX_DIR, 'indexing.lock')
LAST_INDEX_PATH = os.path.join(INDEX_DIR, 'last_index.txt')
POLICIES_PATH = os.path.join(PROJECT_DIR, '.claude', 'repo-cognition.policies.local.md')
KNOWLEDGE_PATH = os.path.join(PROJECT_DIR, '.claude', 'repo-cognition.knowledge.local.md')


def set_project_dir(new_project_dir: str) -> None:
    """Recompute all path constants for a new project directory.

    Call this early in hooks/scripts when CLAUDE_PROJECT_DIR is determined.
    """
    global PROJECT_DIR, INDEX_DIR, DB_PATH, MANIFEST_PATH
    global SYMBOL_GRAPH_PATH, CALL_GRAPH_PATH, TAXONOMY_PATH, CLAUDE_MD_PATH
    global DOMAINS_STATE_PATH, PATTERNS_STATE_PATH, LOCK_PATH, LAST_INDEX_PATH
    global POLICIES_PATH, KNOWLEDGE_PATH

    PROJECT_DIR = os.path.abspath(new_project_dir)
    INDEX_DIR = os.path.join(PROJECT_DIR, '.claude', 'index', 'repo-cognition')
    DB_PATH = os.path.join(INDEX_DIR, 'index.db')
    MANIFEST_PATH = os.path.join(INDEX_DIR, 'file_manifest.json')
    SYMBOL_GRAPH_PATH = os.path.join(INDEX_DIR, 'symbol_graph.json')
    CALL_GRAPH_PATH = os.path.join(INDEX_DIR, 'call_graph.json')
    TAXONOMY_PATH = os.path.join(INDEX_DIR, 'project_taxonomy.md')
    CLAUDE_MD_PATH = os.path.join(INDEX_DIR, 'CLAUDE.md')
    DOMAINS_STATE_PATH = os.path.join(PROJECT_DIR, '.claude', 'repo-cognition.domains.local.md')
    PATTERNS_STATE_PATH = os.path.join(PROJECT_DIR, '.claude', 'repo-cognition.patterns.local.md')
    LOCK_PATH = os.path.join(INDEX_DIR, 'indexing.lock')
    LAST_INDEX_PATH = os.path.join(INDEX_DIR, 'last_index.txt')
    POLICIES_PATH = os.path.join(PROJECT_DIR, '.claude', 'repo-cognition.policies.local.md')
    KNOWLEDGE_PATH = os.path.join(PROJECT_DIR, '.claude', 'repo-cognition.knowledge.local.md')

    # Reset lazy cache
    global _resolved_project_dir, _resolved_index_dir
    _resolved_project_dir = PROJECT_DIR
    _resolved_index_dir = INDEX_DIR

    # Ensure index directory exists
    ensure_index_dir()


def ensure_index_dir() -> tuple[bool, str]:
    """Create the index directory and verify it's writable.

    Returns:
        (ok, error_message) — ok is True if the directory exists and is writable.
    """
    try:
        os.makedirs(INDEX_DIR, exist_ok=True)
        # Verify writability
        test_file = os.path.join(INDEX_DIR, '.write_test')
        try:
            with open(test_file, 'w') as f:
                f.write('ok')
            os.remove(test_file)
            return True, ''
        except (OSError, IOError) as e:
            return False, f'Index directory {INDEX_DIR} is not writable: {e}'
    except OSError as e:
        return False, f'Cannot create index directory {INDEX_DIR}: {e}'


def check_index_exists() -> bool:
    """Return True if the index database exists and has been initialized."""
    if not os.path.exists(DB_PATH):
        return False
    if os.path.getsize(DB_PATH) == 0:
        return False
    # Verify it's a real SQLite database with at least the schema_version table
    try:
        import sqlite3
        conn = sqlite3.connect(DB_PATH)
        try:
            tables = conn.execute(
                "SELECT COUNT(*) FROM sqlite_master WHERE type='table'"
            ).fetchone()[0]
            return tables > 0
        finally:
            conn.close()
    except sqlite3.Error:
        return False


def get_python_command() -> str:
    """Find a working Python interpreter.

    Tries: current sys.executable → 'python3' → 'python' → 'py' (Windows).

    Returns:
        Path or command name of a working Python interpreter.
    """
    # Strategy 1: The Python currently running
    if sys.executable:
        return sys.executable

    # Strategy 2: Common names on PATH
    candidates = ['python3', 'python']
    if sys.platform == 'win32':
        candidates = ['python', 'python3', 'py']

    for cmd in candidates:
        try:
            result = subprocess.run(
                [cmd, '--version'],
                capture_output=True, text=True, timeout=5,
                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0)
            )
            if result.returncode == 0:
                return cmd
        except (FileNotFoundError, subprocess.TimeoutExpired):
            continue

    # Last resort
    return 'python3'


# Ensure index directory exists on import
ensure_index_dir()
