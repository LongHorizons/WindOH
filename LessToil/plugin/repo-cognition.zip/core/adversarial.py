"""Adversarial Robustness — treat repository as potentially hostile.

Detects deceptive patterns: misleading names, hidden side effects,
semantic mismatches between declared purpose and implementation,
and hidden execution paths.
"""

from __future__ import annotations


def detect_deceptive_patterns(file_path: str, source: str = '') -> list[dict]:
    """Detect misleading names and deceptive code patterns.

    Checks: names that misrepresent behavior, hidden side effects,
    overly broad exception handlers, commented-out code in production paths.
    """
    findings = []
    try:
        from .manifest import get_connection
        conn = get_connection()
        try:
            # Symbols with 'get' prefix but have side effects
            cur = conn.execute(
                """SELECT s.name, s.kind
                   FROM symbols s JOIN files f ON s.file_id = f.id
                   WHERE f.file_path = ?
                     AND s.name LIKE 'get%'
                     AND s.has_side_effects = 1""",
                (file_path,)
            )
            for name, kind in cur.fetchall():
                findings.append({
                    'pattern': 'deceptive_prefix',
                    'symbol': name,
                    'kind': kind,
                    'detail': f"'{name}' has 'get' prefix but marked with side effects",
                    'severity': 'medium',
                })

            # Symbols with 'validate'/'check'/'verify' that don't return anything
            cur2 = conn.execute(
                """SELECT s.name, s.kind
                   FROM symbols s JOIN files f ON s.file_id = f.id
                   WHERE f.file_path = ?
                     AND (s.name LIKE 'validate%' OR s.name LIKE 'check%'
                          OR s.name LIKE 'verify%' OR s.name LIKE 'assert%')
                     AND s.kind IN ('function', 'method')
                     AND s.signature IS NOT NULL""",
                (file_path,)
            )
            for name, kind in cur2.fetchall():
                findings.append({
                    'pattern': 'validation_without_return',
                    'symbol': name,
                    'kind': kind,
                    'detail': f"'{name}' suggests boolean return but signature unclear",
                    'severity': 'low',
                })

            # Symbols named 'safe'/'secure' — often security theater
            cur3 = conn.execute(
                """SELECT s.name, s.kind
                   FROM symbols s JOIN files f ON s.file_id = f.id
                   WHERE f.file_path = ?
                     AND (s.name LIKE '%safe%' OR s.name LIKE '%secure%'
                          OR s.name LIKE '%trusted%')
                     AND s.security_sensitive = 0""",
                (file_path,)
            )
            for name, kind in cur3.fetchall():
                findings.append({
                    'pattern': 'security_theater',
                    'symbol': name,
                    'kind': kind,
                    'detail': f"'{name}' implies security but not marked as security-sensitive",
                    'severity': 'low',
                })
        finally:
            conn.close()
    except Exception:
        pass
    return findings


def detect_semantic_mismatch(symbol_name: str, declared_purpose: str = '') -> list[dict]:
    """Detect semantic mismatch between a symbol's name and its implementation."""
    mismatches = []
    try:
        from .manifest import get_connection
        conn = get_connection()
        try:
            cur = conn.execute(
                """SELECT s.name, s.kind, s.has_side_effects, s.security_sensitive,
                          COUNT(ce.callee_name) AS callee_count
                   FROM symbols s
                   LEFT JOIN call_edges ce ON s.id = ce.caller_id
                   WHERE s.name = ?
                   GROUP BY s.id""",
                (symbol_name,)
            )
            row = cur.fetchone()
            if row is None:
                return mismatches
            name, kind, side_effects, sec_sensitive, callee_count = row

            name_lower = name.lower()

            # 'pure' or 'immutable' but has side effects
            if any(w in name_lower for w in ('pure', 'immutable', 'const')) and side_effects:
                mismatches.append({
                    'symbol': name,
                    'mismatch': 'Claims purity but has side effects',
                    'severity': 'high',
                })

            # 'encrypt'/'hash' but not security sensitive
            if any(w in name_lower for w in ('encrypt', 'decrypt', 'hash', 'sign')) and not sec_sensitive:
                mismatches.append({
                    'symbol': name,
                    'mismatch': 'Cryptographic operation not marked security-sensitive',
                    'severity': 'high',
                })

            # 'delete'/'remove'/'destroy' but has side effects — usually correct
            # 'init'/'setup' that calls nothing — suspicious
            if any(w in name_lower for w in ('init', 'setup', 'configure')) and callee_count == 0:
                mismatches.append({
                    'symbol': name,
                    'mismatch': 'Initialization function with no dependencies — may be stub',
                    'severity': 'low',
                })
        finally:
            conn.close()
    except Exception:
        pass
    return mismatches


def detect_hidden_execution_paths(file_path: str) -> list[dict]:
    """Detect patterns that create hidden execution paths.

    Looks for: decorators on exported functions, metaclass usage,
    dynamic dispatch patterns, and monkey-patching indicators.
    """
    findings = []
    try:
        from .manifest import get_connection
        conn = get_connection()
        try:
            # Dynamic call edges indicate hidden paths
            cur = conn.execute(
                """SELECT s.name, COUNT(ce.id) AS dynamic_calls
                   FROM call_edges ce
                   JOIN symbols s ON ce.caller_id = s.id
                   JOIN files f ON s.file_id = f.id
                   WHERE f.file_path = ? AND ce.is_dynamic = 1
                   GROUP BY s.name""",
                (file_path,)
            )
            for name, count in cur.fetchall():
                findings.append({
                    'pattern': 'dynamic_dispatch',
                    'symbol': name,
                    'dynamic_calls': count,
                    'detail': f"'{name}' uses {count} dynamic calls — hidden execution paths",
                    'severity': 'medium',
                })
        finally:
            conn.close()
    except Exception:
        pass
    return findings
