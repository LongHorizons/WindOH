"""Cost-aware architecture governance.

Models build time, CI costs, cloud costs, and developer hours per change
to optimize architectural decisions for real economic impact.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class CostModel:
    build_time_minutes: float = 5.0
    ci_cost_monthly: float = 100.0
    cloud_cost_monthly: float = 200.0
    dev_hours_per_change: float = 2.0
    hourly_dev_cost: float = 100.0


def estimate_build_cost() -> dict:
    """Estimate build/maintenance costs from index data."""
    try:
        from .manifest import get_connection
        conn = get_connection()
        try:
            file_count = conn.execute("SELECT COUNT(*) FROM files").fetchone()[0]
            sym_count = conn.execute("SELECT COUNT(*) FROM symbols").fetchone()[0]
            total_lines = conn.execute(
                "SELECT COALESCE(SUM(line_count), 0) FROM files"
            ).fetchone()[0]
        finally:
            conn.close()
    except Exception:
        file_count, sym_count, total_lines = 0, 0, 0

    # Heuristic cost estimation
    build_minutes = max(1.0, file_count * 0.02 + total_lines * 0.0001)
    ci_monthly = max(20.0, file_count * 0.5)
    dev_hours_per_change = max(0.5, sym_count * 0.002)

    return {
        'estimated_build_time_minutes': round(build_minutes, 1),
        'estimated_ci_monthly_cost': round(ci_monthly, 2),
        'estimated_dev_hours_per_change': round(dev_hours_per_change, 2),
        'files': file_count,
        'symbols': sym_count,
        'total_lines': total_lines,
    }


def optimize_for_cost(target: str = 'build_time') -> list[dict]:
    """Propose cost-reducing architectural changes.

    Targets: 'build_time', 'ci_cost', 'dev_hours'
    """
    proposals = []
    try:
        from .manifest import get_connection
        conn = get_connection()
        try:
            # Largest files contribute most to build time
            cur = conn.execute(
                "SELECT file_path, line_count FROM files ORDER BY line_count DESC LIMIT 10"
            )
            for file_path, lines in cur.fetchall():
                if lines > 500:
                    proposals.append({
                        'target': target,
                        'file': file_path,
                        'current_lines': lines,
                        'action': f'Split {file_path} into smaller modules to reduce build time',
                        'estimated_savings': f'~{lines * 0.001:.1f} min build time',
                    })

            # High-churn files contribute most to CI cost
            cur2 = conn.execute(
                """SELECT tm.file_path, tm.risk_score, tm.total_commits
                   FROM temporal_metrics tm
                   ORDER BY tm.risk_score DESC LIMIT 10"""
            )
            for file_path, risk, commits in cur2.fetchall():
                if risk > 0.5:
                    proposals.append({
                        'target': 'ci_cost',
                        'file': file_path,
                        'risk_score': risk,
                        'commits': commits,
                        'action': f'Stabilize {file_path} to reduce CI churn cost',
                        'estimated_savings': f'~{risk * 20:.1f} CI minutes/month',
                    })
        finally:
            conn.close()
    except Exception:
        pass
    return proposals[:15]
