"""Knowledge Decay Detection — detect when assumptions rot.

Tracks when inferences were made, when their source data last changed,
and flags beliefs that may have expired. Prevents the system from
acting on stale information.
"""

from __future__ import annotations


def detect_stale_beliefs() -> list[dict]:
    """Find inferences whose source data has changed since recording.

    Checks evidence_records against file modification times and
    flags any inference where the underlying data may have changed.
    """
    stale = []
    try:
        from .manifest import get_connection
        conn = get_connection()
        try:
            # Expired inferences
            cur = conn.execute(
                """SELECT inference_id, inference_type, target, created_at, expires_at
                   FROM evidence_records
                   WHERE expires_at IS NOT NULL
                     AND datetime(expires_at) < datetime('now')
                   ORDER BY expires_at
                   LIMIT 50"""
            )
            for inf_id, inf_type, target, created, expires in cur.fetchall():
                stale.append({
                    'inference_id': inf_id,
                    'type': inf_type,
                    'target': target,
                    'created': created,
                    'expired': expires,
                    'reason': 'past_expiry',
                })

            # Inferences about files that have been reindexed since
            cur2 = conn.execute(
                """SELECT er.inference_id, er.inference_type, er.target,
                          er.created_at, f.last_indexed_at
                   FROM evidence_records er
                   JOIN files f ON f.file_path = er.target
                   WHERE er.created_at < f.last_indexed_at
                   LIMIT 50"""
            )
            for inf_id, inf_type, target, created, reindexed in cur2.fetchall():
                stale.append({
                    'inference_id': inf_id,
                    'type': inf_type,
                    'target': target,
                    'created': created,
                    'reindexed_at': reindexed,
                    'reason': 'source_data_changed',
                })
        finally:
            conn.close()
    except Exception:
        pass
    return stale[:100]


def compute_knowledge_freshness() -> dict:
    """Compute per-domain knowledge freshness scores.

    Freshness = 1.0 - (stale_inferences / total_inferences) per domain.
    """
    try:
        from .manifest import get_connection
        conn = get_connection()
        try:
            total = conn.execute(
                "SELECT COUNT(*) FROM evidence_records"
            ).fetchone()[0]
            if total == 0:
                return {'overall_freshness': 1.0, 'by_domain': {}, 'total': 0}

            stale_count = len(detect_stale_beliefs())
            freshness = 1.0 - (stale_count / total) if total > 0 else 1.0

            return {
                'overall_freshness': round(freshness, 3),
                'stale_count': stale_count,
                'total_inferences': total,
                'fresh_inferences': total - stale_count,
            }
        finally:
            conn.close()
    except Exception:
        return {'overall_freshness': 1.0, 'total': 0}
