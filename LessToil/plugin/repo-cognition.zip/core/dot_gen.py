#!/usr/bin/env python3
"""Generate DOT (Graphviz) graph files from the repository cognition index."""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from core import INDEX_DIR
from core.manifest import get_connection


GRAPH_OUTPUT_DIR = os.path.join(INDEX_DIR, 'graphs')


def _escape_dot(text: str) -> str:
    """Escape a string for DOT label use."""
    return text.replace('"', '\\"').replace('\n', ' ')


def generate_call_graph(symbol_name: str, direction: str = 'both',
                         max_depth: int = 3) -> str:
    """Generate a DOT call graph centered on a symbol.

    Args:
        symbol_name: The function/symbol to center the graph on
        direction: 'callers', 'callees', or 'both'
        max_depth: Maximum levels of indirection

    Returns:
        Path to the generated DOT file
    """
    conn = get_connection()
    try:
        nodes = {}
        edges = []

        def add_node(name, file_path, kind='function'):
            if name not in nodes:
                nodes[name] = {
                    'name': name,
                    'file': file_path or 'unknown',
                    'kind': kind,
                }

        # Color scheme by kind
        kind_colors = {
            'function': '#7BA7BC',
            'method': '#6A9FB5',
            'class': '#D4A76A',
            'endpoint': '#A5D6A7',
        }

        # BFS for callers
        if direction in ('callers', 'both'):
            visited = {symbol_name}
            frontier = [symbol_name]
            for depth in range(max_depth):
                next_frontier = []
                for name in frontier:
                    cur = conn.execute(
                        """SELECT DISTINCT s.name AS caller, f.file_path, s.kind
                           FROM call_edges ce
                           JOIN symbols s ON ce.caller_id = s.id
                           JOIN files f ON s.file_id = f.id
                           WHERE ce.callee_name = ?
                           LIMIT 30""",
                        (name,)
                    )
                    for caller, file_path, kind in cur.fetchall():
                        add_node(caller, file_path, kind)
                        edges.append((caller, name))
                        if caller not in visited:
                            visited.add(caller)
                            next_frontier.append(caller)
                frontier = next_frontier

        # BFS for callees
        if direction in ('callees', 'both'):
            visited = {symbol_name}
            frontier = [symbol_name]
            for depth in range(max_depth):
                next_frontier = []
                for name in frontier:
                    cur = conn.execute(
                        """SELECT DISTINCT ce.callee_name, ce.callee_file, s2.kind
                           FROM call_edges ce
                           JOIN symbols s ON ce.caller_id = s.id
                           LEFT JOIN symbols s2 ON ce.callee_name = s2.name
                           WHERE s.name = ?
                             AND ce.callee_name IS NOT NULL
                           LIMIT 30""",
                        (name,)
                    )
                    for callee, callee_file, kind in cur.fetchall():
                        if callee:
                            add_node(callee, callee_file, kind or 'function')
                            edges.append((name, callee))
                            if callee not in visited:
                                visited.add(callee)
                                next_frontier.append(callee)
                frontier = next_frontier

        # Also include the center symbol
        cur = conn.execute(
            "SELECT f.file_path, s.kind FROM symbols s JOIN files f ON s.file_id = f.id "
            "WHERE s.name = ? LIMIT 1",
            (symbol_name,)
        )
        row = cur.fetchone()
        if row:
            add_node(symbol_name, row[0], row[1] or 'function')
        else:
            add_node(symbol_name, 'unknown')

        # Generate DOT
        lines = ['digraph CallGraph {']
        lines.append('  rankdir=LR;')
        lines.append('  node [shape=box, style=rounded, fontname="Courier New", fontsize=10];')
        lines.append('  edge [fontname="Courier New", fontsize=8];')

        for node_id, node in nodes.items():
            color = kind_colors.get(node.get('kind', 'function'), '#BBBBBB')
            label = f"{node['name']}\\n{os.path.basename(node['file'])}"
            is_center = node_id == symbol_name
            style = 'bold' if is_center else 'solid'
            penwidth = '2' if is_center else '1'
            lines.append(
                f'  "{_escape_dot(node_id)}" [label="{_escape_dot(label)}", '
                f'fillcolor="{color}", style=filled,{style}, penwidth={penwidth}];'
            )

        for from_node, to_node in edges:
            lines.append(f'  "{_escape_dot(from_node)}" -> "{_escape_dot(to_node)}";')

        lines.append('}')

        os.makedirs(GRAPH_OUTPUT_DIR, exist_ok=True)
        dot_path = os.path.join(GRAPH_OUTPUT_DIR, f'{symbol_name.replace("/", "_")}.dot')
        with open(dot_path, 'w') as f:
            f.write('\n'.join(lines))

        return dot_path
    finally:
        conn.close()


def generate_domain_graph() -> str:
    """Generate a DOT graph showing cross-domain dependencies.

    Returns:
        Path to the generated DOT file
    """
    conn = get_connection()
    try:
        cur = conn.execute(
            """SELECT d1.name AS from_domain, d2.name AS to_domain,
                      COUNT(*) AS connections
               FROM call_edges ce
               JOIN symbols s_caller ON ce.caller_id = s_caller.id
               JOIN files f_caller ON s_caller.file_id = f_caller.id
               JOIN file_domains fd1 ON f_caller.id = fd1.file_id
               JOIN domains d1 ON fd1.domain_id = d1.id
               JOIN symbols s_callee ON ce.callee_name = s_callee.name
               JOIN files f_callee ON s_callee.file_id = f_callee.id
               JOIN file_domains fd2 ON f_callee.id = fd2.file_id
               JOIN domains d2 ON fd2.domain_id = d2.id
               WHERE d1.name != d2.name
               GROUP BY d1.name, d2.name
               ORDER BY connections DESC"""
        )
        edges = cur.fetchall()

        # Get all domains
        cur2 = conn.execute("SELECT name, security_boundary FROM domains ORDER BY name")
        domains = {r[0]: bool(r[1]) for r in cur2.fetchall()}

        lines = ['digraph DomainGraph {']
        lines.append('  rankdir=TB;')
        lines.append('  node [shape=box, style=rounded, fontname="Arial", fontsize=12];')
        lines.append('  edge [fontname="Arial", fontsize=9];')

        for domain_name, is_security in domains.items():
            color = '#FFB3B3' if is_security else '#B3D4FF'
            border = '#CC0000' if is_security else '#3366CC'
            penwidth = '3' if is_security else '1'
            lines.append(
                f'  "{_escape_dot(domain_name)}" [label="{_escape_dot(domain_name)}", '
                f'fillcolor="{color}", color="{border}", penwidth={penwidth}];'
            )

        for from_d, to_d, count in edges:
            penwidth = '1'
            if count > 20:
                penwidth = '3'
            elif count > 10:
                penwidth = '2'
            lines.append(
                f'  "{_escape_dot(from_d)}" -> "{_escape_dot(to_d)}" '
                f'[label="{count}", penwidth={penwidth}];'
            )

        lines.append('}')

        os.makedirs(GRAPH_OUTPUT_DIR, exist_ok=True)
        dot_path = os.path.join(GRAPH_OUTPUT_DIR, 'domain-graph.dot')
        with open(dot_path, 'w') as f:
            f.write('\n'.join(lines))

        return dot_path
    finally:
        conn.close()


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: python dot_gen.py <call-graph|domain-graph> [symbol_name]")
        sys.exit(1)

    mode = sys.argv[1]
    if mode == 'call-graph' and len(sys.argv) >= 3:
        symbol_name = sys.argv[2]
        path = generate_call_graph(symbol_name)
        print(f"Call graph written to {path}")
    elif mode == 'domain-graph':
        path = generate_domain_graph()
        print(f"Domain graph written to {path}")
    else:
        print("Usage: python dot_gen.py <call-graph|domain-graph> [symbol_name]")
        sys.exit(1)
