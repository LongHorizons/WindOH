"""Multi-Verifier Consensus Engine.

Runs independent verification passes and detects disagreement.
When verifiers disagree, the consensus engine resolves conflicts
by weighting verifier reliability and evidence quality.

Registered verifiers:
  - invariant_check (governance)
  - policy_check (governance)
  - simulation (simulation)
  - immune_check (immune_system)
  - formal_check (formal_constraints)
  - confidence_gate (confidence)
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class VerifierResult:
    name: str
    verdict: str  # 'pass', 'warn', 'block'
    details: list[str] = field(default_factory=list)
    evidence: list[dict] = field(default_factory=list)
    confidence: float = 0.5


class ConsensusEngine:
    """Orchestrates multiple verifiers and resolves disagreements."""

    def __init__(self):
        self.verifiers: dict[str, callable] = {}
        self._register_default_verifiers()

    def _register_default_verifiers(self) -> None:
        """Register built-in verifiers."""
        self.register_verifier('invariant_check', self._run_invariant_check)
        self.register_verifier('policy_check', self._run_policy_check)
        self.register_verifier('simulation', self._run_simulation_check)
        self.register_verifier('immune_check', self._run_immune_check)
        self.register_verifier('formal_check', self._run_formal_check)
        self.register_verifier('confidence_gate', self._run_confidence_gate)

    def register_verifier(self, name: str, fn: callable) -> None:
        """Register a custom verifier function."""
        self.verifiers[name] = fn

    def reach_consensus(self, file_paths: list[str]) -> dict:
        """Run all registered verifiers and resolve disagreements.

        Returns: {
            consensus: 'pass' | 'warn' | 'block',
            disagreements: [...],
            verifier_results: [...],
            resolved_by: str,
        }
        """
        results: list[VerifierResult] = []
        for name, fn in self.verifiers.items():
            try:
                result = fn(file_paths)
                results.append(result)
            except Exception:
                results.append(VerifierResult(
                    name=name, verdict='pass',
                    details=['Verifier failed — treating as pass for safety'],
                    confidence=0.0,
                ))

        # Aggregate verdicts
        blocks = [r for r in results if r.verdict == 'block']
        warns = [r for r in results if r.verdict == 'warn']
        passes = [r for r in results if r.verdict == 'pass']

        # Consensus logic
        if blocks:
            consensus = 'block'
            resolved_by = 'any_block'
        elif warns:
            # If multiple high-confidence verifiers warn, escalate
            high_conf_warns = [w for w in warns if w.confidence > 0.7]
            if len(high_conf_warns) >= 2:
                consensus = 'block'
                resolved_by = 'consensus_escalation'
            else:
                consensus = 'warn'
                resolved_by = 'majority_warn' if len(warns) > len(passes) else 'minority_warn'
        else:
            consensus = 'pass'
            resolved_by = 'unanimous'

        # Detect disagreements
        disagreements = []
        verdicts = set(r.verdict for r in results)
        if len(verdicts) > 1:
            for r1 in results:
                for r2 in results:
                    if r1.name < r2.name and r1.verdict != r2.verdict:
                        disagreements.append({
                            'verifier_a': r1.name,
                            'verdict_a': r1.verdict,
                            'verifier_b': r2.name,
                            'verdict_b': r2.verdict,
                        })

        return {
            'consensus': consensus,
            'resolved_by': resolved_by,
            'block': consensus == 'block',
            'disagreements': disagreements,
            'verifier_results': [
                {
                    'name': r.name,
                    'verdict': r.verdict,
                    'details': r.details,
                    'confidence': r.confidence,
                }
                for r in results
            ],
            'summary': f"Consensus: {consensus.upper()} "
                       f"({len(blocks)} block, {len(warns)} warn, "
                       f"{len(passes)} pass, {len(disagreements)} disagreements)",
        }

    # ------------------------------------------------------------------
    # Built-in verifier implementations
    # ------------------------------------------------------------------

    def _run_invariant_check(self, file_paths: list[str]) -> VerifierResult:
        try:
            from .governance import check_all_invariants
            inv = check_all_invariants()
            details = []
            if inv.get('errors'):
                details.append(f"{len(inv['errors'])} invariant errors")
            if inv.get('warnings'):
                details.append(f"{len(inv['warnings'])} invariant warnings")
            verdict = 'block' if inv.get('errors') else ('warn' if inv.get('warnings') else 'pass')
            return VerifierResult(
                name='invariant_check',
                verdict=verdict,
                details=details,
                evidence=[inv],
                confidence=0.9,
            )
        except Exception:
            return VerifierResult(name='invariant_check', verdict='pass')

    def _run_policy_check(self, file_paths: list[str]) -> VerifierResult:
        try:
            from .governance import check_policies_for_file
            errors = []
            warnings = []
            for fp in file_paths:
                pol = check_policies_for_file(fp)
                errors.extend(pol.get('errors', []))
                warnings.extend(pol.get('warnings', []))

            details = []
            if errors:
                details.append(f"{len(errors)} policy errors")
            if warnings:
                details.append(f"{len(warnings)} policy warnings")
            verdict = 'block' if errors else ('warn' if warnings else 'pass')
            return VerifierResult(
                name='policy_check',
                verdict=verdict,
                details=details,
                evidence=[{'errors': len(errors), 'warnings': len(warnings)}],
                confidence=0.85,
            )
        except Exception:
            return VerifierResult(name='policy_check', verdict='pass')

    def _run_simulation_check(self, file_paths: list[str]) -> VerifierResult:
        if len(file_paths) <= 1:
            return VerifierResult(
                name='simulation', verdict='pass',
                details=['Single file — simulation skipped'],
                confidence=0.5,
            )
        try:
            from .simulation import simulate_change
            sim = simulate_change(file_paths)
            grade = sim.get('grade', 'safe')
            verdict = 'block' if grade == 'dangerous' else ('warn' if grade == 'risky' else 'pass')
            return VerifierResult(
                name='simulation',
                verdict=verdict,
                details=[f"Grade: {grade}, {sim.get('reason', '')}"],
                evidence=[sim],
                confidence=0.7,
            )
        except Exception:
            return VerifierResult(name='simulation', verdict='pass')

    def _run_immune_check(self, file_paths: list[str]) -> VerifierResult:
        try:
            from .immune_system import ImmuneSystem
            system = ImmuneSystem()
            anomalies = system.detect_anomalies()
            if not anomalies:
                return VerifierResult(
                    name='immune_check', verdict='pass',
                    details=['No anomalies detected'],
                    confidence=0.6,
                )
            high = [a for a in anomalies if a.severity == 'high']
            verdict = 'block' if high else 'warn'
            return VerifierResult(
                name='immune_check',
                verdict=verdict,
                details=[a.description for a in anomalies],
                evidence=[{'anomalies': len(anomalies), 'high': len(high)}],
                confidence=0.65,
            )
        except Exception:
            return VerifierResult(name='immune_check', verdict='pass')

    def _run_formal_check(self, file_paths: list[str]) -> VerifierResult:
        try:
            from .formal_constraints import check_formal_constraints
            fc = check_formal_constraints(file_paths)
            details = []
            if fc.get('errors'):
                details.append(f"{len(fc['errors'])} constraint errors")
            if fc.get('warnings'):
                details.append(f"{len(fc['warnings'])} constraint warnings")
            verdict = 'block' if fc.get('block') else ('warn' if fc.get('warnings') else 'pass')
            return VerifierResult(
                name='formal_check',
                verdict=verdict,
                details=details,
                evidence=[fc],
                confidence=0.8,
            )
        except Exception:
            return VerifierResult(name='formal_check', verdict='pass')

    def _run_confidence_gate(self, file_paths: list[str]) -> VerifierResult:
        try:
            from .confidence import get_confidence_summary, LOW_CONFIDENCE_THRESHOLD
            conf = get_confidence_summary()
            avg = conf.get('avg_aggregate', 0.5)
            if avg < LOW_CONFIDENCE_THRESHOLD:
                return VerifierResult(
                    name='confidence_gate',
                    verdict='warn',
                    details=[f"Average confidence {avg:.2f} below threshold {LOW_CONFIDENCE_THRESHOLD}"],
                    evidence=[conf],
                    confidence=0.75,
                )
            return VerifierResult(
                name='confidence_gate',
                verdict='pass',
                details=[f"Average confidence: {avg:.2f}"],
                evidence=[conf],
                confidence=0.75,
            )
        except Exception:
            return VerifierResult(name='confidence_gate', verdict='pass')


# Module-level engine instance
_engine: ConsensusEngine | None = None


def _get_engine() -> ConsensusEngine:
    global _engine
    if _engine is None:
        _engine = ConsensusEngine()
    return _engine


def consensus_check(file_paths: list[str]) -> dict:
    """Unified decision function. Replaces individual governance/impact/
    simulation calls in pre_tool_use.py.

    Returns a dict with 'block', 'consensus', and 'verifier_results'.
    """
    return _get_engine().reach_consensus(file_paths)


def get_consensus_summary(file_paths: list[str]) -> dict:
    """Quick consensus summary for hook context injection."""
    result = consensus_check(file_paths)
    return {
        'consensus': result['consensus'],
        'block': result['block'],
        'verifiers': len(result['verifier_results']),
        'disagreements': len(result['disagreements']),
    }
