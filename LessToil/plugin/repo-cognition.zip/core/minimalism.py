"""Minimalism optimization layer.

Computes simplicity metrics for files and domains, tracking:
- abstraction_density: how many abstract/interface constructs per concrete
- dependency_entropy: randomness of the dependency graph
- state_surface_area: how many mutable fields/state accessors
- cross_domain_coupling: how entangled is this across domain boundaries
- indirection_depth: average call chain depth

Goal: continuously seek the "minimum sufficient system design."
"""

from __future__ import annotations

import math

from .manifest import get_connection


def compute_abstraction_density(file_path: str) -> float:
    """Compute ratio of abstract symbols to concrete implementations.

    High values suggest over-abstraction.
    """
    conn = get_connection()
    try:
        cur = conn.execute(
            """SELECT COUNT(*),
                      SUM(CASE WHEN s.kind IN ('interface', 'class', 'struct', 'enum',
                                                'trait', 'protocol', 'abstract')
                            THEN 1 ELSE 0 END)
               FROM symbols s JOIN files f ON s.file_id = f.id
               WHERE f.file_path = ?""",
            (file_path,)
        )
        row = cur.fetchone()
        if row is None or row[0] == 0:
            return 0.0
        total, abstracts = row
        return round(abstracts / total, 4)
    finally:
        conn.close()


def compute_dependency_entropy(file_path: str) -> float:
    """Compute Shannon entropy of the dependency distribution for this file.

    High entropy = highly unpredictable dependencies → complex.
    Low entropy = clear, focused dependencies → simple.
    """
    conn = get_connection()
    try:
        cur = conn.execute(
            """SELECT ce.callee_name, COUNT(*) AS call_count
               FROM call_edges ce
               JOIN symbols s ON ce.caller_id = s.id
               JOIN files f ON s.file_id = f.id
               WHERE f.file_path = ?
               GROUP BY ce.callee_name""",
            (file_path,)
        )
        calls = list(cur.fetchall())
        if not calls:
            return 0.0

        total = sum(c[1] for c in calls)
        entropy = 0.0
        for _, count in calls:
            p = count / total
            if p > 0:
                entropy -= p * math.log2(p)

        max_entropy = math.log2(len(calls)) if len(calls) > 1 else 1.0
        return round(min(1.0, entropy / max_entropy) if max_entropy > 0 else 0.0, 4)
    finally:
        conn.close()


def compute_state_surface_area(file_path: str) -> float:
    """Estimate exposed state surface: fields/variables that are publicly accessible.

    Returns 0-1 where 1 = maximum state exposure.
    """
    conn = get_connection()
    try:
        # Count exported symbols
        cur = conn.execute(
            """SELECT COUNT(*) FROM symbols s
               JOIN files f ON s.file_id = f.id
               WHERE f.file_path = ? AND s.is_exported = 1""",
            (file_path,)
        )
        exported = cur.fetchone()[0]

        # Count total symbols
        cur2 = conn.execute(
            """SELECT COUNT(*) FROM symbols s
               JOIN files f ON s.file_id = f.id
               WHERE f.file_path = ?""",
            (file_path,)
        )
        total = cur2.fetchone()[0]

        # Count side-effect-producing symbols
        cur3 = conn.execute(
            """SELECT COUNT(*) FROM symbols s
               JOIN files f ON s.file_id = f.id
               WHERE f.file_path = ? AND s.has_side_effects = 1""",
            (file_path,)
        )
        side_effects = cur3.fetchone()[0]

        if total == 0:
            return 0.0

        export_ratio = exported / total
        side_effect_ratio = side_effects / max(1, total)

        return round(0.6 * export_ratio + 0.4 * side_effect_ratio, 4)
    finally:
        conn.close()


def compute_cross_domain_coupling(file_path: str) -> float:
    """Measure how strongly this file couples across domain boundaries.

    Returns 0-1 where 1 = heavily cross-domain tangled.
    """
    conn = get_connection()
    try:
        # Get the file's domain
        cur = conn.execute(
            """SELECT d.name FROM domains d
               JOIN file_domains fd ON d.id = fd.domain_id
               JOIN files f ON fd.file_id = f.id
               WHERE f.file_path = ?""",
            (file_path,)
        )
        file_domains = {r[0] for r in cur.fetchall()}

        if not file_domains:
            return 0.0

        # Count cross-domain calls
        cur2 = conn.execute(
            """SELECT COUNT(DISTINCT ce.callee_name)
               FROM call_edges ce
               JOIN symbols s ON ce.caller_id = s.id
               JOIN files f ON s.file_id = f.id
               WHERE f.file_path = ?
                 AND ce.callee_name IN (
                     SELECT s2.name FROM symbols s2
                     JOIN files f2 ON s2.file_id = f2.id
                     JOIN file_domains fd2 ON f2.id = fd2.file_id
                     JOIN domains d2 ON fd2.domain_id = d2.id
                 )""",
            (file_path,)
        )
        cross_domain_calls = cur2.fetchone()[0]

        # Total calls from this file
        cur3 = conn.execute(
            """SELECT COUNT(*) FROM call_edges ce
               JOIN symbols s ON ce.caller_id = s.id
               JOIN files f ON s.file_id = f.id
               WHERE f.file_path = ?""",
            (file_path,)
        )
        total_calls = cur3.fetchone()[0]

        if total_calls == 0:
            return 0.0

        return round(min(1.0, cross_domain_calls / max(1, total_calls)), 4)
    finally:
        conn.close()


def compute_indirection_depth(file_path: str) -> float:
    """Compute average call chain depth originating from this file.

    Deep chains suggest excessive indirection.
    """
    conn = get_connection()
    try:
        cur = conn.execute(
            """WITH RECURSIVE chain AS (
                SELECT ce.callee_name, 1 AS depth
                FROM call_edges ce
                JOIN symbols s ON ce.caller_id = s.id
                JOIN files f ON s.file_id = f.id
                WHERE f.file_path = ?
                UNION ALL
                SELECT ce2.callee_name, ch.depth + 1
                FROM call_edges ce2
                JOIN symbols s2 ON ce2.caller_id = s2.id
                JOIN chain ch ON s2.name = ch.callee_name
                WHERE ch.depth < 10
            )
            SELECT AVG(depth), MAX(depth) FROM chain""",
            (file_path,)
        )
        row = cur.fetchone()
        if row is None or row[0] is None:
            return 0.0

        avg_depth, max_depth = row
        # Normalize to 0-1 where 1 = excessively deep (10+)
        return round(min(1.0, (avg_depth or 0) / 7.0), 4)
    finally:
        conn.close()


def compute_simplicity_score(file_path: str) -> dict:
    """Compute a composite simplicity score for a file.

    Returns dict with all component metrics and a composite score.
    Simplicity = 1 - complexity, so lower is simpler.
    """
    metrics = {
        'abstraction_density': compute_abstraction_density(file_path),
        'dependency_entropy': compute_dependency_entropy(file_path),
        'state_surface_area': compute_state_surface_area(file_path),
        'cross_domain_coupling': compute_cross_domain_coupling(file_path),
        'indirection_depth': compute_indirection_depth(file_path),
    }

    # Composite: weighted sum of the metrics (all 0-1, lower is better)
    composite = round(
        0.25 * metrics['abstraction_density'] +
        0.25 * metrics['dependency_entropy'] +
        0.20 * metrics['state_surface_area'] +
        0.15 * metrics['cross_domain_coupling'] +
        0.15 * metrics['indirection_depth'],
        4
    )

    # Simplicity = 1 - complexity
    metrics['simplicity_score'] = round(1.0 - composite, 4)
    metrics['complexity_score'] = composite

    return metrics


def get_minimalism_summary() -> dict:
    """Return a summary of minimalism metrics across the codebase."""
    conn = get_connection()
    try:
        cur = conn.execute("SELECT file_path FROM files LIMIT 50")
        files = [r[0] for r in cur.fetchall()]

        if not files:
            return {'files_analyzed': 0, 'average_simplicity': 1.0}

        scores = []
        for fp in files:
            try:
                s = compute_simplicity_score(fp)['simplicity_score']
                scores.append(s)
            except Exception:
                scores.append(0.5)

        avg = sum(scores) / len(scores)
        degraded = sum(1 for s in scores if s < 0.5)

        return {
            'files_analyzed': len(files),
            'average_simplicity': round(avg, 4),
            'degraded_files': degraded,
        }
    finally:
        conn.close()
