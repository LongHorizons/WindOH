"""Toolchain Auditor — every tool invocation recorded with verification trail.

Self-governing trust infrastructure: records what tools were called, on what
files, with what verification and consensus results, and whether actions were
approved or overridden. Enables audit reports and trust scoring.
"""

from __future__ import annotations

import json
from dataclasses import dataclass


@dataclass
class AuditEntry:
    tool_name: str
    file_paths: list[str] | None = None
    session_id: str = ''
    verification_result: str = ''
    consensus_result: str = ''
    approved: bool = True
    overridden: bool = False


def record_tool_audit(entry: AuditEntry) -> int:
    """Persist a tool invocation audit entry. Returns record id."""
    from .manifest import get_connection
    conn = get_connection()
    try:
        cur = conn.execute(
            """INSERT INTO toolchain_audit
               (tool_name, file_paths, session_id, verification_result,
                consensus_result, approved, overridden)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (entry.tool_name,
             json.dumps(entry.file_paths or []),
             entry.session_id,
             entry.verification_result,
             entry.consensus_result,
             int(entry.approved),
             int(entry.overridden))
        )
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


def generate_audit_report(session_id: str = '') -> dict:
    """Generate a human-readable audit trail report.

    If session_id is empty, reports on all sessions.
    """
    from .manifest import get_connection
    conn = get_connection()
    try:
        if session_id:
            cur = conn.execute(
                """SELECT tool_name, file_paths, verification_result,
                          consensus_result, approved, overridden, recorded_at
                   FROM toolchain_audit
                   WHERE session_id = ?
                   ORDER BY recorded_at DESC""",
                (session_id,)
            )
        else:
            cur = conn.execute(
                """SELECT tool_name, file_paths, verification_result,
                          consensus_result, approved, overridden, recorded_at
                   FROM toolchain_audit
                   ORDER BY recorded_at DESC
                   LIMIT 100"""
            )

        entries = []
        for tool_name, file_paths, ver_result, con_result, approved, overridden, recorded in cur.fetchall():
            entries.append({
                'tool': tool_name,
                'files': json.loads(file_paths or '[]'),
                'verification': ver_result,
                'consensus': con_result,
                'approved': bool(approved),
                'overridden': bool(overridden),
                'at': recorded,
            })

        total = len(entries)
        approved_count = sum(1 for e in entries if e['approved'])
        overridden_count = sum(1 for e in entries if e['overridden'])

        return {
            'session_id': session_id or 'all',
            'total_actions': total,
            'approved': approved_count,
            'overridden': overridden_count,
            'approval_rate': round(approved_count / total, 3) if total > 0 else 1.0,
            'entries': entries[:50],
        }
    finally:
        conn.close()


def compute_trust_score() -> dict:
    """Compute proportion of verified vs overridden actions.

    High trust = most actions pass verification without override.
    Low trust = frequent overrides suggest the system is unreliable.
    """
    from .manifest import get_connection
    conn = get_connection()
    try:
        total = conn.execute(
            "SELECT COUNT(*) FROM toolchain_audit"
        ).fetchone()[0]

        if total == 0:
            return {'trust_score': 1.0, 'total_actions': 0, 'interpretation': 'No data yet'}

        approved = conn.execute(
            "SELECT COUNT(*) FROM toolchain_audit WHERE approved = 1"
        ).fetchone()[0]

        overridden = conn.execute(
            "SELECT COUNT(*) FROM toolchain_audit WHERE overridden = 1"
        ).fetchone()[0]

        blocked = conn.execute(
            "SELECT COUNT(*) FROM toolchain_audit WHERE verification_result = 'blocked'"
        ).fetchone()[0]

        trust = round(approved / total, 3) if total > 0 else 1.0

        if trust > 0.9:
            interpretation = 'High trust — system is well-calibrated'
        elif trust > 0.7:
            interpretation = 'Moderate trust — occasional overrides expected'
        elif trust > 0.5:
            interpretation = 'Low trust — system frequently overridden'
        else:
            interpretation = 'Critical — system may need recalibration'

        return {
            'trust_score': trust,
            'total_actions': total,
            'approved': approved,
            'overridden': overridden,
            'blocked': blocked,
            'override_rate': round(overridden / total, 3) if total > 0 else 0.0,
            'interpretation': interpretation,
        }
    finally:
        conn.close()
