"""Confidence-weighted planning for symbol and file understanding.

Tracks certainty across four dimensions (parser, type, runtime, purpose)
so the agent can distinguish between high-confidence autonomous decisions
and low-confidence situations requiring user confirmation.

The runtime_confidence dimension starts at 0.5 (unknown) rather than 0.0
(definitely wrong) so aggregate confidence is usable even before profiling
data is available. Runtime feedback from profiling/test results adjusts it.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Optional

from .manifest import get_connection

# Language typing confidence — statically typed languages get higher scores
TYPED_LANGUAGES = {
    'typescript': 0.85, 'javascript': 0.40, 'python': 0.40,
    'go': 0.90, 'rust': 0.90, 'java': 0.85, 'csharp': 0.85,
    'kotlin': 0.85, 'swift': 0.85, 'c': 0.50, 'cpp': 0.50,
    'ruby': 0.35, 'php': 0.35, 'scala': 0.80, 'elixir': 0.70,
}

# Parser confidence by method
TREE_SITTER_CONFIDENCE = 0.90
REGEX_CONFIDENCE = 0.60
UNKNOWN_METHOD_CONFIDENCE = 0.30

# Thresholds
AUTONOMOUS_THRESHOLD = 0.85
LOW_CONFIDENCE_THRESHOLD = 0.50


@dataclass
class ConfidenceRecord:
    parser: float = 0.0
    type: float = 0.0
    runtime: float = 0.0
    purpose: float = 0.0

    @property
    def aggregate(self) -> float:
        return min(self.parser, self.type, self.runtime, self.purpose)

    def should_autonomously_decide(self) -> bool:
        return self.aggregate >= AUTONOMOUS_THRESHOLD

    def must_ask_user(self) -> bool:
        return self.aggregate < LOW_CONFIDENCE_THRESHOLD

    def to_dict(self) -> dict:
        return {
            'parser': self.parser, 'type': self.type,
            'runtime': self.runtime, 'purpose': self.purpose,
            'aggregate': self.aggregate,
        }


def compute_parser_confidence(method: str) -> float:
    if method == 'tree-sitter':
        return TREE_SITTER_CONFIDENCE
    elif method == 'regex':
        return REGEX_CONFIDENCE
    return UNKNOWN_METHOD_CONFIDENCE


def compute_type_confidence(language: str) -> float:
    return TYPED_LANGUAGES.get(language.lower(), 0.40)


def _infer_purpose_confidence(symbol_name: str, kind: str) -> float:
    """Heuristic purpose inference from symbol name and kind."""
    name_lower = symbol_name.lower()
    score = 0.3  # base

    # Structural clarity boosts
    if kind in ('function', 'method', 'class', 'struct', 'interface'):
        score += 0.1
    if kind in ('variable', 'constant', 'field'):
        score -= 0.05

    # Naming clarity
    verb_prefixes = ('get', 'set', 'create', 'delete', 'update', 'find',
                     'query', 'fetch', 'load', 'save', 'build', 'validate',
                     'parse', 'serialize', 'handle', 'process', 'compute')
    for prefix in verb_prefixes:
        if name_lower.startswith(prefix):
            score += 0.15
            break

    # Anti-patterns that reduce clarity
    if any(w in name_lower for w in ('temp', 'tmp', 'foo', 'bar', 'baz', 'test')):
        score -= 0.15
    if len(symbol_name) < 3:
        score -= 0.15
    if any(w in name_lower for w in ('impl', 'handler', 'manager', 'util', 'helper')):
        score -= 0.05  # vague, often bloated

    return max(0.0, min(1.0, score))


def store_confidence(symbol_id: int, record: ConfidenceRecord,
                      method: str = 'heuristic') -> None:
    conn = get_connection()
    try:
        conn.execute(
            """INSERT OR REPLACE INTO confidence_scores
               (symbol_id, parser_confidence, type_confidence,
                runtime_confidence, inferred_purpose_confidence,
                aggregate_confidence, assessed_at, assessed_by)
               VALUES (?, ?, ?, ?, ?, ?, datetime('now'), ?)""",
            (symbol_id, record.parser, record.type, record.runtime,
             record.purpose, record.aggregate, method)
        )
        conn.commit()
    finally:
        conn.close()


def get_symbol_confidence(symbol_id: int) -> Optional[ConfidenceRecord]:
    conn = get_connection()
    try:
        cur = conn.execute(
            """SELECT parser_confidence, type_confidence, runtime_confidence,
                      inferred_purpose_confidence
               FROM confidence_scores WHERE symbol_id = ?""",
            (symbol_id,)
        )
        row = cur.fetchone()
        if row is None:
            return None
        return ConfidenceRecord(
            parser=row[0], type=row[1], runtime=row[2], purpose=row[3]
        )
    finally:
        conn.close()


def get_low_confidence_symbols(limit: int = 20) -> list[dict]:
    conn = get_connection()
    try:
        cur = conn.execute(
            """SELECT s.name, s.kind, f.file_path, cs.aggregate_confidence
               FROM confidence_scores cs
               JOIN symbols s ON cs.symbol_id = s.id
               JOIN files f ON s.file_id = f.id
               WHERE cs.aggregate_confidence < ?
               ORDER BY cs.aggregate_confidence ASC
               LIMIT ?""",
            (LOW_CONFIDENCE_THRESHOLD, limit)
        )
        return [
            {'name': r[0], 'kind': r[1], 'file': r[2], 'confidence': r[3]}
            for r in cur.fetchall()
        ]
    finally:
        conn.close()


def get_file_confidence(file_path: str) -> Optional[ConfidenceRecord]:
    conn = get_connection()
    try:
        cur = conn.execute(
            """SELECT AVG(cs.parser_confidence), AVG(cs.type_confidence),
                      AVG(cs.runtime_confidence), AVG(cs.inferred_purpose_confidence)
               FROM confidence_scores cs
               JOIN symbols s ON cs.symbol_id = s.id
               JOIN files f ON s.file_id = f.id
               WHERE f.file_path = ?""",
            (file_path,)
        )
        row = cur.fetchone()
        if row is None or row[0] is None:
            return None
        return ConfidenceRecord(
            parser=row[0], type=row[1], runtime=row[2], purpose=row[3]
        )
    finally:
        conn.close()


def get_confidence_summary() -> dict:
    conn = get_connection()
    try:
        total = conn.execute(
            "SELECT COUNT(*) FROM confidence_scores"
        ).fetchone()[0]
        if total == 0:
            return {'total': 0, 'low_confidence': 0, 'avg_aggregate': 0.0}

        low = conn.execute(
            "SELECT COUNT(*) FROM confidence_scores WHERE aggregate_confidence < ?",
            (LOW_CONFIDENCE_THRESHOLD,)
        ).fetchone()[0]

        avg_agg = conn.execute(
            "SELECT AVG(aggregate_confidence) FROM confidence_scores"
        ).fetchone()[0] or 0.0

        avg_parser = conn.execute(
            "SELECT AVG(parser_confidence) FROM confidence_scores"
        ).fetchone()[0] or 0.0

        avg_type = conn.execute(
            "SELECT AVG(type_confidence) FROM confidence_scores"
        ).fetchone()[0] or 0.0

        return {
            'total': total,
            'low_confidence': low,
            'avg_aggregate': round(avg_agg, 3),
            'avg_parser': round(avg_parser, 3),
            'avg_type': round(avg_type, 3),
        }
    finally:
        conn.close()


def compute_and_store(file_id: int, symbol_name: str, kind: str,
                       language: str, method: str = 'tree-sitter') -> int:
    """Compute confidence for a symbol and store it. Returns symbol_id."""
    conn = get_connection()
    try:
        cur = conn.execute(
            "SELECT id FROM symbols WHERE file_id = ? AND name = ? AND kind = ? "
            "ORDER BY id DESC LIMIT 1",
            (file_id, symbol_name, kind)
        )
        row = cur.fetchone()
        if row is None:
            return -1

        symbol_id = row[0]
        record = ConfidenceRecord(
            parser=compute_parser_confidence(method),
            type=compute_type_confidence(language),
            runtime=0.5,  # unknown, not definitely wrong
            purpose=_infer_purpose_confidence(symbol_name, kind),
        )
        store_confidence(symbol_id, record, method)

        # Also update the symbol's cached confidence_score
        conn.execute(
            "UPDATE symbols SET confidence_score = ? WHERE id = ?",
            (record.aggregate, symbol_id)
        )
        conn.commit()
        return symbol_id
    finally:
        conn.close()


def compute_confidence_batch(file_id: int, symbols: list[dict],
                              language: str, method: str = 'tree-sitter') -> int:
    """Compute and store confidence for a batch of symbols. Returns count of successes."""
    count = 0
    for sym in symbols:
        sid = compute_and_store(
            file_id, sym.get('name', ''), sym.get('kind', ''),
            language, method
        )
        if sid > 0:
            count += 1
    return count


# ---------------------------------------------------------------------------
# Runtime confidence feedback loop
# ---------------------------------------------------------------------------

@dataclass
class ConfidenceFeedback:
    symbol_id: int
    feedback_type: str  # 'test_pass', 'test_fail', 'profiling_hot', 'profiling_cold'
    delta: float        # positive = increase confidence, negative = decrease
    source: str = ''
    evidence_id: str = ''


def update_runtime_confidence(file_path: str) -> int:
    """Update runtime confidence for symbols in a file using profiling snapshots.

    Checks if any hot functions in recent profile snapshots match symbols
    in the given file and boosts runtime confidence accordingly. Symbols
    that appear in profiling data get a confidence boost; others remain at
    their current level.

    Returns the number of symbols updated.
    """
    conn = get_connection()
    try:
        # Get symbols in the file
        cur = conn.execute(
            """SELECT s.id, s.name FROM symbols s
               JOIN files f ON s.file_id = f.id
               WHERE f.file_path = ?""",
            (file_path,)
        )
        symbols = [(r[0], r[1]) for r in cur.fetchall()]
        if not symbols:
            return 0

        # Get hot function names from recent profile snapshots
        hot_names: set[str] = set()
        try:
            cur2 = conn.execute(
                "SELECT profile_data FROM profile_snapshots ORDER BY id DESC LIMIT 5"
            )
            for (data_json,) in cur2.fetchall():
                try:
                    data = json.loads(data_json)
                    for hf in data.get('hot_functions', []):
                        hot_names.add(hf.get('function', ''))
                    for ms in data.get('mapped_symbols', []):
                        hot_names.add(ms.get('profiled_function', ''))
                except (json.JSONDecodeError, TypeError):
                    pass
        except Exception:
            pass

        updated = 0
        for symbol_id, symbol_name in symbols:
            current = get_symbol_confidence(symbol_id)
            if current is None:
                continue

            new_runtime = current.runtime
            if symbol_name in hot_names:
                new_runtime = min(1.0, current.runtime + 0.25)
            elif hot_names:
                new_runtime = max(0.3, current.runtime - 0.05)

            if new_runtime != current.runtime:
                new_record = ConfidenceRecord(
                    parser=current.parser,
                    type=current.type,
                    runtime=new_runtime,
                    purpose=current.purpose,
                )
                store_confidence(symbol_id, new_record, 'runtime_update')
                conn.execute(
                    "UPDATE symbols SET confidence_score = ? WHERE id = ?",
                    (new_record.aggregate, symbol_id)
                )
                updated += 1

        conn.commit()
        return updated
    finally:
        conn.close()


def apply_feedback(feedback: ConfidenceFeedback) -> bool:
    """Apply a feedback signal to adjust confidence for a symbol.

    Positive deltas (test_pass, profiling_hot) increase runtime confidence.
    Negative deltas (test_fail, profiling_cold) decrease it.

    Returns True if the update was applied.
    """
    conn = get_connection()
    try:
        current = get_symbol_confidence(feedback.symbol_id)
        if current is None:
            return False

        new_runtime = max(0.0, min(1.0, current.runtime + feedback.delta))
        new_record = ConfidenceRecord(
            parser=current.parser,
            type=current.type,
            runtime=new_runtime,
            purpose=current.purpose,
        )
        store_confidence(feedback.symbol_id, new_record, feedback.source or 'feedback')
        conn.execute(
            "UPDATE symbols SET confidence_score = ? WHERE id = ?",
            (new_record.aggregate, feedback.symbol_id)
        )
        conn.commit()
        return True
    finally:
        conn.close()


def feedback_loop(file_path: str) -> dict:
    """Gather evidence and adjust confidence for all symbols in a file.

    Called from PostToolUse after reindex to incorporate runtime signals.
    Returns a summary of adjustments made.
    """
    updated = update_runtime_confidence(file_path)

    conn = get_connection()
    try:
        cur = conn.execute(
            """SELECT AVG(cs.aggregate_confidence)
               FROM confidence_scores cs
               JOIN symbols s ON cs.symbol_id = s.id
               JOIN files f ON s.file_id = f.id
               WHERE f.file_path = ?""",
            (file_path,)
        )
        row = cur.fetchone()
        avg_confidence = round(row[0], 3) if row and row[0] else 0.0
    finally:
        conn.close()

    return {
        'file_path': file_path,
        'symbols_updated': updated,
        'avg_confidence_after': avg_confidence,
    }
