"""Semantic Compression — detect equivalent paradigms beyond literal duplication.

Goes beyond SimHash by detecting semantically equivalent but differently-named
abstractions. Flags merge candidates where two symbols serve the same purpose
under different names.
"""

from __future__ import annotations


def canonicalize_abstractions() -> list[dict]:
    """Detect semantically equivalent but differently-named patterns.

    Uses heuristics: same kind + similar signature structure + similar name
    semantic domain. Returns merge candidates.
    """
    candidates = []
    try:
        from .manifest import get_connection
        conn = get_connection()
        try:
            # Find groups of symbols with same kind and similar name structure
            cur = conn.execute(
                """SELECT s1.name AS name_a, s2.name AS name_b,
                          s1.kind, f1.file_path AS file_a,
                          f2.file_path AS file_b
                   FROM symbols s1
                   JOIN symbols s2 ON s1.kind = s2.kind
                     AND s1.id < s2.id
                     AND ABS(LENGTH(s1.name) - LENGTH(s2.name)) <= 3
                   JOIN files f1 ON s1.file_id = f1.id
                   JOIN files f2 ON s2.file_id = f2.id
                   WHERE s1.is_exported = 1 AND s2.is_exported = 1
                     AND f1.file_path != f2.file_path
                   LIMIT 100"""
            )
            for name_a, name_b, kind, file_a, file_b in cur.fetchall():
                similarity = _name_semantic_similarity(name_a, name_b)
                if similarity > 0.6:
                    candidates.append({
                        'symbol_a': name_a,
                        'symbol_b': name_b,
                        'kind': kind,
                        'file_a': file_a,
                        'file_b': file_b,
                        'semantic_similarity': round(similarity, 2),
                        'recommendation': f"'{name_a}' and '{name_b}' may be equivalent — consider consolidating",
                    })
        finally:
            conn.close()
    except Exception:
        pass
    return candidates[:20]


def _name_semantic_similarity(a: str, b: str) -> float:
    """Compute semantic similarity between two symbol names."""
    a_lower = a.lower().replace('_', '').replace('-', '')
    b_lower = b.lower().replace('_', '').replace('-', '')

    # Same base with different prefixes/suffixes
    if a_lower in b_lower or b_lower in a_lower:
        return 0.8

    # Check shared substrings
    shorter = min(len(a_lower), len(b_lower))
    if shorter == 0:
        return 0.0

    matches = sum(1 for i in range(shorter) if a_lower[i] == b_lower[i])
    return matches / max(len(a_lower), len(b_lower))


def collapse_equivalent_paradigms(threshold: float = 0.7) -> list[dict]:
    """Flag merge candidates above the similarity threshold.

    Returns actionable suggestions for collapsing equivalent abstractions
    into canonical forms.
    """
    candidates = canonicalize_abstractions()
    return [
        {
            'merge_candidate': f"{c['symbol_a']} ↔ {c['symbol_b']}",
            'similarity': c['semantic_similarity'],
            'files': f"{c['file_a']}, {c['file_b']}",
            'kind': c['kind'],
            'action': 'Extract shared interface or canonical implementation',
        }
        for c in candidates
        if c['semantic_similarity'] >= threshold
    ]
