"""Operational Sovereignty — the cognition system must survive its own failures.

Provides health checks, corruption detection and repair, and operational
status assessment. Ensures the system degrades gracefully rather than
failing catastrophically.
"""

from __future__ import annotations

import os


def health_check() -> dict:
    """Run comprehensive health check on the cognition infrastructure.

    Checks: DB integrity, index freshness, lock staleness, disk space.
    """
    checks = []

    # 1. Database integrity
    try:
        from .manifest import get_connection, DB_PATH
        conn = get_connection()
        try:
            result = conn.execute("PRAGMA integrity_check").fetchone()
            db_ok = result[0] == 'ok'
            checks.append({
                'check': 'database_integrity',
                'status': 'pass' if db_ok else 'fail',
                'detail': str(result[0]),
            })
        finally:
            conn.close()
    except Exception as e:
        checks.append({
            'check': 'database_integrity',
            'status': 'fail',
            'detail': str(e),
        })

    # 2. Index freshness
    try:
        from . import LAST_INDEX_PATH
        if os.path.exists(LAST_INDEX_PATH):
            with open(LAST_INDEX_PATH) as f:
                last_index = f.read().strip()
            checks.append({
                'check': 'index_freshness',
                'status': 'pass',
                'detail': f'Last indexed: {last_index}',
            })
        else:
            checks.append({
                'check': 'index_freshness',
                'status': 'warn',
                'detail': 'No last index timestamp found',
            })
    except Exception as e:
        checks.append({
            'check': 'index_freshness',
            'status': 'warn',
            'detail': str(e),
        })

    # 3. Lock staleness
    try:
        from . import LOCK_PATH
        if os.path.exists(LOCK_PATH):
            lock_age = os.path.getmtime(LOCK_PATH)
            if os.path.getmtime(LOCK_PATH) < os.path.getmtime(LOCK_PATH) - 3600:
                checks.append({
                    'check': 'lock_staleness',
                    'status': 'warn',
                    'detail': 'Lock file is over 1 hour old — may be stale',
                })
            else:
                checks.append({
                    'check': 'lock_staleness',
                    'status': 'pass',
                    'detail': 'Lock is recent',
                })
        else:
            checks.append({
                'check': 'lock_staleness',
                'status': 'pass',
                'detail': 'No lock file (idle)',
            })
    except Exception:
        checks.append({
            'check': 'lock_staleness',
            'status': 'pass',
            'detail': 'Could not check lock',
        })

    # 4. Required directories exist
    try:
        from . import INDEX_DIR
        if os.path.isdir(INDEX_DIR):
            checks.append({
                'check': 'index_directory',
                'status': 'pass',
                'detail': INDEX_DIR,
            })
        else:
            checks.append({
                'check': 'index_directory',
                'status': 'fail',
                'detail': f'{INDEX_DIR} does not exist',
            })
    except Exception as e:
        checks.append({
            'check': 'index_directory',
            'status': 'fail',
            'detail': str(e),
        })

    failed = [c for c in checks if c['status'] == 'fail']
    warned = [c for c in checks if c['status'] == 'warn']

    return {
        'healthy': len(failed) == 0,
        'checks': checks,
        'failed': len(failed),
        'warnings': len(warned),
    }


def recover_from_corruption() -> dict:
    """Attempt to detect and repair corrupted index entries.

    Removes file entries where the on-disk file no longer exists,
    and symbols referencing deleted files.
    """
    repairs = []
    try:
        from .manifest import get_connection
        from . import PROJECT_DIR

        conn = get_connection()
        try:
            # Find files in index that no longer exist on disk
            cur = conn.execute("SELECT id, file_path FROM files")
            for file_id, file_path in cur.fetchall():
                full_path = os.path.join(PROJECT_DIR, file_path)
                if not os.path.exists(full_path):
                    conn.execute("DELETE FROM files WHERE id = ?", (file_id,))
                    repairs.append({
                        'action': 'removed_stale_file',
                        'file': file_path,
                        'reason': 'File no longer exists on disk',
                    })

            conn.commit()
        finally:
            conn.close()
    except Exception as e:
        return {'repairs': len(repairs), 'error': str(e)}

    return {'repairs': len(repairs), 'details': repairs}


def is_operational() -> dict:
    """Determine if the cognition system can function despite partial outages.

    Returns operational status with degraded capabilities enumerated.
    """
    hc = health_check()
    degraded = [c for c in hc['checks'] if c['status'] in ('warn', 'fail')]

    if hc['healthy']:
        status = 'fully_operational'
    elif hc['failed'] <= 2:
        status = 'degraded'
    else:
        status = 'critical'

    return {
        'status': status,
        'healthy': hc['healthy'],
        'degraded_capabilities': [d['check'] for d in degraded],
        'recommendation': (
            'All systems operational' if status == 'fully_operational'
            else 'Run /index-rebuild to restore full capability' if status == 'degraded'
            else 'Critical failure — reinitialize with /index-rebuild'
        ),
    }
