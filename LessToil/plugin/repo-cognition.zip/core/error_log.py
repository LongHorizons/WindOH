"""Persistent error logging for the Repository Cognition Engine.

Replaces silent `except Exception: pass` blocks across all hooks and commands
with timestamped, auto-rotated logs that users can inspect when things go wrong.
"""

from __future__ import annotations

import os
import sys
import traceback
from datetime import datetime, timezone

from . import INDEX_DIR

ERROR_LOG_PATH = os.path.join(INDEX_DIR, 'errors.log')
MAX_LOG_SIZE = 1_048_576  # 1 MB auto-rotation threshold
MAX_LOG_LINES = 500  # Keep the most recent 500 entries on rotation


def _ensure_index_dir() -> None:
    """Create the index directory if it doesn't exist."""
    try:
        os.makedirs(INDEX_DIR, exist_ok=True)
    except OSError:
        pass  # We'll try to log anyway; the open() call will surface the error


def log_error(module: str, message: str, exc_info: object = None) -> None:
    """Append an error entry to the persistent error log.

    Args:
        module: Name of the module or hook where the error occurred.
        message: Human-readable description of the error.
        exc_info: Optional exception info tuple from sys.exc_info().
    """
    _ensure_index_dir()

    timestamp = datetime.now(timezone.utc).isoformat()
    tb_str = ''
    if exc_info and exc_info != (None, None, None):
        try:
            tb_str = '\n' + ''.join(traceback.format_exception(*exc_info))
        except Exception:
            tb_str = '\n(traceback unavailable)'

    pid = os.getpid()
    entry = f'[{timestamp}] [PID:{pid}] [{module}] {message}{tb_str}\n'

    try:
        # Auto-rotate if the log file exceeds the size limit
        if os.path.exists(ERROR_LOG_PATH) and os.path.getsize(ERROR_LOG_PATH) > MAX_LOG_SIZE:
            _rotate_log()

        with open(ERROR_LOG_PATH, 'a', encoding='utf-8') as f:
            f.write(entry)
    except Exception:
        # Last resort: print to stderr so at least the debug console shows it
        print(f'[repo-cognition] [{module}] {message}', file=sys.stderr)


def log_warning(module: str, message: str) -> None:
    """Log a non-fatal warning. Same signature as log_error for simplicity."""
    log_error(module, f'WARNING: {message}')


def get_recent_errors(n: int = 50) -> list[str]:
    """Return the most recent N error entries from the log.

    Returns an empty list if the log file doesn't exist or can't be read.
    """
    if not os.path.exists(ERROR_LOG_PATH):
        return []
    try:
        with open(ERROR_LOG_PATH, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        # Return the last N lines (most recent)
        return [line.rstrip('\n') for line in lines[-n:]]
    except Exception:
        return []


def get_error_count() -> int:
    """Return the total number of error entries currently in the log."""
    if not os.path.exists(ERROR_LOG_PATH):
        return 0
    try:
        with open(ERROR_LOG_PATH, 'r', encoding='utf-8') as f:
            return sum(1 for _ in f)
    except Exception:
        return 0


def clear_error_log() -> None:
    """Truncate the error log. Used after a successful full rebuild."""
    try:
        if os.path.exists(ERROR_LOG_PATH):
            os.remove(ERROR_LOG_PATH)
    except OSError:
        pass


def _rotate_log() -> None:
    """Rotate the error log: keep only the most recent MAX_LOG_LINES entries."""
    try:
        with open(ERROR_LOG_PATH, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        # Keep only the tail entries
        if len(lines) > MAX_LOG_LINES:
            lines = lines[-MAX_LOG_LINES:]
        with open(ERROR_LOG_PATH, 'w', encoding='utf-8') as f:
            f.writelines(lines)
    except Exception:
        pass


def format_error_summary(errors: list[str]) -> str:
    """Format a compact error summary suitable for display in the dashboard."""
    if not errors:
        return ''

    lines = ['  --  INDEXING WARNINGS']
    for e in errors[-8:]:
        # Truncate long messages for dashboard display
        truncated = e[:120] + ('...' if len(e) > 120 else '')
        lines.append(f'     !!  {truncated}')
    if len(errors) > 8:
        lines.append(f'     ... and {len(errors) - 8} more (see {ERROR_LOG_PATH})')
    lines.append('')
    return '\n'.join(lines)
