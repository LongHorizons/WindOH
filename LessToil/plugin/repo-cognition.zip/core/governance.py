"""Architectural governance engine: invariants and policy enforcement.

Invariants are SQL queries where 0 rows = satisfied, >0 rows = violation.
They enforce what MUST remain true about the architecture.

Policies are configurable threshold-based checks (max complexity, max depth,
forbidden patterns) enforced via Python function checks.

PreToolUse integration: invariants and policy errors block with exit code 2;
warnings produce advisory systemMessages.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass

from .manifest import get_connection

# Severity levels
SEVERITY_ERROR = 'error'
SEVERITY_WARNING = 'warning'
SEVERITY_INFO = 'info'

# Configuration paths
POLICIES_CONFIG_PATH = '.claude/repo-cognition.policies.local.md'


# ---------------------------------------------------------------------------
# Invariant management
# ---------------------------------------------------------------------------

@dataclass
class Invariant:
    name: str
    description: str
    query: str
    severity: str = SEVERITY_ERROR
    enabled: bool = True


BUILTIN_INVARIANTS = [
    Invariant(
        name='auth_domain_isolation',
        description='Auth domain must not import from UI domain',
        query="""SELECT DISTINCT s.name, f.file_path
FROM call_edges ce
JOIN symbols s ON ce.caller_id = s.id
JOIN files f ON s.file_id = f.id
JOIN file_domains fd_caller ON f.id = fd_caller.file_id
JOIN domains d_caller ON fd_caller.domain_id = d_caller.id
WHERE d_caller.name = 'ui'
  AND ce.callee_name IN (
    SELECT DISTINCT s2.name FROM symbols s2
    JOIN file_domains fd2 ON s2.file_id = fd2.file_id
    JOIN domains d2 ON fd2.domain_id = d2.id
    WHERE d2.name = 'auth'
  )""",
        severity=SEVERITY_ERROR,
    ),
    Invariant(
        name='no_direct_db_from_ui',
        description='UI components must not directly access database symbols',
        query="""SELECT DISTINCT s.name, f.file_path
FROM symbols s
JOIN files f ON s.file_id = f.id
JOIN file_domains fd ON f.id = fd.file_id
JOIN domains d ON fd.domain_id = d.id
WHERE d.name = 'ui'
  AND (s.name LIKE '%database%' OR s.name LIKE '%db%'
       OR s.name LIKE '%query%' OR s.name LIKE '%sql%'
       OR s.name LIKE '%execute%' OR s.name LIKE '%cursor%')""",
        severity=SEVERITY_WARNING,
    ),
    Invariant(
        name='no_circular_domains',
        description='Architectural domains must not have circular dependencies',
        query="""WITH RECURSIVE domain_deps AS (
    SELECT DISTINCT
        d1.name AS source_domain,
        d2.name AS dep_domain,
        1 AS depth
    FROM call_edges ce
    JOIN symbols s_caller ON ce.caller_id = s_caller.id
    JOIN files f_caller ON s_caller.file_id = f_caller.id
    JOIN file_domains fd_caller ON f_caller.id = fd_caller.file_id
    JOIN domains d1 ON fd_caller.domain_id = d1.id
    JOIN symbols s_callee ON s_callee.name = ce.callee_name
    JOIN files f_callee ON s_callee.file_id = f_callee.id
    JOIN file_domains fd_callee ON f_callee.id = fd_callee.file_id
    JOIN domains d2 ON fd_callee.domain_id = d2.id
    WHERE d1.name != d2.name
    UNION ALL
    SELECT dd.source_domain, d3.name AS dep_domain, dd.depth + 1
    FROM domain_deps dd
    JOIN call_edges ce ON ce.callee_name IN (
        SELECT s.name FROM symbols s
        JOIN file_domains fd ON s.file_id = fd.file_id
        JOIN domains d ON fd.domain_id = d.id
        WHERE d.name = dd.dep_domain
    )
    JOIN symbols s_caller ON ce.caller_id = s_caller.id
    JOIN files f_caller ON s_caller.file_id = f_caller.id
    JOIN file_domains fd_caller ON f_caller.id = fd_caller.file_id
    JOIN domains d3 ON fd_caller.domain_id = d3.id
    WHERE d3.name != dd.dep_domain AND dd.depth < 10
)
SELECT source_domain, dep_domain, MIN(depth) AS min_depth
FROM domain_deps
WHERE source_domain = dep_domain
GROUP BY source_domain, dep_domain""",
        severity=SEVERITY_ERROR,
    ),
]


def register_invariant(name: str, description: str, query: str,
                        severity: str = SEVERITY_ERROR, enabled: bool = True) -> int:
    """Register a new invariant rule. Returns the invariant id."""
    conn = get_connection()
    try:
        cur = conn.execute(
            """INSERT OR REPLACE INTO invariants (name, description, query, severity, enabled)
               VALUES (?, ?, ?, ?, ?)""",
            (name, description, query, severity, int(enabled))
        )
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


def get_invariants(enabled_only: bool = True) -> list[dict]:
    """Get all registered invariants."""
    conn = get_connection()
    try:
        where = "WHERE enabled = 1" if enabled_only else ""
        cur = conn.execute(
            f"SELECT id, name, description, query, severity, enabled FROM invariants {where}"
        )
        return [
            {'id': r[0], 'name': r[1], 'description': r[2],
             'query': r[3], 'severity': r[4], 'enabled': bool(r[5])}
            for r in cur.fetchall()
        ]
    finally:
        conn.close()


def init_builtin_invariants() -> int:
    """Register all built-in invariants. Returns count registered."""
    count = 0
    for inv in BUILTIN_INVARIANTS:
        register_invariant(inv.name, inv.description, inv.query,
                           inv.severity, inv.enabled)
        count += 1
    return count


# ---------------------------------------------------------------------------
# Invariant checking
# ---------------------------------------------------------------------------

def check_invariant(invariant_id: int) -> list[dict]:
    """Run an invariant query and return violations (empty list = satisfied)."""
    conn = get_connection()
    try:
        cur = conn.execute(
            "SELECT name, query, severity FROM invariants WHERE id = ? AND enabled = 1",
            (invariant_id,)
        )
        row = cur.fetchone()
        if row is None:
            return []

        name, query, severity = row
        try:
            cur2 = conn.execute(query)
            violations = []
            for vrow in cur2.fetchall():
                violation = {'invariant': name, 'severity': severity}
                for i, col in enumerate(cur2.description):
                    violation[col[0]] = vrow[i]
                violations.append(violation)
            return violations
        except Exception as e:
            return [{'invariant': name, 'severity': severity,
                     'error': f'Query failed: {e}'}]
    finally:
        conn.close()


def check_all_invariants() -> dict:
    """Run all enabled invariants. Returns summary with violations grouped by severity."""
    invariants = get_invariants(enabled_only=True)
    results = {'errors': [], 'warnings': [], 'passed': 0, 'total': len(invariants)}

    for inv in invariants:
        violations = check_invariant(inv['id'])
        if not violations:
            results['passed'] += 1
        elif violations[0].get('error'):
            # Query failure
            results['warnings'].append({
                'invariant': inv['name'],
                'detail': violations[0]['error'],
            })
        else:
            for v in violations:
                entry = {'invariant': v['invariant'], 'detail': str(v)}
                if v.get('severity') == SEVERITY_ERROR:
                    results['errors'].append(entry)
                else:
                    results['warnings'].append(entry)

    return results


def record_violation(invariant_name: str, file_path: str, detail: str,
                      session_id: str = '') -> None:
    """Record an invariant violation."""
    conn = get_connection()
    try:
        cur = conn.execute(
            "SELECT id FROM invariants WHERE name = ?", (invariant_name,)
        )
        row = cur.fetchone()
        if row is None:
            return
        conn.execute(
            """INSERT INTO invariant_violations (invariant_id, file_path, detail, session_id)
               VALUES (?, ?, ?, ?)""",
            (row[0], file_path, detail, session_id)
        )
        conn.commit()
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Pre-edit simulation
# ---------------------------------------------------------------------------

def simulate_edit(file_path: str, old_content: str, new_content: str) -> dict:
    """Simulate the effect of an edit on invariants.

    Creates a temporary view to check if the proposed change would violate
    any invariants. Since SQLite doesn't support true temp views across
    connections, we use a simplified approach: check if the file being
    edited is in a domain with invariants, and pre-check those invariants.

    Returns: {'block': bool, 'warnings': list[str], 'violations': list[dict]}
    """
    result = {'block': False, 'warnings': [], 'violations': []}

    invariants = get_invariants(enabled_only=True)
    if not invariants:
        return result

    # Check existing violations that this file participates in
    conn = get_connection()
    try:
        # Find domains the file belongs to
        cur = conn.execute(
            """SELECT d.name FROM domains d
               JOIN file_domains fd ON d.id = fd.domain_id
               JOIN files f ON fd.file_id = f.id
               WHERE f.file_path = ?""",
            (file_path,)
        )
        file_domains = {r[0] for r in cur.fetchall()}
    finally:
        conn.close()

    # Check invariants related to this file's domains
    for inv in invariants:
        # Check if the invariant query involves this file's domains
        query_lower = inv['query'].lower()
        relevant = any(d.lower() in query_lower for d in file_domains)
        if file_path.lower() in query_lower:
            relevant = True

        if not relevant:
            # Also run a quick check - if the file_path appears in any
            # existing violation for this invariant, include it
            continue

        violations = check_invariant(inv['id'])
        if violations:
            for v in violations:
                entry = {'invariant': inv['name'], 'detail': str(v)}
                if inv['severity'] == SEVERITY_ERROR:
                    result['violations'].append(entry)
                    if not v.get('error'):
                        result['block'] = True
                else:
                    result['warnings'].append(
                        f"Invariant '{inv['name']}': {inv['description']}"
                    )

    return result


# ---------------------------------------------------------------------------
# Policy management (Phase 4)
# ---------------------------------------------------------------------------

@dataclass
class Policy:
    name: str
    category: str
    description: str
    threshold_value: float
    severity: str = SEVERITY_WARNING
    enabled: bool = True


BUILTIN_POLICIES = [
    Policy(
        name='max_function_complexity',
        category='complexity',
        description='Functions should not exceed the specified line count',
        threshold_value=80,
        severity=SEVERITY_WARNING,
    ),
    Policy(
        name='max_dependency_depth',
        category='complexity',
        description='Call chain depth should not exceed the specified maximum',
        threshold_value=5,
        severity=SEVERITY_WARNING,
    ),
    Policy(
        name='max_file_size',
        category='complexity',
        description='Files should not exceed the specified line count',
        threshold_value=1000,
        severity=SEVERITY_WARNING,
    ),
    Policy(
        name='max_parameters',
        category='complexity',
        description='Functions should not exceed the specified parameter count',
        threshold_value=6,
        severity=SEVERITY_WARNING,
    ),
    Policy(
        name='forbid_circular_deps',
        category='architecture',
        description='Circular dependencies between modules are forbidden',
        threshold_value=0,
        severity=SEVERITY_ERROR,
    ),
    Policy(
        name='require_tests_for_security_paths',
        category='security',
        description='Security-sensitive symbols must have corresponding tests',
        threshold_value=0,
        severity=SEVERITY_WARNING,
    ),
]


def register_policy(name: str, category: str, description: str,
                     threshold_value: float, severity: str = SEVERITY_WARNING,
                     enabled: bool = True) -> int:
    """Register a new policy rule. Returns the policy id."""
    conn = get_connection()
    try:
        cur = conn.execute(
            """INSERT OR REPLACE INTO policies
               (name, category, description, threshold_value, severity, enabled)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (name, category, description, threshold_value, severity, int(enabled))
        )
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


def get_policies(enabled_only: bool = True, category: str = '') -> list[dict]:
    """Get all registered policies."""
    conn = get_connection()
    try:
        where = "WHERE enabled = 1" if enabled_only else "WHERE 1=1"
        params = []
        if category:
            where += " AND category = ?"
            params.append(category)
        cur = conn.execute(
            f"SELECT id, name, category, description, threshold_value, severity, enabled "
            f"FROM policies {where} ORDER BY category, name",
            params
        )
        return [
            {'id': r[0], 'name': r[1], 'category': r[2], 'description': r[3],
             'threshold_value': r[4], 'severity': r[5], 'enabled': bool(r[6])}
            for r in cur.fetchall()
        ]
    finally:
        conn.close()


def init_builtin_policies() -> int:
    """Register all built-in policies. Returns count registered."""
    count = 0
    for pol in BUILTIN_POLICIES:
        register_policy(pol.name, pol.category, pol.description,
                        pol.threshold_value, pol.severity, pol.enabled)
        count += 1
    return count


# ---------------------------------------------------------------------------
# Policy checking
# ---------------------------------------------------------------------------

def check_policy_function_complexity(file_path: str, threshold: float) -> list[dict]:
    """Check if functions in a file exceed complexity threshold (lines)."""
    conn = get_connection()
    try:
        cur = conn.execute(
            """SELECT s.name, s.start_line, s.end_line,
                      (s.end_line - s.start_line) AS length
               FROM symbols s
               JOIN files f ON s.file_id = f.id
               WHERE f.file_path = ? AND s.kind IN ('function', 'method')
                 AND s.end_line IS NOT NULL AND s.start_line IS NOT NULL
                 AND (s.end_line - s.start_line) > ?
               ORDER BY length DESC""",
            (file_path, threshold)
        )
        return [
            {'symbol': r[0], 'start_line': r[1], 'end_line': r[2],
             'length': r[3], 'threshold': threshold}
            for r in cur.fetchall()
        ]
    finally:
        conn.close()


def check_policy_string(params):
    pass


def check_policy_max_file_size(file_path: str, threshold: float) -> list[dict]:
    """Check if a file exceeds the line count threshold."""
    conn = get_connection()
    try:
        cur = conn.execute(
            "SELECT line_count FROM files WHERE file_path = ?", (file_path,)
        )
        row = cur.fetchone()
        if row and row[0] > threshold:
            return [{'file': file_path, 'line_count': row[0], 'threshold': threshold}]
        return []
    finally:
        conn.close()


def check_policy_max_parameters(file_path: str, threshold: float) -> list[dict]:
    """Check if functions have too many parameters (heuristic from signature)."""
    conn = get_connection()
    try:
        cur = conn.execute(
            """SELECT s.name, s.signature
               FROM symbols s JOIN files f ON s.file_id = f.id
               WHERE f.file_path = ? AND s.kind IN ('function', 'method')
                 AND s.signature IS NOT NULL""",
            (file_path,)
        )
        violations = []
        for name, sig in cur.fetchall():
            # Count commas in parameter list
            param_match = sig.find('(')
            if param_match >= 0:
                param_end = sig.find(')', param_match)
                if param_end > param_match:
                    params = sig[param_match + 1:param_end]
                    param_count = params.count(',') + 1 if params.strip() else 0
                    if param_count > threshold:
                        violations.append({
                            'symbol': name, 'param_count': param_count,
                            'threshold': threshold,
                        })
        return violations
    finally:
        conn.close()


def check_policy_require_tests(file_path: str, threshold: float = 0) -> list[dict]:
    """Check if security-sensitive symbols have corresponding tests."""
    conn = get_connection()
    try:
        cur = conn.execute(
            """SELECT s.name
               FROM symbols s JOIN files f ON s.file_id = f.id
               WHERE f.file_path = ? AND s.security_sensitive = 1""",
            (file_path,)
        )
        security_symbols = [r[0] for r in cur.fetchall()]
        if not security_symbols:
            return []

        violations = []
        for sym_name in security_symbols:
            cur2 = conn.execute(
                """SELECT COUNT(*) FROM call_edges ce
                   JOIN symbols s2 ON ce.caller_id = s2.id
                   JOIN files f2 ON s2.file_id = f2.id
                   WHERE ce.callee_name = ?
                     AND (f2.file_path LIKE '%test%'
                          OR f2.file_path LIKE '%spec%'
                          OR f2.file_path LIKE '%__tests__%')""",
                (sym_name,)
            )
            if cur2.fetchone()[0] == 0:
                violations.append({
                    'symbol': sym_name,
                    'detail': 'Security-sensitive symbol has no test coverage',
                })
        return violations
    finally:
        conn.close()


def check_policy_max_dependency_depth(file_path: str, threshold: float) -> list[dict]:
    """Check if any call chain from this file exceeds the max depth."""
    conn = get_connection()
    try:
        # Find symbols in the file
        cur = conn.execute(
            "SELECT name FROM symbols s JOIN files f ON s.file_id = f.id "
            "WHERE f.file_path = ?",
            (file_path,)
        )
        symbols = [r[0] for r in cur.fetchall()]
        if not symbols:
            return []

        violations = []
        for sym_name in symbols[:10]:  # limit to first 10 symbols for performance
            # Simple depth check: count levels in recursive CTE
            cur2 = conn.execute(
                """WITH RECURSIVE deps AS (
                    SELECT ce.callee_name, 1 AS depth
                    FROM call_edges ce
                    JOIN symbols s ON ce.caller_id = s.id
                    WHERE s.name = ?
                    UNION ALL
                    SELECT ce2.callee_name, d.depth + 1
                    FROM call_edges ce2
                    JOIN symbols s2 ON ce2.caller_id = s2.id
                    JOIN deps d ON s2.name = d.callee_name
                    WHERE d.depth < ?
                )
                SELECT MAX(depth) FROM deps""",
                (sym_name, int(threshold) + 10)
            )
            row = cur2.fetchone()
            if row and row[0] and row[0] > threshold:
                violations.append({
                    'symbol': sym_name, 'max_depth': row[0],
                    'threshold': threshold,
                })
        return violations
    finally:
        conn.close()


POLICY_CHECKERS = {
    'max_function_complexity': check_policy_function_complexity,
    'max_file_size': check_policy_max_file_size,
    'max_parameters': check_policy_max_parameters,
    'max_dependency_depth': check_policy_max_dependency_depth,
    'require_tests_for_security_paths': check_policy_require_tests,
}


def check_policies_for_file(file_path: str) -> dict:
    """Run all enabled policy checks against a single file.

    Returns: {'errors': [...], 'warnings': [...]}
    """
    result = {'errors': [], 'warnings': []}
    policies = get_policies(enabled_only=True)

    for pol in policies:
        checker = POLICY_CHECKERS.get(pol['name'])
        if checker is None:
            continue
        try:
            violations = checker(file_path, pol['threshold_value'])
            if violations:
                entry = {
                    'policy': pol['name'],
                    'category': pol['category'],
                    'violations': violations,
                }
                if pol['severity'] == SEVERITY_ERROR:
                    result['errors'].append(entry)
                else:
                    result['warnings'].append(entry)

                # Record to database
                conn = get_connection()
                try:
                    for v in violations:
                        conn.execute(
                            """INSERT INTO policy_violations
                               (policy_id, file_path, detail, detected_at)
                               VALUES (?, ?, ?, datetime('now'))""",
                            (pol['id'], file_path, json.dumps(v))
                        )
                    conn.commit()
                finally:
                    conn.close()
        except Exception:
            pass

    return result


def record_policy_violation(policy_name: str, file_path: str, detail: str,
                             session_id: str = '') -> None:
    """Record a policy violation to the database."""
    conn = get_connection()
    try:
        cur = conn.execute(
            "SELECT id FROM policies WHERE name = ?", (policy_name,)
        )
        row = cur.fetchone()
        if row is None:
            return
        conn.execute(
            """INSERT INTO policy_violations (policy_id, file_path, detail, session_id)
               VALUES (?, ?, ?, ?)""",
            (row[0], file_path, detail, session_id)
        )
        conn.commit()
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Comprehensive governance check (used by PreToolUse hook)
# ---------------------------------------------------------------------------

def check_governance(file_paths: list[str], session_id: str = '') -> dict:
    """Run all governance checks for the given files.

    This is the main entry point for the PreToolUse hook.

    Returns: {
        'block': bool,        # True if exit code 2 should be returned
        'errors': [str],      # Error messages (blocking)
        'warnings': [str],    # Warning messages (advisory)
    }
    """
    result = {'block': False, 'errors': [], 'warnings': []}

    # Run invariant checks
    try:
        invariant_results = check_all_invariants()
        for err in invariant_results.get('errors', []):
            result['errors'].append(
                f"INVARIANT VIOLATION: {err['invariant']} — {err['detail']}"
            )
            result['block'] = True
        for warn in invariant_results.get('warnings', []):
            result['warnings'].append(
                f"Invariant warning: {warn['invariant']} — {warn['detail']}"
            )
    except Exception:
        pass

    # Run policy checks per file
    for file_path in file_paths:
        try:
            pol_result = check_policies_for_file(file_path)
            for err in pol_result.get('errors', []):
                result['errors'].append(
                    f"POLICY VIOLATION: {err['policy']} in {file_path}"
                )
                result['block'] = True
                # Record violations
                for v in err.get('violations', []):
                    record_policy_violation(
                        err['policy'], file_path, json.dumps(v), session_id
                    )
            for warn in pol_result.get('warnings', []):
                result['warnings'].append(
                    f"Policy warning: {warn['policy']} in {file_path}"
                )
                for v in warn.get('violations', []):
                    record_policy_violation(
                        warn['policy'], file_path, json.dumps(v), session_id
                    )
        except Exception:
            pass

    return result


# ---------------------------------------------------------------------------
# Configuration persistence
# ---------------------------------------------------------------------------

def load_policies_from_md(project_dir: str) -> dict:
    """Load policies and invariants from .claude/repo-cognition.policies.local.md."""
    config_path = os.path.join(project_dir, POLICIES_CONFIG_PATH)
    if not os.path.exists(config_path):
        return {'policies': [], 'invariants': []}

    import re
    import yaml
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            content = f.read()
        # Extract YAML frontmatter
        match = re.match(r'^---\s*\n(.*?)\n---', content, re.DOTALL)
        if match:
            return yaml.safe_load(match.group(1)) or {}
    except Exception:
        pass
    return {'policies': [], 'invariants': []}


def export_policies_to_md(project_dir: str) -> str:
    """Export current policies/invariants to .claude/repo-cognition.policies.local.md."""
    invariants = get_invariants(enabled_only=False)
    policies = get_policies(enabled_only=False)

    lines = [
        '---',
        '# Repo Cognition Governance Configuration',
        '# Edit this file to customize invariant and policy rules.',
        '',
    ]

    if invariants:
        lines.append('invariants:')
        for inv in invariants:
            lines.append(f'  - name: {inv["name"]}')
            lines.append(f'    description: "{inv["description"]}"')
            lines.append(f'    severity: {inv["severity"]}')
            lines.append(f'    enabled: {str(inv["enabled"]).lower()}')
            lines.append('')

    if policies:
        lines.append('policies:')
        for pol in policies:
            lines.append(f'  - name: {pol["name"]}')
            lines.append(f'    category: {pol["category"]}')
            lines.append(f'    description: "{pol["description"]}"')
            lines.append(f'    threshold_value: {pol["threshold_value"]}')
            lines.append(f'    severity: {pol["severity"]}')
            lines.append(f'    enabled: {str(pol["enabled"]).lower()}')
            lines.append('')

    lines.append('---')

    yaml_content = '\n'.join(lines)
    config_path = os.path.join(project_dir, POLICIES_CONFIG_PATH)
    try:
        os.makedirs(os.path.dirname(config_path), exist_ok=True)
    except OSError:
        pass
    try:
        with open(config_path, 'w', encoding='utf-8') as f:
            f.write(yaml_content)
    except OSError:
        pass

    return config_path


def get_governance_summary() -> dict:
    """Return a summary of governance state for dashboards."""
    conn = get_connection()
    try:
        inv_count = conn.execute(
            "SELECT COUNT(*) FROM invariants WHERE enabled = 1"
        ).fetchone()[0]
        pol_count = conn.execute(
            "SELECT COUNT(*) FROM policies WHERE enabled = 1"
        ).fetchone()[0]

        inv_violations = conn.execute(
            "SELECT COUNT(*) FROM invariant_violations WHERE resolved_at IS NULL"
        ).fetchone()[0]
        pol_violations = conn.execute(
            "SELECT COUNT(*) FROM policy_violations WHERE resolved_at IS NULL"
        ).fetchone()[0]

        return {
            'invariants': inv_count,
            'policies': pol_count,
            'unresolved_invariant_violations': inv_violations,
            'unresolved_policy_violations': pol_violations,
        }
    finally:
        conn.close()
