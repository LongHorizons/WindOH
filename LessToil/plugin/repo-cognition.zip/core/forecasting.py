"""Long-horizon architectural forecasting + autonomous experimentation.

Projects architectural trends forward, synthesizes alternative topologies,
and benchmarks them against defined fitness criteria.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class FutureState:
    label: str
    horizon: str  # '1x', '2x', '5x', '10x'
    projected_files: int = 0
    projected_symbols: int = 0
    projected_domains: int = 0
    projected_avg_drift: float = 0.0
    risks: list[str] = field(default_factory=list)
    recommendations: list[str] = field(default_factory=list)


class ArchitecturalForecaster:
    """Projects current architectural metrics forward under growth assumptions."""

    def forecast_10x(self) -> list[FutureState]:
        """Project architectural state at 1x, 2x, 5x, and 10x scale."""
        try:
            from .manifest import get_connection
            conn = get_connection()
            try:
                files = conn.execute("SELECT COUNT(*) FROM files").fetchone()[0]
                symbols = conn.execute("SELECT COUNT(*) FROM symbols").fetchone()[0]
                domains = conn.execute("SELECT COUNT(*) FROM domains").fetchone()[0]
                avg_drift = conn.execute(
                    "SELECT AVG(architectural_drift_score) FROM files"
                ).fetchone()[0] or 0.0

                sym_per_file = symbols / files if files > 0 else 5
            finally:
                conn.close()
        except Exception:
            files, symbols, domains, avg_drift = 100, 500, 5, 0.1
            sym_per_file = 5

        horizons = [
            ('1x', 1), ('2x', 2), ('5x', 5), ('10x', 10),
        ]
        states = []
        for label, scale in horizons:
            proj_files = files * scale
            proj_syms = int(proj_files * sym_per_file)
            proj_domains = min(domains * (1 + 0.3 * (scale - 1)), 30)
            drift_growth = 0.02 * (scale - 1)
            proj_drift = min(1.0, avg_drift + drift_growth)

            risks = []
            recommendations = []
            if proj_files > 500:
                risks.append(f"File count ({proj_files}) may need domain partitioning")
                recommendations.append("Introduce subdomain boundaries at 500+ files")
            if proj_drift > 0.4:
                risks.append(f"Drift projected at {proj_drift:.2f} — architectural erosion likely")
                recommendations.append("Establish drift budget and automated enforcement")
            if proj_domains > 15:
                risks.append(f"Domain count ({int(proj_domains)}) may cause coupling complexity")
                recommendations.append("Implement domain interface contracts")

            states.append(FutureState(
                label=label, horizon=label,
                projected_files=proj_files,
                projected_symbols=proj_syms,
                projected_domains=int(proj_domains),
                projected_avg_drift=round(proj_drift, 4),
                risks=risks,
                recommendations=recommendations,
            ))
        return states


def synthesize_alternatives(goal: str = 'reduce_coupling') -> list[dict]:
    """Synthesize alternative architectural topologies for a given goal."""
    alternatives = {
        'reduce_coupling': [
            {'name': 'domain_facade', 'description': 'Introduce facade per domain, hide internals',
             'effort': 'large', 'risk': 'medium', 'benefit': 'high'},
            {'name': 'event_bus', 'description': 'Replace direct calls with event bus/pub-sub',
             'effort': 'large', 'risk': 'high', 'benefit': 'high'},
            {'name': 'interface_segregation', 'description': 'Split large interfaces by client need',
             'effort': 'medium', 'risk': 'low', 'benefit': 'medium'},
        ],
        'reduce_complexity': [
            {'name': 'extract_module', 'description': 'Split largest files into focused modules',
             'effort': 'medium', 'risk': 'low', 'benefit': 'high'},
            {'name': 'remove_abstraction', 'description': 'Inline single-use abstractions',
             'effort': 'low', 'risk': 'low', 'benefit': 'medium'},
            {'name': 'standardize_patterns', 'description': 'Replace ad-hoc patterns with canonical ones',
             'effort': 'large', 'risk': 'medium', 'benefit': 'high'},
        ],
        'improve_testability': [
            {'name': 'dependency_injection', 'description': 'Inject dependencies rather than hardcoding',
             'effort': 'large', 'risk': 'medium', 'benefit': 'high'},
            {'name': 'pure_core', 'description': 'Extract pure logic from effectful wrappers',
             'effort': 'medium', 'risk': 'low', 'benefit': 'high'},
        ],
    }
    return alternatives.get(goal, [
        {'name': 'incremental', 'description': 'Incremental improvement in small steps',
         'effort': 'low', 'risk': 'low', 'benefit': 'low'},
    ])


def benchmark_topology(alternatives: list[dict]) -> list[dict]:
    """Rank alternatives by a composite score of benefit/effort/risk."""
    scored = []
    for alt in alternatives:
        benefit_score = {'low': 1, 'medium': 2, 'high': 3}.get(alt.get('benefit', 'low'), 1)
        effort_score = {'low': 1, 'medium': 2, 'large': 3}.get(alt.get('effort', 'medium'), 2)
        risk_score = {'low': 1, 'medium': 2, 'high': 3}.get(alt.get('risk', 'medium'), 2)
        composite = round((benefit_score * 2 - effort_score - risk_score) / 3.0, 2)
        scored.append({**alt, 'composite_score': composite})
    scored.sort(key=lambda a: a['composite_score'], reverse=True)
    return scored
