"""Human Cognitive Load Modeling.

Measures how difficult code is for humans to understand, debug, and modify.
Optimizes for operational cognition — the mental cost of working with the code.
"""

from __future__ import annotations


def compute_understandability(file_path: str) -> dict:
    """Estimate how understandable a file is for a human reader.

    Considers: naming clarity, structural coherence, documentation quality.
    Returns scores from 0.0 (incomprehensible) to 1.0 (clear).
    """
    score = 0.5  # neutral baseline
    factors = []

    try:
        from .manifest import get_connection
        conn = get_connection()
        try:
            # Get file info
            cur = conn.execute(
                "SELECT language, line_count FROM files WHERE file_path = ?",
                (file_path,)
            )
            row = cur.fetchone()
            if row is None:
                return {'score': 0.5, 'factors': ['file not indexed']}
            language, line_count = row

            # Line count: very long files hurt understandability
            if line_count > 1000:
                score -= 0.2
                factors.append('very_large_file')
            elif line_count > 500:
                score -= 0.1
                factors.append('large_file')
            elif line_count < 50:
                score += 0.05

            # Naming quality: check for vague names
            cur2 = conn.execute(
                """SELECT s.name FROM symbols s
                   JOIN files f ON s.file_id = f.id
                   WHERE f.file_path = ?""",
                (file_path,)
            )
            names = [r[0] for r in cur2.fetchall()]
            vague_count = sum(
                1 for n in names
                if any(w in n.lower() for w in ('temp', 'tmp', 'foo', 'bar', 'data', 'info'))
            )
            if names:
                vague_ratio = vague_count / len(names)
                if vague_ratio > 0.2:
                    score -= 0.15
                    factors.append('vague_names')

            # Documentation: check for docstrings/comments
            cur3 = conn.execute(
                """SELECT COUNT(*) FROM symbols s
                   JOIN files f ON s.file_id = f.id
                   WHERE f.file_path = ? AND s.docstring IS NOT NULL""",
                (file_path,)
            )
            documented = cur3.fetchone()[0]
            if names and documented / len(names) > 0.5:
                score += 0.1
                factors.append('well_documented')
            elif names and documented == 0:
                score -= 0.05
                factors.append('no_documentation')
        finally:
            conn.close()
    except Exception:
        pass

    return {
        'file': file_path,
        'score': round(max(0.0, min(1.0, score)), 3),
        'factors': factors,
    }


def compute_debugging_difficulty(file_path: str) -> dict:
    """Estimate how hard a file is to debug.

    Considers: coupling count, indirection depth, side effects, call chain depth.
    """
    score = 0.3  # base difficulty
    factors = []

    try:
        from .manifest import get_connection
        conn = get_connection()
        try:
            # Count callers (coupling)
            cur = conn.execute(
                """SELECT COUNT(DISTINCT ce.caller_id)
                   FROM call_edges ce
                   JOIN symbols s ON s.name = ce.callee_name
                   JOIN files f ON s.file_id = f.id
                   WHERE f.file_path = ?""",
                (file_path,)
            )
            caller_count = cur.fetchone()[0]
            if caller_count > 20:
                score += 0.3
                factors.append('high_coupling')
            elif caller_count > 10:
                score += 0.15
                factors.append('moderate_coupling')

            # Count symbols with side effects
            cur2 = conn.execute(
                """SELECT COUNT(*) FROM symbols s
                   JOIN files f ON s.file_id = f.id
                   WHERE f.file_path = ? AND s.has_side_effects = 1""",
                (file_path,)
            )
            side_effect_count = cur2.fetchone()[0]
            if side_effect_count > 5:
                score += 0.2
                factors.append('many_side_effects')
        finally:
            conn.close()
    except Exception:
        pass

    return {
        'file': file_path,
        'score': round(min(1.0, score), 3),
        'factors': factors,
    }


def compute_conceptual_compression(file_path: str) -> dict:
    """Estimate how well concepts are compressed (high cohesion, low conceptual sprawl).

    Good compression = fewer distinct domain concepts per file, each well-developed.
    """
    try:
        from .manifest import get_connection
        conn = get_connection()
        try:
            cur = conn.execute(
                """SELECT COUNT(DISTINCT d.name)
                   FROM domains d
                   JOIN file_domains fd ON d.id = fd.domain_id
                   JOIN files f ON fd.file_id = f.id
                   WHERE f.file_path = ?""",
                (file_path,)
            )
            domain_count = cur.fetchone()[0]
        finally:
            conn.close()

        if domain_count == 1:
            return {'file': file_path, 'score': 0.9, 'interpretation': 'well_focused'}
        elif domain_count <= 2:
            return {'file': file_path, 'score': 0.6, 'interpretation': 'acceptable'}
        elif domain_count <= 4:
            return {'file': file_path, 'score': 0.3, 'interpretation': 'conceptual_sprawl'}
        else:
            return {'file': file_path, 'score': 0.1, 'interpretation': 'severe_sprawl'}
    except Exception:
        return {'file': file_path, 'score': 0.5, 'interpretation': 'unknown'}
