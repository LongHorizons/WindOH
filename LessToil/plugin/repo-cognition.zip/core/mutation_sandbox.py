"""Mutation Sandbox — transactional subgraph editing.

Wraps multi-file edits in a sandboxed transaction:
clone → patch → simulate → verify → commit or rollback.

This allows the system to test changes against the indexed graph
before they are applied to the real database, enabling risk-free
"what-if" analysis.
"""

from __future__ import annotations

import copy
import json
from dataclasses import dataclass, field


@dataclass
class SandboxTransaction:
    tx_id: str
    file_paths: list[str] = field(default_factory=list)
    snapshot: dict = field(default_factory=dict)
    changes: list[dict] = field(default_factory=list)
    committed: bool = False
    rolled_back: bool = False


class MutationSandbox:
    """Manages sandboxed transactions for safe subgraph editing."""

    def __init__(self):
        self.transactions: dict[str, SandboxTransaction] = {}

    def begin(self, file_paths: list[str]) -> str:
        """Start a sandbox transaction. Snapshots affected rows to memory.

        Returns a transaction ID.
        """
        import uuid
        tx_id = str(uuid.uuid4())[:12]

        snapshot = self._snapshot_files(file_paths)
        tx = SandboxTransaction(
            tx_id=tx_id,
            file_paths=list(file_paths),
            snapshot=snapshot,
        )
        self.transactions[tx_id] = tx
        return tx_id

    def _snapshot_files(self, file_paths: list[str]) -> dict:
        """Capture current DB state for the affected files."""
        snapshot: dict = {'files': {}, 'symbols': {}, 'edges': [], 'domains': {}}
        try:
            from .manifest import get_connection
            conn = get_connection()
            try:
                placeholders = ','.join('?' for _ in file_paths)
                # Snapshot file rows
                cur = conn.execute(
                    f"SELECT * FROM files WHERE file_path IN ({placeholders})",
                    file_paths
                )
                for row in cur.fetchall():
                    snapshot['files'][row[1]] = {
                        'id': row[0], 'file_path': row[1], 'sha256': row[2],
                        'language': row[3], 'file_size': row[4],
                        'line_count': row[5], 'last_indexed_at': row[6],
                    }

                # Snapshot symbols for these files
                file_ids = [str(v['id']) for v in snapshot['files'].values()]
                if file_ids:
                    fid_placeholders = ','.join('?' for _ in file_ids)
                    cur2 = conn.execute(
                        f"SELECT * FROM symbols WHERE file_id IN ({fid_placeholders})",
                        file_ids
                    )
                    for row in cur2.fetchall():
                        snapshot['symbols'][row[2]] = {
                            'id': row[0], 'file_id': row[1], 'name': row[2],
                            'kind': row[3], 'signature': row[4],
                            'start_line': row[5], 'end_line': row[6],
                            'is_exported': row[8], 'security_sensitive': row[9],
                        }

                    # Snapshot call edges for these symbols
                    symbol_ids = [str(v['id']) for v in snapshot['symbols'].values()]
                    sid_placeholders = ','.join('?' for _ in symbol_ids)
                    cur3 = conn.execute(
                        f"SELECT * FROM call_edges WHERE caller_id IN ({sid_placeholders})",
                        symbol_ids
                    )
                    snapshot['edges'] = [
                        {'id': r[0], 'caller_id': r[1], 'callee_name': r[2],
                         'callee_file': r[4], 'call_line': r[5]}
                        for r in cur3.fetchall()
                    ]
            finally:
                conn.close()
        except Exception:
            pass
        return snapshot

    def apply_change(self, tx_id: str, file_path: str,
                     new_symbols: list[dict], new_edges: list[dict]) -> bool:
        """Apply a change to the sandboxed in-memory copy. Does NOT write to DB."""
        tx = self.transactions.get(tx_id)
        if tx is None or tx.committed or tx.rolled_back:
            return False
        tx.changes.append({
            'file_path': file_path,
            'new_symbols': copy.deepcopy(new_symbols),
            'new_edges': copy.deepcopy(new_edges),
        })
        return True

    def simulate(self, tx_id: str) -> dict:
        """Run invariants and simulation against the sandboxed state."""
        tx = self.transactions.get(tx_id)
        if tx is None:
            return {'status': 'error', 'reason': 'unknown transaction'}

        results = {'status': 'ok', 'warnings': [], 'errors': [], 'grade': 'safe'}
        try:
            from .governance import check_governance
            gov = check_governance(tx.file_paths, '')
            if gov.get('block'):
                results['status'] = 'blocked'
                results['errors'].extend(gov.get('errors', []))
                results['grade'] = 'dangerous'
            results['warnings'].extend(gov.get('warnings', []))
        except Exception:
            pass

        if len(tx.file_paths) > 1:
            try:
                from .simulation import simulate_change
                sim = simulate_change(tx.file_paths)
                results['simulation'] = sim
                if sim.get('grade') == 'dangerous':
                    results['grade'] = 'dangerous'
                    results['status'] = 'blocked'
            except Exception:
                pass

        return results

    def commit(self, tx_id: str) -> bool:
        """Mark a sandbox transaction as committed (actual writes happen externally)."""
        tx = self.transactions.get(tx_id)
        if tx is None or tx.rolled_back:
            return False
        tx.committed = True
        return True

    def rollback(self, tx_id: str) -> bool:
        """Discard the sandbox transaction."""
        tx = self.transactions.get(tx_id)
        if tx is None:
            return False
        tx.rolled_back = True
        return True


def sandboxed_edit(file_paths: list[str], changes: list[dict]) -> dict:
    """Convenience entry point: begin sandbox, apply changes, simulate.

    Returns: {tx_id, status, simulation_results}
    """
    sandbox = MutationSandbox()
    tx_id = sandbox.begin(file_paths)

    for change in changes:
        sandbox.apply_change(
            tx_id,
            change.get('file_path', ''),
            change.get('new_symbols', []),
            change.get('new_edges', []),
        )

    sim_result = sandbox.simulate(tx_id)

    if sim_result.get('status') == 'blocked':
        sandbox.rollback(tx_id)
    else:
        sandbox.commit(tx_id)

    return {
        'tx_id': tx_id,
        'status': sim_result.get('status', 'ok'),
        'simulation_results': sim_result,
    }
