"""Call graph queries for the repository cognition index.

Provides functions to query the call graph stored in SQLite:
- get_callers: who calls a given symbol
- get_callees: what a given symbol calls
- get_transitive_dependents: all downstream dependents (recursive)
- find_call_path: shortest path between two symbols
- get_impact_summary: summary of what would be affected by a change
"""

from __future__ import annotations

from .manifest import get_connection


def get_callers(symbol_name: str, file_path: str | None = None,
                limit: int = 100) -> list[dict]:
    """Return all symbols that call the given symbol."""
    conn = get_connection()
    try:
        if file_path:
            cur = conn.execute(
                """SELECT DISTINCT s.name AS caller_name, s.kind, f.file_path,
                        ce.call_line, ce.confidence
                   FROM call_edges ce
                   JOIN symbols s ON ce.caller_id = s.id
                   JOIN files f ON s.file_id = f.id
                   WHERE ce.callee_name = ?
                     AND (ce.callee_file = ? OR ce.callee_file IS NULL)
                   ORDER BY f.file_path, ce.call_line
                   LIMIT ?""",
                (symbol_name, file_path, limit)
            )
        else:
            cur = conn.execute(
                """SELECT DISTINCT s.name AS caller_name, s.kind, f.file_path,
                        ce.call_line, ce.confidence
                   FROM call_edges ce
                   JOIN symbols s ON ce.caller_id = s.id
                   JOIN files f ON s.file_id = f.id
                   WHERE ce.callee_name = ?
                   ORDER BY f.file_path, ce.call_line
                   LIMIT ?""",
                (symbol_name, limit)
            )
        return [
            {"caller": r[0], "kind": r[1], "file": r[2],
             "line": r[3], "confidence": r[4]}
            for r in cur.fetchall()
        ]
    finally:
        conn.close()


def get_callees(symbol_name: str, file_path: str | None = None,
                limit: int = 100) -> list[dict]:
    """Return all symbols called by the given symbol."""
    conn = get_connection()
    try:
        if file_path:
            cur = conn.execute(
                """SELECT DISTINCT ce.callee_name, ce.callee_file, ce.call_line,
                        ce.confidence, ce.is_dynamic
                   FROM call_edges ce
                   JOIN symbols s ON ce.caller_id = s.id
                   JOIN files f ON s.file_id = f.id
                   WHERE s.name = ? AND f.file_path = ?
                   ORDER BY ce.call_line
                   LIMIT ?""",
                (symbol_name, file_path, limit)
            )
        else:
            cur = conn.execute(
                """SELECT DISTINCT ce.callee_name, ce.callee_file, ce.call_line,
                        ce.confidence, ce.is_dynamic
                   FROM call_edges ce
                   JOIN symbols s ON ce.caller_id = s.id
                   WHERE s.name = ?
                   ORDER BY ce.call_line
                   LIMIT ?""",
                (symbol_name, limit)
            )
        return [
            {"callee": r[0], "file": r[1], "line": r[2],
             "confidence": r[3], "is_dynamic": bool(r[4])}
            for r in cur.fetchall()
        ]
    finally:
        conn.close()


def get_transitive_dependents(symbol_name: str, max_depth: int = 10,
                               limit: int = 200) -> list[dict]:
    """Return all symbols that transitively depend on the given symbol.

    Uses a recursive CTE to walk the call graph upward (who calls this,
    who calls those, etc.)
    """
    conn = get_connection()
    try:
        cur = conn.execute(
            """WITH RECURSIVE dependents AS (
                SELECT s.id, s.name, f.file_path, 1 AS depth
                FROM call_edges ce
                JOIN symbols s ON ce.caller_id = s.id
                JOIN files f ON s.file_id = f.id
                WHERE ce.callee_name = ?

                UNION ALL

                SELECT s.id, s.name, f.file_path, d.depth + 1
                FROM call_edges ce
                JOIN symbols s ON ce.caller_id = s.id
                JOIN files f ON s.file_id = f.id
                JOIN dependents d ON ce.callee_name = d.name
                WHERE d.depth < ?
            )
            SELECT DISTINCT name, file_path, depth FROM dependents
            ORDER BY depth, file_path
            LIMIT ?""",
            (symbol_name, max_depth, limit)
        )
        return [
            {"symbol": r[0], "file": r[1], "depth": r[2]}
            for r in cur.fetchall()
        ]
    finally:
        conn.close()


def get_transitive_dependencies(symbol_name: str, max_depth: int = 10,
                                 limit: int = 200) -> list[dict]:
    """Return all symbols transitively called by the given symbol.

    Walks the call graph downward (what does this call, what do those call, etc.)
    """
    conn = get_connection()
    try:
        cur = conn.execute(
            """WITH RECURSIVE deps AS (
                SELECT ce.callee_name AS name, ce.callee_file AS file_path, 1 AS depth
                FROM call_edges ce
                JOIN symbols s ON ce.caller_id = s.id
                WHERE s.name = ?

                UNION ALL

                SELECT ce.callee_name AS name, ce.callee_file AS file_path, d.depth + 1
                FROM call_edges ce
                JOIN symbols s ON ce.caller_id = s.id
                JOIN deps d ON s.name = d.name
                WHERE d.depth < ? AND ce.callee_name IS NOT NULL
            )
            SELECT DISTINCT name, file_path, depth FROM deps
            ORDER BY depth, name
            LIMIT ?""",
            (symbol_name, max_depth, limit)
        )
        return [
            {"symbol": r[0], "file": r[1], "depth": r[2]}
            for r in cur.fetchall()
        ]
    finally:
        conn.close()


def find_call_path(from_symbol: str, to_symbol: str,
                    max_depth: int = 10) -> list[dict] | None:
    """Find the shortest call path from one symbol to another.

    Uses BFS through the call graph. Returns the path as a list of
    {name, file, line} dicts, or None if no path found.
    """
    conn = get_connection()
    try:
        # Build adjacency list limited to relevant symbols
        cur = conn.execute(
            """SELECT DISTINCT s1.name, ce.callee_name, f.file_path, ce.call_line
               FROM call_edges ce
               JOIN symbols s1 ON ce.caller_id = s1.id
               JOIN files f ON s1.file_id = f.id
               WHERE ce.callee_name IS NOT NULL"""
        )
        adj = {}
        for row in cur.fetchall():
            caller, callee, file_path, line = row
            if caller not in adj:
                adj[caller] = []
            adj[caller].append({"name": callee, "file": file_path, "line": line})

        # BFS
        from collections import deque
        visited = {from_symbol}
        queue = deque([(from_symbol, [])])

        while queue:
            current, path = queue.popleft()

            if len(path) >= max_depth:
                continue

            for neighbor in adj.get(current, []):
                if neighbor["name"] == to_symbol:
                    return path + [neighbor]
                if neighbor["name"] not in visited:
                    visited.add(neighbor["name"])
                    queue.append((neighbor["name"], path + [neighbor]))

        return None
    finally:
        conn.close()


def get_hotspots(min_callers: int = 10, limit: int = 50) -> list[dict]:
    """Return symbols with the most incoming callers (potential refactoring targets)."""
    conn = get_connection()
    try:
        cur = conn.execute(
            """SELECT ce.callee_name, COUNT(DISTINCT ce.caller_id) AS caller_count,
                    GROUP_CONCAT(DISTINCT f.file_path) AS files
               FROM call_edges ce
               JOIN symbols s ON ce.caller_id = s.id
               JOIN files f ON s.file_id = f.id
               WHERE ce.callee_name IS NOT NULL
               GROUP BY ce.callee_name
               HAVING caller_count >= ?
               ORDER BY caller_count DESC
               LIMIT ?""",
            (min_callers, limit)
        )
        return [
            {"symbol": r[0], "caller_count": r[1],
             "files": r[2].split(',') if r[2] else []}
            for r in cur.fetchall()
        ]
    finally:
        conn.close()


def get_orphaned_symbols() -> list[dict]:
    """Return symbols that are defined but never called."""
    conn = get_connection()
    try:
        cur = conn.execute(
            """SELECT s.name, s.kind, f.file_path, s.start_line
               FROM symbols s
               JOIN files f ON s.file_id = f.id
               WHERE s.kind IN ('function', 'method')
                 AND s.name NOT IN (
                     SELECT DISTINCT ce.callee_name FROM call_edges ce
                     WHERE ce.callee_name IS NOT NULL
                 )
                 AND s.name NOT IN (
                     SELECT DISTINCT s2.name FROM symbols s2
                     WHERE s2.kind IN ('class', 'export')
                 )
               ORDER BY f.file_path, s.start_line
               LIMIT 200"""
        )
        return [
            {"symbol": r[0], "kind": r[1], "file": r[2], "line": r[3]}
            for r in cur.fetchall()
        ]
    finally:
        conn.close()


def get_symbol_by_name(name: str) -> list[dict]:
    """Look up a symbol by exact name across all files."""
    conn = get_connection()
    try:
        cur = conn.execute(
            """SELECT s.name, s.kind, s.signature, s.start_line, s.end_line,
                    s.is_exported, s.security_sensitive, s.has_side_effects,
                    f.file_path, f.language
               FROM symbols s
               JOIN files f ON s.file_id = f.id
               WHERE s.name = ?
               ORDER BY f.file_path, s.start_line""",
            (name,)
        )
        return [
            {"name": r[0], "kind": r[1], "signature": r[2],
             "start_line": r[3], "end_line": r[4],
             "is_exported": bool(r[5]), "security_sensitive": bool(r[6]),
             "has_side_effects": bool(r[7]),
             "file": r[8], "language": r[9]}
            for r in cur.fetchall()
        ]
    finally:
        conn.close()


def search_symbols(pattern: str, limit: int = 100) -> list[dict]:
    """Search for symbols whose name contains the given pattern (LIKE)."""
    conn = get_connection()
    try:
        cur = conn.execute(
            """SELECT s.name, s.kind, s.signature, f.file_path, f.language,
                    s.start_line
               FROM symbols s
               JOIN files f ON s.file_id = f.id
               WHERE s.name LIKE ?
               ORDER BY s.name, f.file_path
               LIMIT ?""",
            (f'%{pattern}%', limit)
        )
        return [
            {"name": r[0], "kind": r[1], "signature": r[2],
             "file": r[3], "language": r[4], "line": r[5]}
            for r in cur.fetchall()
        ]
    finally:
        conn.close()
