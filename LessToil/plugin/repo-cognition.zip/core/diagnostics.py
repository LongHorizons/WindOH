"""Self-diagnosis module for the Repository Cognition Engine.

Provides `run_diagnostics()` which checks every subsystem and returns a
structured report with per-check PASS/FAIL/WARN status — used by the
/index-check command so users can diagnose why things aren't working.
"""

from __future__ import annotations

import os
import sys
import json
import sqlite3
from datetime import datetime, timezone

from . import PROJECT_DIR, INDEX_DIR, DB_PATH, LOCK_PATH


def _check_python() -> dict:
    """Verify Python version is sufficient."""
    info = sys.version_info
    ok = info >= (3, 8)
    return {
        'name': 'Python version',
        'status': 'PASS' if ok else 'FAIL',
        'detail': f'{sys.version}',
        'fix': None if ok else 'Install Python 3.8+ from https://python.org',
    }


def _check_env_vars() -> dict:
    """Check that CLAUDE_PLUGIN_ROOT is available."""
    plugin_root = os.environ.get('CLAUDE_PLUGIN_ROOT', '')
    project_dir = os.environ.get('CLAUDE_PROJECT_DIR', '')
    if plugin_root:
        return {
            'name': 'Environment variables',
            'status': 'PASS',
            'detail': f'CLAUDE_PLUGIN_ROOT={plugin_root}, CLAUDE_PROJECT_DIR={project_dir or "(not set)"}',
            'fix': None,
        }
    return {
        'name': 'Environment variables',
        'status': 'WARN',
        'detail': 'CLAUDE_PLUGIN_ROOT not set. Plugin auto-detection fallback active.',
        'fix': 'Reinstall the plugin or set CLAUDE_PLUGIN_ROOT in your environment.',
    }


def _check_project_dir() -> dict:
    """Check that PROJECT_DIR points to a real directory."""
    if os.path.isdir(PROJECT_DIR):
        # Check for git root
        git_dir = os.path.join(PROJECT_DIR, '.git')
        has_git = os.path.isdir(git_dir) or os.path.isfile(git_dir)
        return {
            'name': 'Project directory',
            'status': 'PASS',
            'detail': f'{PROJECT_DIR} (git: {"yes" if has_git else "no"})',
            'fix': None,
        }
    return {
        'name': 'Project directory',
        'status': 'FAIL',
        'detail': f'{PROJECT_DIR} does not exist or is not a directory',
        'fix': 'Set CLAUDE_PROJECT_DIR to your project root, or run Claude Code from the project directory.',
    }


def _check_index_dir() -> dict:
    """Check that the index directory exists and is writable."""
    if os.path.isdir(INDEX_DIR):
        # Check writability
        test_file = os.path.join(INDEX_DIR, '.write_test')
        try:
            with open(test_file, 'w') as f:
                f.write('test')
            os.remove(test_file)
            return {
                'name': 'Index directory',
                'status': 'PASS',
                'detail': f'{INDEX_DIR} (writable)',
                'fix': None,
            }
        except (OSError, IOError):
            return {
                'name': 'Index directory',
                'status': 'FAIL',
                'detail': f'{INDEX_DIR} exists but is not writable',
                'fix': 'Check file permissions on .claude/index/repo-cognition/',
            }
    # Doesn't exist — try to create
    try:
        os.makedirs(INDEX_DIR, exist_ok=True)
        return {
            'name': 'Index directory',
            'status': 'WARN',
            'detail': f'{INDEX_DIR} created — was missing',
            'fix': None,
        }
    except OSError as e:
        return {
            'name': 'Index directory',
            'status': 'FAIL',
            'detail': f'Cannot create {INDEX_DIR}: {e}',
            'fix': 'Check parent directory permissions.',
        }


def _check_db() -> dict:
    """Check that the SQLite database exists and has the right schema."""
    if not os.path.exists(DB_PATH):
        return {
            'name': 'Index database',
            'status': 'FAIL',
            'detail': f'{DB_PATH} not found',
            'fix': 'Run /index-rebuild to create the index.',
        }

    try:
        conn = sqlite3.connect(DB_PATH)
        try:
            cur = conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
            )
            tables = [row[0] for row in cur.fetchall()]
            expected_tables = {
                'files', 'symbols', 'call_edges', 'domains', 'file_domains',
                'schema_version',
            }
            missing = expected_tables - set(tables)

            # Check core counts
            file_count = conn.execute("SELECT COUNT(*) FROM files").fetchone()[0]
            symbol_count = conn.execute("SELECT COUNT(*) FROM symbols").fetchone()[0]
            edge_count = conn.execute("SELECT COUNT(*) FROM call_edges").fetchone()[0]

            if missing:
                return {
                    'name': 'Index database',
                    'status': 'FAIL',
                    'detail': f'Missing tables: {", ".join(sorted(missing))}',
                    'fix': 'Run /index-rebuild to recreate the schema.',
                }

            if file_count == 0:
                return {
                    'name': 'Index database',
                    'status': 'WARN',
                    'detail': f'Schema OK ({len(tables)} tables) but 0 files indexed',
                    'fix': 'The index is empty. Run /index-rebuild to populate it.',
                }

            status = 'PASS'
            detail_parts = [f'{file_count} files, {symbol_count} symbols, {edge_count} edges, {len(tables)} tables']
            if symbol_count == 0 and file_count > 0:
                status = 'WARN'
                detail_parts.append('SYMBOLS MISSING — indexing may have been interrupted')

            return {
                'name': 'Index database',
                'status': status,
                'detail': ', '.join(detail_parts),
                'fix': None if status == 'PASS' else 'Run /index-rebuild to re-extract symbols.',
            }
        finally:
            conn.close()
    except sqlite3.Error as e:
        return {
            'name': 'Index database',
            'status': 'FAIL',
            'detail': f'SQLite error: {e}',
            'fix': 'The database may be corrupt. Delete it and run /index-rebuild.',
        }


def _check_lock() -> dict:
    """Check for stale lock files."""
    if not os.path.exists(LOCK_PATH):
        return {
            'name': 'Index lock',
            'status': 'PASS',
            'detail': 'No lock file (indexing not in progress)',
            'fix': None,
        }
    try:
        with open(LOCK_PATH) as f:
            data = json.load(f)
        pid = data.get('pid')
        started = data.get('started_at', 'unknown')
        # Check if the process is alive
        try:
            os.kill(pid, 0)
            # Process is alive — indexing may be in progress
            return {
                'name': 'Index lock',
                'status': 'WARN',
                'detail': f'Indexing in progress (PID {pid}, started {started})',
                'fix': 'Wait for the current indexing session to complete.',
            }
        except (OSError, TypeError, SystemError):
            # Process is dead — stale lock
            return {
                'name': 'Index lock',
                'status': 'FAIL',
                'detail': f'Stale lock from dead process PID {pid} (started {started})',
                'fix': 'Delete .claude/index/repo-cognition/indexing.lock and retry.',
            }
    except (json.JSONDecodeError, KeyError) as e:
        return {
            'name': 'Index lock',
            'status': 'FAIL',
            'detail': f'Corrupt lock file: {e}',
            'fix': 'Delete .claude/index/repo-cognition/indexing.lock and retry.',
        }


def _check_error_log() -> dict:
    """Check the error log for recent issues."""
    from .error_log import get_error_count
    count = get_error_count()
    if count == 0:
        return {
            'name': 'Error log',
            'status': 'PASS',
            'detail': 'No errors recorded',
            'fix': None,
        }
    return {
        'name': 'Error log',
        'status': 'WARN',
        'detail': f'{count} error(s) recorded',
        'fix': 'Review .claude/index/repo-cognition/errors.log for details.',
    }


def _check_git() -> dict:
    """Check that git is available and the project is a repository."""
    import subprocess
    try:
        result = subprocess.run(
            ['git', 'rev-parse', '--show-toplevel'],
            capture_output=True, text=True, timeout=10,
            cwd=PROJECT_DIR,
        )
        if result.returncode == 0:
            return {
                'name': 'Git availability',
                'status': 'PASS',
                'detail': f'git available, repo root: {result.stdout.strip()}',
                'fix': None,
            }
        return {
            'name': 'Git availability',
            'status': 'WARN',
            'detail': 'git found but not in a repository (temporal analysis unavailable)',
            'fix': 'Initialize a git repository for full temporal risk analysis.',
        }
    except FileNotFoundError:
        return {
            'name': 'Git availability',
            'status': 'WARN',
            'detail': 'git not found on PATH (temporal analysis unavailable)',
            'fix': 'Install git for temporal risk analysis.',
        }
    except subprocess.TimeoutExpired:
        return {
            'name': 'Git availability',
            'status': 'WARN',
            'detail': 'git command timed out',
            'fix': 'Check for large repository or slow filesystem.',
        }


def _check_db_file_size() -> dict:
    """Check DB file size for abnormal conditions."""
    if not os.path.exists(DB_PATH):
        return {
            'name': 'DB file size',
            'status': 'SKIP',
            'detail': 'No database file',
            'fix': None,
        }
    size = os.path.getsize(DB_PATH)
    size_mb = size / (1024 * 1024)
    if size_mb > 500:
        return {
            'name': 'DB file size',
            'status': 'WARN',
            'detail': f'{size_mb:.1f} MB — unusually large',
            'fix': 'Consider running /index-rebuild to reclaim space.',
        }
    return {
        'name': 'DB file size',
        'status': 'PASS',
        'detail': f'{size_mb:.1f} MB',
        'fix': None,
    }


ALL_CHECKS = [
    _check_python,
    _check_env_vars,
    _check_project_dir,
    _check_index_dir,
    _check_db,
    _check_lock,
    _check_error_log,
    _check_git,
    _check_db_file_size,
]


def run_diagnostics() -> dict:
    """Run all diagnostic checks and return a structured report.

    Returns:
        dict with keys:
            'timestamp': ISO timestamp
            'overall': 'PASS' | 'WARN' | 'FAIL'
            'checks': list of per-check result dicts
            'pass_count', 'warn_count', 'fail_count': summary counts
    """
    results = []
    for check_fn in ALL_CHECKS:
        try:
            result = check_fn()
        except Exception as e:
            result = {
                'name': check_fn.__name__.replace('_check_', '').replace('_', ' '),
                'status': 'FAIL',
                'detail': f'Exception during check: {e}',
                'fix': 'Unexpected error — check plugin installation.',
            }
        results.append(result)

    pass_count = sum(1 for r in results if r['status'] == 'PASS')
    warn_count = sum(1 for r in results if r['status'] == 'WARN')
    fail_count = sum(1 for r in results if r['status'] == 'FAIL')
    skip_count = sum(1 for r in results if r['status'] == 'SKIP')

    if fail_count > 0:
        overall = 'FAIL'
    elif warn_count > 0:
        overall = 'WARN'
    else:
        overall = 'PASS'

    return {
        'timestamp': datetime.now(timezone.utc).isoformat(),
        'overall': overall,
        'checks': results,
        'pass_count': pass_count,
        'warn_count': warn_count,
        'fail_count': fail_count,
        'skip_count': skip_count,
    }


def format_diagnostic_result(report: dict) -> str:
    """Render a diagnostic report as a professional terminal dashboard.

    Uses only ASCII-safe characters for cross-platform compatibility
    (Windows cp1252 terminals can't render emoji).
    """
    overall = report.get('overall', '?')
    overall_icon = {'PASS': '*', 'WARN': '!', 'FAIL': 'X'}.get(overall, '?')

    lines = []
    lines.append('+' + '-' * 58 + '+')
    lines.append(f'|  REPOSITORY COGNITION  --  System Check                     |')
    lines.append(f'|  [{overall_icon}]  {overall:<53}|')
    lines.append(f'|  {report.get("pass_count", 0)} pass  |  {report.get("warn_count", 0)} warn  |  {report.get("fail_count", 0)} fail  |  {report.get("skip_count", 0)} skip     |')
    lines.append('+' + '-' * 58 + '+')
    lines.append('')

    for check in report.get('checks', []):
        status = check.get('status', '?')
        icon = {'PASS': '[OK]', 'WARN': '[!!]', 'FAIL': '[XX]', 'SKIP': '[--]'}.get(status, '[  ]')
        name = check.get('name', '')
        detail = check.get('detail', '')
        fix = check.get('fix', '')

        lines.append(f'  {icon}  {name}')
        if detail:
            lines.append(f'       {detail}')
        if fix:
            lines.append(f'       -> Fix: {fix}')
        lines.append('')

    lines.append('  ' + '=' * 58)
    return '\n'.join(lines)
