"""Runtime profiling integration.

Wraps test execution with language-appropriate profilers and maps
profiler output to indexed symbols. Supports cProfile (Python),
pprof (Go), and --prof (Node). Best-effort for other languages.
"""

from __future__ import annotations

import json
import os
import subprocess
import tempfile

from .manifest import get_connection
from . import PROJECT_DIR

PROFILE_SNAPSHOT_PREFIX = 'profile_'


def detect_profiler(language: str) -> str:
    """Detect the best available profiler for a language."""
    profilers = {
        'python': 'cProfile',
        'go': 'pprof',
        'typescript': 'node-prof',
        'javascript': 'node-prof',
    }
    return profilers.get(language, 'none')


def run_profile(test_command: str, language: str = 'python',
                 timeout: int = 120) -> dict:
    """Run a test command with profiling enabled.

    Returns a dict with profile results mapped to indexed symbols.
    """
    profiler = detect_profiler(language)
    if profiler == 'none':
        return {'status': 'skipped', 'reason': f'no profiler for {language}'}

    if profiler == 'cProfile':
        return _run_python_profile(test_command, timeout)
    elif profiler == 'node-prof':
        return _run_node_profile(test_command, timeout)
    elif profiler == 'pprof':
        return _run_go_profile(test_command, timeout)

    return {'status': 'skipped', 'reason': 'profiler not implemented'}


def _run_python_profile(test_command: str, timeout: int) -> dict:
    """Run Python code with cProfile."""
    tmp = tempfile.NamedTemporaryFile(suffix='.prof', delete=False)
    tmp_path = tmp.name
    tmp.close()

    try:
        profile_code = (
            f"import cProfile, sys; "
            f"cProfile.run({test_command!r}, {tmp_path!r})"
        )
        result = subprocess.run(
            ['python', '-c', profile_code],
            capture_output=True, text=True, timeout=timeout,
            cwd=PROJECT_DIR
        )
        return _parse_python_profile(tmp_path, result)
    except subprocess.TimeoutExpired:
        return {'status': 'error', 'reason': 'profiling timed out'}
    except Exception as e:
        return {'status': 'error', 'reason': str(e)}
    finally:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass


def _parse_python_profile(prof_path: str, result) -> dict:
    """Parse cProfile output using pstats."""
    try:
        import pstats
        stats = pstats.Stats(prof_path)
        stats.sort_stats('cumulative')

        hot_functions = []
        for func, info in stats.stats.items():
            if len(hot_functions) >= 20:
                break
            file_path, line, func_name = func
            hot_functions.append({
                'function': func_name,
                'file': file_path,
                'line': line,
                'calls': info[0],
                'total_time': round(info[2], 4),
                'cumulative_time': round(info[3], 4),
            })

        # Map to indexed symbols
        mapped = _map_to_symbols(hot_functions)

        return {
            'status': 'completed',
            'profiler': 'cProfile',
            'hot_functions': hot_functions[:10],
            'mapped_symbols': mapped[:10],
            'stdout': result.stdout[:500] if result.stdout else '',
        }
    except Exception as e:
        return {'status': 'error', 'reason': f'parse error: {e}'}


def _run_node_profile(test_command: str, timeout: int) -> dict:
    """Run Node.js code with --prof flag."""
    try:
        result = subprocess.run(
            ['node', '--prof', '-e', test_command],
            capture_output=True, text=True, timeout=timeout,
            cwd=PROJECT_DIR
        )
        return {
            'status': 'completed',
            'profiler': 'node-prof',
            'stdout': result.stdout[:500] if result.stdout else '',
            'note': 'Node --prof output requires node --prof-process for human readable output',
        }
    except FileNotFoundError:
        return {'status': 'skipped', 'reason': 'node not found'}
    except subprocess.TimeoutExpired:
        return {'status': 'error', 'reason': 'profiling timed out'}
    except Exception as e:
        return {'status': 'error', 'reason': str(e)}


def _run_go_profile(test_command: str, timeout: int) -> dict:
    """Run Go tests with profiler flags."""
    try:
        result = subprocess.run(
            ['go', 'test', '-cpuprofile', 'cpu.prof', '-memprofile', 'mem.prof',
             './...'],
            capture_output=True, text=True, timeout=timeout,
            cwd=PROJECT_DIR
        )
        return {
            'status': 'completed',
            'profiler': 'pprof',
            'stdout': result.stdout[:500] if result.stdout else '',
            'note': 'Profile data written to cpu.prof and mem.prof',
        }
    except FileNotFoundError:
        return {'status': 'skipped', 'reason': 'go not found'}
    except subprocess.TimeoutExpired:
        return {'status': 'error', 'reason': 'profiling timed out'}
    except Exception as e:
        return {'status': 'error', 'reason': str(e)}


def _map_to_symbols(hot_functions: list[dict]) -> list[dict]:
    """Map profiled functions to indexed symbols."""
    conn = get_connection()
    try:
        mapped = []
        for hf in hot_functions:
            cur = conn.execute(
                """SELECT s.name, s.kind, f.file_path, s.confidence_score
                   FROM symbols s JOIN files f ON s.file_id = f.id
                   WHERE s.name = ? LIMIT 1""",
                (hf['function'],)
            )
            row = cur.fetchone()
            if row:
                mapped.append({
                    'profiled_function': hf['function'],
                    'total_time': hf['total_time'],
                    'indexed_symbol': row[0],
                    'kind': row[1],
                    'file': row[2],
                    'confidence': row[3],
                })
        return mapped
    finally:
        conn.close()


def store_profile_snapshot(profile_data: dict, label: str = '') -> int:
    """Store a profiling snapshot in the database. Returns snapshot id."""
    conn = get_connection()
    try:
        cur = conn.execute(
            """INSERT INTO profile_snapshots (label, profile_data, captured_at)
               VALUES (?, ?, datetime('now'))""",
            (label or 'manual', json.dumps(profile_data))
        )
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


def get_profile_snapshots(limit: int = 10) -> list[dict]:
    """Retrieve recent profiling snapshots."""
    conn = get_connection()
    try:
        cur = conn.execute(
            "SELECT id, label, captured_at FROM profile_snapshots ORDER BY id DESC LIMIT ?",
            (limit,)
        )
        return [
            {'id': r[0], 'label': r[1], 'captured_at': r[2]}
            for r in cur.fetchall()
        ]
    finally:
        conn.close()


def detect_hot_call_chains(hot_functions: list[dict]) -> list[dict]:
    """Find call chains involving hot (high-time) functions."""
    conn = get_connection()
    try:
        chains = []
        for hf in hot_functions[:5]:
            cur = conn.execute(
                """WITH RECURSIVE chain AS (
                    SELECT s.name, f.file_path, 1 AS depth
                    FROM symbols s
                    JOIN files f ON s.file_id = f.id
                    WHERE s.name = ?
                    UNION ALL
                    SELECT s2.name, f2.file_path, ch.depth + 1
                    FROM call_edges ce
                    JOIN symbols s2 ON ce.caller_id = s2.id
                    JOIN files f2 ON s2.file_id = f2.id
                    JOIN chain ch ON ce.callee_name = ch.name
                    WHERE ch.depth < 5
                )
                SELECT DISTINCT name, file_path, depth FROM chain ORDER BY depth""",
                (hf['function'],)
            )
            callers = [
                {'function': r[0], 'file': r[1], 'depth': r[2]}
                for r in cur.fetchall()
            ]
            if callers:
                chains.append({
                    'hot_function': hf['function'],
                    'total_time': hf.get('total_time', 0),
                    'call_chain': callers,
                })
        return chains
    finally:
        conn.close()
