"""Meta-Reasoning — self-modeling agent that tracks failures and blind spots.

Records where the system fails, detects systematic error patterns,
and calibrates confidence against actual outcomes. Enables the system
to learn from its mistakes.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class AgentFailureRecord:
    failure_type: str
    context: str = ''
    root_cause: str = ''
    mitigation: str = ''
    recorded_at: str = ''


# In-memory failure log (survives session, not permanent)
_failure_log: list[AgentFailureRecord] = []


def track_failure(failure_type: str, context: str = '', root_cause: str = '',
                  mitigation: str = '') -> None:
    """Record a failure for learning and pattern detection."""
    from datetime import datetime, timezone
    _failure_log.append(AgentFailureRecord(
        failure_type=failure_type,
        context=context,
        root_cause=root_cause,
        mitigation=mitigation,
        recorded_at=datetime.now(timezone.utc).isoformat(),
    ))
    # Keep only last 100 failures in memory
    if len(_failure_log) > 100:
        _failure_log.pop(0)


def detect_blind_spots() -> list[dict]:
    """Detect systematic failure patterns from recorded failures.

    Returns blind spots: failure types that recur with common characteristics.
    """
    if len(_failure_log) < 3:
        return []

    from collections import Counter
    type_counts = Counter(f.failure_type for f in _failure_log)

    blind_spots = []
    for ftype, count in type_counts.most_common(10):
        if count >= 3:
            examples = [f for f in _failure_log if f.failure_type == ftype]
            common_contexts = Counter(e.context for e in examples).most_common(3)
            blind_spots.append({
                'failure_type': ftype,
                'occurrences': count,
                'common_contexts': [c[0] for c in common_contexts],
                'recommended_mitigation': examples[0].mitigation if examples else '',
            })

    return blind_spots


def confidence_calibration() -> dict:
    """Measure how well confidence scores correlate with outcomes.

    Compares stored confidence scores against evidence of correctness
    (tests passing, profiling data, invariant satisfaction).
    """
    calibration = {
        'calibrated': True,
        'overconfident': 0,
        'underconfident': 0,
        'total_assessed': 0,
    }

    try:
        from .manifest import get_connection
        conn = get_connection()
        try:
            # High confidence but low evidence = overconfident
            cur = conn.execute(
                """SELECT COUNT(*) FROM confidence_scores
                   WHERE aggregate_confidence >= 0.8
                     AND runtime_confidence < 0.3"""
            )
            calibration['overconfident'] = cur.fetchone()[0]

            # Low confidence but high evidence = underconfident
            cur2 = conn.execute(
                """SELECT COUNT(*) FROM confidence_scores
                   WHERE aggregate_confidence < 0.4
                     AND runtime_confidence >= 0.7"""
            )
            calibration['underconfident'] = cur2.fetchone()[0]

            cur3 = conn.execute("SELECT COUNT(*) FROM confidence_scores")
            calibration['total_assessed'] = cur3.fetchone()[0]

            if calibration['total_assessed'] > 0:
                miscalibrated = calibration['overconfident'] + calibration['underconfident']
                calibration['calibrated'] = (
                    miscalibrated / calibration['total_assessed'] < 0.3
                )
        finally:
            conn.close()
    except Exception:
        pass

    return calibration


def get_meta_summary() -> dict:
    """Return meta-reasoning summary: failures, blind spots, calibration."""
    return {
        'total_failures': len(_failure_log),
        'blind_spots': detect_blind_spots()[:5],
        'calibration': confidence_calibration(),
    }
