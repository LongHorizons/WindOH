"""Refactor simulation engine.

Before multi-file edits (>3 files or >1 domain): simulate the impact
and grade the proposed change. Grades: safe, cautious, risky, dangerous.
Dangerous → block; Risky → prominent warning.
"""

from __future__ import annotations

from .manifest import get_connection

# Simulation thresholds
MULTI_FILE_THRESHOLD = 3
MULTI_DOMAIN_THRESHOLD = 1
HIGH_COUPLING_THRESHOLD = 0.7
HIGH_CALLER_COUNT_THRESHOLD = 20


def simulate_change(file_paths: list[str]) -> dict:
    """Simulate the impact of a multi-file change.

    Returns a dict with grades, deltas, and recommendations.
    """
    if len(file_paths) <= 1:
        return {'grade': 'safe', 'reason': 'single file change', 'deltas': {}}

    conn = get_connection()
    try:
        # Get affected symbols
        placeholders = ','.join('?' for _ in file_paths)
        cur = conn.execute(
            f"""SELECT s.name, s.kind, COUNT(ce2.caller_id) AS caller_count
                FROM symbols s
                JOIN files f ON s.file_id = f.id
                LEFT JOIN call_edges ce2 ON s.name = ce2.callee_name
                WHERE f.file_path IN ({placeholders})
                GROUP BY s.name, s.kind
                LIMIT 50""",
            file_paths
        )
        affected = [
            {'name': r[0], 'kind': r[1], 'callers': r[2]}
            for r in cur.fetchall()
        ]

        if not affected:
            return {'grade': 'safe', 'reason': 'no symbols affected', 'deltas': {}}

        # Compute coupling delta
        coupling_delta = _compute_coupling_delta(file_paths, conn)

        # Compute complexity delta
        complexity_delta = _compute_complexity_delta(file_paths, conn)

        # Compute entropy delta
        entropy_delta = _compute_entropy_delta(file_paths, affected, conn)

        # Risk exposure
        risk_exposure = _compute_risk_exposure(file_paths, affected, conn)

        # Domain impact
        affected_domains = _get_affected_domains(file_paths, conn)
        cross_domain = len(affected_domains) > MULTI_DOMAIN_THRESHOLD

        # Determine grade
        grade = _determine_grade(
            len(file_paths), coupling_delta, complexity_delta,
            entropy_delta, risk_exposure, cross_domain,
            sum(a['callers'] for a in affected)
        )

        return {
            'grade': grade['level'],
            'reason': grade['reason'],
            'deltas': {
                'coupling_delta': coupling_delta,
                'complexity_delta': complexity_delta,
                'entropy_delta': entropy_delta,
                'risk_exposure': risk_exposure,
            },
            'affected_symbols': len(affected),
            'total_callers': sum(a['callers'] for a in affected),
            'affected_domains': affected_domains,
            'cross_domain': cross_domain,
            'recommendations': grade.get('recommendations', []),
        }
    finally:
        conn.close()


def _compute_coupling_delta(file_paths: list[str], conn) -> float:
    """Estimate how much coupling would change (-1 to +1)."""
    placeholders = ','.join('?' for _ in file_paths)

    # External callers
    cur = conn.execute(
        f"""SELECT COUNT(DISTINCT f2.file_path)
            FROM call_edges ce
            JOIN symbols s ON s.name = ce.callee_name
            JOIN files f ON s.file_id = f.id
            JOIN symbols s2 ON ce.caller_id = s2.id
            JOIN files f2 ON s2.file_id = f2.id
            WHERE f.file_path IN ({placeholders})
              AND f2.file_path NOT IN ({placeholders})""",
        file_paths + file_paths
    )
    external_files = cur.fetchone()[0]

    # Internal coupling
    cur2 = conn.execute(
        f"""SELECT COUNT(DISTINCT f2.file_path)
            FROM call_edges ce
            JOIN symbols s ON s.name = ce.callee_name
            JOIN files f ON s.file_id = f.id
            JOIN symbols s2 ON ce.caller_id = s2.id
            JOIN files f2 ON s2.file_id = f2.id
            WHERE f.file_path IN ({placeholders})
              AND f2.file_path IN ({placeholders})""",
        file_paths + file_paths
    )
    internal_files = cur2.fetchone()[0]

    total = external_files + internal_files
    if total == 0:
        return 0.0
    return round(min(0.5, external_files / (total * 2.0)), 4)


def _compute_complexity_delta(file_paths: list[str], conn) -> float:
    """Estimate complexity impact of the change."""
    placeholders = ','.join('?' for _ in file_paths)
    cur = conn.execute(
        f"""SELECT AVG(line_count) FROM files
            WHERE file_path IN ({placeholders})""",
        file_paths
    )
    row = cur.fetchone()
    avg_lines = row[0] if row and row[0] else 0
    return round(min(0.5, avg_lines / 2000.0), 4)


def _compute_entropy_delta(file_paths: list[str], affected: list[dict], conn) -> float:
    """Estimate entropy (disorder) impact."""
    caller_count = sum(a['callers'] for a in affected)
    return round(min(0.5, caller_count / 100.0), 4)


def _compute_risk_exposure(file_paths: list[str], affected: list[dict],
                            conn) -> float:
    """Compute risk exposure from temporal + security data."""
    risk = 0.0

    # Temporal risk
    placeholders = ','.join('?' for _ in file_paths)
    cur = conn.execute(
        f"""SELECT AVG(risk_score) FROM temporal_metrics
            WHERE file_path IN ({placeholders})""",
        file_paths
    )
    row = cur.fetchone()
    if row and row[0]:
        risk += row[0] * 0.5

    # Security sensitivity
    security_count = sum(1 for a in affected if a.get('security_sensitive'))
    if security_count > 0:
        risk += min(0.5, security_count * 0.1)

    return round(min(1.0, risk), 4)


def _get_affected_domains(file_paths: list[str], conn) -> list[str]:
    """Get distinct domains affected by the change."""
    placeholders = ','.join('?' for _ in file_paths)
    cur = conn.execute(
        f"""SELECT DISTINCT d.name
            FROM domains d
            JOIN file_domains fd ON d.id = fd.domain_id
            JOIN files f ON fd.file_id = f.id
            WHERE f.file_path IN ({placeholders})""",
        file_paths
    )
    return [r[0] for r in cur.fetchall()]


def _determine_grade(num_files: int, coupling: float, complexity: float,
                      entropy: float, risk: float, cross_domain: bool,
                      total_callers: int) -> dict:
    """Determine the simulation grade and recommendations."""
    score = 0
    recommendations = []

    if num_files > MULTI_FILE_THRESHOLD:
        score += 2
        recommendations.append("Consider splitting into smaller, sequential changes")
    if cross_domain:
        score += 2
        recommendations.append("Cross-domain change: coordinate with domain owners")
    if coupling > HIGH_COUPLING_THRESHOLD:
        score += 1
    if complexity > 0.3:
        score += 1
    if total_callers > HIGH_CALLER_COUNT_THRESHOLD:
        score += 1
        recommendations.append(f"High caller count ({total_callers}): verify all callers")
    if risk > 0.5:
        score += 2
        recommendations.append("High risk exposure: ensure tests and review")

    if score >= 6:
        return {'level': 'dangerous', 'reason': 'High risk multi-domain change',
                'recommendations': recommendations}
    elif score >= 4:
        return {'level': 'risky', 'reason': 'Significant impact across domains',
                'recommendations': recommendations}
    elif score >= 2:
        return {'level': 'cautious', 'reason': 'Moderate impact detected',
                'recommendations': recommendations}
    else:
        return {'level': 'safe', 'reason': 'Low impact change',
                'recommendations': recommendations}


def should_block(grade: str) -> bool:
    """Should a change be blocked based on its simulation grade?"""
    return grade == 'dangerous'


def should_warn(grade: str) -> bool:
    """Should a prominent warning be shown for this grade?"""
    return grade in ('dangerous', 'risky')


def simulate_batch(file_paths: list[str]) -> str:
    """Run simulation and return a human-readable summary."""
    result = simulate_change(file_paths)
    deltas = result.get('deltas', {})

    lines = [
        f"**Simulation grade: {result['grade'].upper()}**",
        f"Reason: {result['reason']}",
        f"Affected: {result['affected_symbols']} symbols, "
        f"{result['total_callers']} callers",
    ]

    if result.get('cross_domain'):
        lines.append(f"Domains: {', '.join(result['affected_domains'])}")

    if result.get('recommendations'):
        lines.append("Recommendations:")
        for rec in result['recommendations']:
            lines.append(f"  - {rec}")

    return '\n'.join(lines)
