"""File walker, SHA256 hashing, and language detection for repository indexing."""

from __future__ import annotations

import os
import hashlib
import json
from datetime import datetime, timezone
from typing import Callable

from . import PROJECT_DIR, INDEX_DIR, LAST_INDEX_PATH, LOCK_PATH

# Directories and files to exclude from indexing
EXCLUDE_DIRS = {
    '.git', 'node_modules', '__pycache__', '.venv', 'venv', '.env',
    'dist', 'build', 'target', '.next', '.nuxt', 'coverage',
    '.claude', '.idea', '.vscode', '.vs', 'bin', 'obj',
    'vendor', 'bower_components', '.pytest_cache', '.mypy_cache',
    '.tox', 'eggs', '.eggs', 'wheels', '.cache', 'out',
    '.turbo', '.angular', 'tmp', 'temp', 'logs',
}

EXCLUDE_FILES = {
    '.DS_Store', 'Thumbs.db', 'desktop.ini',
}

# Binary file extensions to skip
BINARY_EXTENSIONS = {
    '.png', '.jpg', '.jpeg', '.gif', '.bmp', '.ico', '.svg',
    '.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx',
    '.zip', '.tar', '.gz', '.bz2', '.7z', '.rar',
    '.exe', '.dll', '.so', '.dylib', '.wasm', '.obj', '.o',
    '.mp3', '.mp4', '.avi', '.mov', '.wmv', '.flv',
    '.ttf', '.otf', '.woff', '.woff2', '.eot',
    '.db', '.sqlite', '.sqlite3', '.duckdb',
    '.pyc', '.pyo', '.class', '.jar',
    '.lock', '.lockb',
}

# File extension -> language mapping
EXTENSION_LANGUAGE_MAP = {
    '.py': 'python',
    '.pyx': 'python',
    '.ts': 'typescript',
    '.tsx': 'typescript',
    '.js': 'javascript',
    '.jsx': 'javascript',
    '.mjs': 'javascript',
    '.cjs': 'javascript',
    '.go': 'go',
    '.rs': 'rust',
    '.java': 'java',
    '.kt': 'kotlin',
    '.kts': 'kotlin',
    '.cpp': 'cpp',
    '.cc': 'cpp',
    '.cxx': 'cpp',
    '.c': 'c',
    '.h': 'c',
    '.hpp': 'cpp',
    '.cs': 'csharp',
    '.rb': 'ruby',
    '.php': 'php',
    '.swift': 'swift',
    '.scala': 'scala',
    '.r': 'r',
    '.lua': 'lua',
    '.sql': 'sql',
    '.graphql': 'graphql',
    '.gql': 'graphql',
    '.proto': 'protobuf',
    '.yaml': 'yaml',
    '.yml': 'yaml',
    '.json': 'json',
    '.md': 'markdown',
    '.mdx': 'markdown',
    '.xml': 'xml',
    '.html': 'html',
    '.htm': 'html',
    '.css': 'css',
    '.scss': 'scss',
    '.less': 'less',
    '.sh': 'shell',
    '.bash': 'shell',
    '.zsh': 'shell',
    '.fish': 'shell',
    '.ps1': 'powershell',
    '.psm1': 'powershell',
    '.tf': 'terraform',
    '.tfvars': 'terraform',
    '.hcl': 'terraform',
    '.dockerfile': 'dockerfile',
    '.toml': 'toml',
    '.ini': 'ini',
    '.cfg': 'ini',
    '.env': 'env',
    '.vue': 'vue',
    '.svelte': 'svelte',
    '.astro': 'astro',
    '.prisma': 'prisma',
    '.sol': 'solidity',
    '.move': 'move',
    '.zig': 'zig',
    '.nim': 'nim',
    '.elm': 'elm',
    '.hs': 'haskell',
    '.ml': 'ocaml',
    '.mli': 'ocaml',
    '.clj': 'clojure',
    '.cljs': 'clojure',
    '.cljc': 'clojure',
    '.edn': 'clojure',
    '.ex': 'elixir',
    '.exs': 'elixir',
    '.erl': 'erlang',
    '.hrl': 'erlang',
    '.dart': 'dart',
    '.nix': 'nix',
}

# Special filename-based language detection (overrides extension)
FILENAME_LANGUAGE_MAP = {
    'Dockerfile': 'dockerfile',
    'Makefile': 'makefile',
    'CMakeLists.txt': 'cmake',
    'BUILD': 'bazel',
    'WORKSPACE': 'bazel',
    'Justfile': 'just',
}


def detect_language(file_path: str) -> str:
    """Detect the programming language of a file based on name and extension."""
    basename = os.path.basename(file_path)
    if basename in FILENAME_LANGUAGE_MAP:
        return FILENAME_LANGUAGE_MAP[basename]

    # Check for compound extensions like .test.ts, .spec.js, .d.ts
    name_lower = basename.lower()
    for ext, lang in EXTENSION_LANGUAGE_MAP.items():
        if name_lower.endswith(ext):
            return lang

    _, ext = os.path.splitext(file_path)
    ext = ext.lower()
    return EXTENSION_LANGUAGE_MAP.get(ext, 'unknown')


def is_binary(file_path: str) -> bool:
    """Check if a file is binary by extension and null byte detection."""
    ext = os.path.splitext(file_path)[1].lower()
    if ext in BINARY_EXTENSIONS:
        return True
    try:
        with open(file_path, 'rb') as f:
            chunk = f.read(8192)
            return b'\x00' in chunk
    except (OSError, IOError):
        return True


def is_excluded(file_path: str, root: str) -> bool:
    """Check if a file or directory should be excluded from indexing."""
    parts = os.path.relpath(file_path, root).split(os.sep)
    for part in parts:
        if part in EXCLUDE_DIRS:
            return True
    basename = os.path.basename(file_path)
    if basename in EXCLUDE_FILES:
        return True
    return False


def compute_sha256(file_path: str) -> str:
    """Compute SHA256 hash of a file."""
    hasher = hashlib.sha256()
    with open(file_path, 'rb') as f:
        for chunk in iter(lambda: f.read(65536), b''):
            hasher.update(chunk)
    return hasher.hexdigest()


def count_lines(file_path: str) -> int:
    """Count lines in a text file efficiently."""
    try:
        with open(file_path, 'r', encoding='utf-8', errors='replace') as f:
            return sum(1 for _ in f)
    except (OSError, IOError):
        return 0


def walk_repository(
    root: str | None = None,
    on_file: Callable[[str, str, int], None] | None = None,
    on_progress: Callable[[int, int], None] | None = None
) -> list[dict]:
    """
    Walk the repository and return file info for all source files.

    Args:
        root: Repository root directory. Defaults to PROJECT_DIR.
        on_file: Optional callback called as (file_path, language, file_size) for each file.
        on_progress: Optional callback called as (scanned, total_dirs) periodically.

    Returns:
        List of dicts with keys: file_path, sha256, language, file_size, line_count
    """
    root = root or PROJECT_DIR
    results = []
    file_count = 0

    for dirpath, dirnames, filenames in os.walk(root):
        # Filter excluded directories in-place
        dirnames[:] = [d for d in dirnames if d not in EXCLUDE_DIRS and not d.startswith('.')]

        for filename in filenames:
            full_path = os.path.join(dirpath, filename)

            if is_excluded(full_path, root):
                continue
            if is_binary(full_path):
                continue

            try:
                file_size = os.path.getsize(full_path)
            except OSError:
                continue

            if file_size == 0:
                continue

            language = detect_language(full_path)
            if language == 'unknown':
                continue

            sha256 = compute_sha256(full_path)
            line_count = count_lines(full_path)

            result = {
                'file_path': os.path.relpath(full_path, root).replace('\\', '/'),
                'sha256': sha256,
                'language': language,
                'file_size': file_size,
                'line_count': line_count,
            }
            results.append(result)

            if on_file:
                on_file(result['file_path'], language, file_size)

            file_count += 1

    return results


def get_changed_files(
    previous_manifest: dict[str, str] | None
) -> tuple[list[str], list[str], list[str]]:
    """
    Compare current filesystem against a previous manifest (path -> sha256 map).
    Returns (added, modified, deleted) lists of file paths.
    """
    if previous_manifest is None:
        all_files = walk_repository()
        return ([f['file_path'] for f in all_files], [], [])

    current = {}
    for f in walk_repository():
        current[f['file_path']] = f['sha256']

    added = [p for p in current if p not in previous_manifest]
    modified = [p for p in current if p in previous_manifest and current[p] != previous_manifest[p]]
    deleted = [p for p in previous_manifest if p not in current]

    return added, modified, deleted


def load_previous_manifest() -> dict[str, str] | None:
    """Load the previous file manifest (path -> sha256) from the index database."""
    try:
        from .manifest import get_connection
        conn = get_connection()
        try:
            cur = conn.execute("SELECT file_path, sha256 FROM files")
            return {row[0]: row[1] for row in cur.fetchall()}
        finally:
            conn.close()
    except Exception:
        return None


def write_last_index_timestamp() -> None:
    """Write the current timestamp to .claude/index/repo-cognition/last_index.txt."""
    now = datetime.now(timezone.utc).isoformat()
    with open(LAST_INDEX_PATH, 'w') as f:
        f.write(now)


def write_lock(pid: int | None = None) -> None:
    """Write an indexing lock file with the current process PID."""
    if pid is None:
        pid = os.getpid()
    with open(LOCK_PATH, 'w') as f:
        json.dump({'pid': pid, 'started_at': datetime.now(timezone.utc).isoformat()}, f)


def remove_lock() -> None:
    """Remove the indexing lock file."""
    try:
        os.remove(LOCK_PATH)
    except FileNotFoundError:
        pass


def is_locked() -> bool:
    """Check if indexing is currently in progress."""
    if not os.path.exists(LOCK_PATH):
        return False
    try:
        with open(LOCK_PATH) as f:
            data = json.load(f)
        pid = data.get('pid')
        if pid is None:
            return False
        # Check if process is still running
        try:
            os.kill(pid, 0)
            return True
        except OSError:
            # Process no longer exists; stale lock
            remove_lock()
            return False
    except (json.JSONDecodeError, KeyError):
        remove_lock()
        return False
