"""Reality Alignment — code correctness != business correctness.

Multi-objective Pareto optimization across simplicity, performance,
maintainability, and safety. Checks whether implementation serves
business intent rather than just being technically correct.
"""

from __future__ import annotations


def check_business_correctness(symbol_name: str) -> dict:
    """Check if a symbol's implementation aligns with its declared intent.

    Cross-references intent_records with actual implementation patterns.
    """
    try:
        from .manifest import get_connection
        conn = get_connection()
        try:
            cur = conn.execute(
                """SELECT ir.intent_category, ir.rationale, ir.constraints,
                          s.kind, s.has_side_effects, s.security_sensitive,
                          f.file_path, f.language
                   FROM intent_records ir
                   JOIN symbols s ON s.name = ir.symbol_name
                   JOIN files f ON s.file_id = f.id
                   WHERE ir.symbol_name = ?
                   LIMIT 1""",
                (symbol_name,)
            )
            row = cur.fetchone()
            if row is None:
                return {
                    'symbol': symbol_name,
                    'aligned': None,
                    'detail': 'No intent record found — cannot assess alignment',
                }

            intent_cat, rationale, constraints_json, kind, side_effects, sec_sensitive, file_path, lang = row

            misalignments = []

            if intent_cat == 'security' and not sec_sensitive:
                misalignments.append('Security intent but not marked security_sensitive')
            if intent_cat == 'performance' and not side_effects:
                misalignments.append('Performance intent but no side effects (possibly pure)')
            if intent_cat == 'abstraction' and kind not in ('class', 'interface', 'struct'):
                misalignments.append('Abstraction intent but not a class/interface/struct')

            return {
                'symbol': symbol_name,
                'intent': intent_cat,
                'rationale': rationale,
                'file': file_path,
                'aligned': len(misalignments) == 0,
                'misalignments': misalignments,
            }
        finally:
            conn.close()
    except Exception:
        return {'symbol': symbol_name, 'aligned': None, 'detail': 'Error checking alignment'}
    return mismatches


def pareto_optimize(weights: dict[str, float] | None = None) -> dict:
    """Multi-objective optimization across architectural objectives.

    Default weights balance: simplicity, performance, maintainability, safety.
    Custom weights allow tradeoff exploration (e.g., favor performance over simplicity).

    Returns Pareto-optimal file ranking.
    """
    if weights is None:
        weights = {
            'simplicity': 0.25,
            'performance': 0.25,
            'maintainability': 0.25,
            'safety': 0.25,
        }

    results = []
    try:
        from .manifest import get_connection
        conn = get_connection()
        try:
            cur = conn.execute(
                """SELECT f.file_path, f.line_count, f.language,
                          f.architectural_drift_score,
                          COUNT(DISTINCT s.id) AS sym_count,
                          AVG(s.confidence_score) AS avg_conf
                   FROM files f
                   LEFT JOIN symbols s ON f.id = s.file_id
                   GROUP BY f.id
                   HAVING COUNT(DISTINCT s.id) > 0
                   LIMIT 100"""
            )
            for file_path, lines, lang, drift, sym_count, avg_conf in cur.fetchall():
                simplicity = max(0, 1.0 - (drift or 0) - (lines or 0) / 2000.0)
                maintainability = min(1.0, (avg_conf or 0.5) + (1.0 - (drift or 0)))
                safety = 1.0 if avg_conf and avg_conf > 0.7 else 0.5

                composite = (
                    weights['simplicity'] * simplicity +
                    weights['performance'] * 0.5 +  # No direct perf data — neutral
                    weights['maintainability'] * maintainability +
                    weights['safety'] * safety
                )

                results.append({
                    'file': file_path,
                    'composite_score': round(composite, 3),
                    'simplicity': round(simplicity, 3),
                    'maintainability': round(maintainability, 3),
                    'safety': round(safety, 3),
                })
        finally:
            conn.close()
    except Exception:
        pass

    results.sort(key=lambda r: r['composite_score'], reverse=True)
    return {
        'weights': weights,
        'files_ranked': len(results),
        'top_performers': results[:10],
        'needs_attention': [r for r in results if r['composite_score'] < 0.4][:10],
    }


def compute_pareto_frontier() -> dict:
    """Compute the tradeoff frontier across competing objectives.

    Identifies files that are optimal in at least one dimension
    (Pareto-optimal set).
    """
    return pareto_optimize({
        'simplicity': 0.4,
        'performance': 0.2,
        'maintainability': 0.2,
        'safety': 0.2,
    })
