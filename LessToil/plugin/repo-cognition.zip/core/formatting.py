"""Ultra-compact ANSI formatting for repo-cognition hook output.

Design principle: all analysis runs at full speed, but output is minimal.
Safe edits are silent. Only risky/dangerous/blocked edits produce visible
output, and even then it's a single color-coded line, not a multi-line card.

Matches Claude Code's native Ink/React terminal look -- color badges,
bold for emphasis, dim for metadata. No box-drawing characters, no quotes,
no decoration. Every character earns its place.
"""

from __future__ import annotations

import random
import time

# ---------------------------------------------------------------------------
# ANSI color/style constants -- match Claude Code's Ink palette
# ---------------------------------------------------------------------------

_RESET = '\x1b[0m'
BOLD = '\x1b[1m'
DIM = '\x1b[2m'

GREEN = '\x1b[32m'
YELLOW = '\x1b[33m'
RED = '\x1b[31m'
CYAN = '\x1b[36m'

BRIGHT_GREEN = '\x1b[92m'
BRIGHT_YELLOW = '\x1b[93m'
BRIGHT_RED = '\x1b[91m'

# Badge backgrounds
_BADGE_SAFE = '\x1b[42m\x1b[30m'      # green bg, black text
_BADGE_WARN = '\x1b[43m\x1b[30m'      # yellow bg, black text
_BADGE_DANGER = '\x1b[41m\x1b[97m'    # red bg, white text
_BADGE_INFO = '\x1b[44m\x1b[97m'      # blue bg, white text


def _s(text: str, *styles: str) -> str:
    """Wrap text in ANSI styles, auto-resetting at end."""
    return ''.join(styles) + text + _RESET


def _badge(text: str, bg: str) -> str:
    """A color badge: [SAFE], [WARN], [BLOCKED]."""
    return bg + f' {text} ' + _RESET


def _file_label(paths: list[str]) -> str:
    """Compact file label from a list of paths."""
    if not paths:
        return '?'
    if len(paths) == 1:
        p = paths[0]
        return p if len(p) <= 40 else '...' + p[-37:]
    return f'{len(paths)} files'


# ---------------------------------------------------------------------------
# Pre-edit output -- only for noteworthy edits
# ---------------------------------------------------------------------------

def safe_line(file_paths: list[str], domain: str, callers: int, ms: float) -> str:
    """Silent -- returns empty string. Safe edits don't need output."""
    return ''


def cautious_line(file_paths: list[str], domain: str, callers: int,
                  warnings: list[str], ms: float) -> str:
    """One subtle dim line for cautious edits. Does not demand attention."""
    label = _file_label(file_paths)
    return _s(
        f'{_badge("·", _BADGE_SAFE)} {label}  {_s(domain, CYAN)}  '
        f'{callers} caller(s)  {_s(f"{ms:.0f}ms", DIM)}',
        DIM
    )


def risky_line(file_paths: list[str], domain: str, callers: int,
               affected_domains: list[str], warnings: list[str],
               sim_grade: str, ms: float) -> str:
    """One prominent line for risky edits. Gets attention but not a card."""
    label = _file_label(file_paths)
    parts = [
        f'{_badge("RISKY", _BADGE_WARN)} {_s(label, BOLD)}',
        f'{_s(domain, CYAN)} domain',
        f'{callers} callers',
    ]
    if affected_domains:
        cross = ', '.join(affected_domains[:2])
        if len(affected_domains) > 2:
            cross += f' +{len(affected_domains) - 2}'
        parts.append(_s(f'cross-domain: {cross}', YELLOW))
    parts.append(_s(f'{ms:.0f}ms', DIM))

    line = '  '.join(parts)
    if warnings:
        first_warning = warnings[0]
        if len(first_warning) > 80:
            first_warning = first_warning[:77] + '...'
        line += '\n' + _s(f'     {first_warning}', YELLOW)
    return line


def dangerous_line(file_paths: list[str], errors: list[str],
                   ms: float) -> str:
    """High-risk warning line -- red, clear, explains the concern but never blocks."""
    label = _file_label(file_paths)
    lines = [
        f'{_badge("WARNING", _BADGE_DANGER)} {_s(label, BOLD)}  '
        f'{_s("review recommended", RED)}  {_s(f"{ms:.0f}ms", DIM)}',
    ]
    for err in errors[:3]:
        if len(err) > 80:
            err = err[:77] + '...'
        lines.append(_s(f'     {err}', RED))
    return '\n'.join(lines)


# ---------------------------------------------------------------------------
# Post-edit -- silent, reindex happens without announcement
# ---------------------------------------------------------------------------

def post_edit_line(file_count: int, total_symbols: int, ms: float) -> str:
    """Silent -- returns empty string. Reindexing is background noise."""
    return ''


# ---------------------------------------------------------------------------
# Session-start dashboard -- compact metrics, no decoration
# ---------------------------------------------------------------------------

def dashboard_compact(stats: dict, indexing_time: float,
                      health: str, domain_count: int,
                      temporal: dict, drift: dict) -> str:
    """One compact dashboard section that shows everything in ~8 lines."""
    fc = stats.get('file_count', 0)
    sc = stats.get('symbol_count', 0)
    ec = stats.get('edge_count', 0)

    # Health indicator
    if sc > 0 and ec > 0:
        health_dot = _s('*', GREEN)
    elif fc > 0:
        health_dot = _s('~', YELLOW)
    else:
        health_dot = _s('-', DIM)

    lines = [
        f'{health_dot} {_s("Repo Cognition", BOLD)}  '
        f'{fc} files  {sc} symbols  {ec} edges  '
        f'{_s(f"{indexing_time:.1f}s", DIM)}',
    ]

    # Domain count
    if domain_count:
        lines.append(_s(f'   {domain_count} domains', DIM))

    # Temporal risk snippet
    if temporal.get('available') and temporal.get('files_analyzed', 0) > 0:
        avg = temporal.get('average_risk', 0)
        high = temporal.get('high_risk_count', 0)
        crit = temporal.get('critical_risk_count', 0)
        if crit > 0:
            risk = _s(f'risk:{avg:.2f} high:{high} crit:{crit}', RED)
        elif high > 3:
            risk = _s(f'risk:{avg:.2f} high:{high}', YELLOW)
        else:
            risk = _s(f'risk:{avg:.2f}', DIM)
        lines.append(f'   {risk}')

    # Drift snippet
    if drift.get('files_analyzed', 0) > 0:
        avg_d = drift.get('average_drift', 0)
        high_d = drift.get('high_drift_files', 0)
        if high_d > 5:
            d = _s(f'drift:{avg_d:.2f} ({high_d} files)', YELLOW)
        elif high_d > 0:
            d = _s(f'drift:{avg_d:.2f} ({high_d} files)', DIM)
        else:
            d = _s(f'drift:{avg_d:.2f}', DIM)
        lines.append(f'   {d}')

    # Footer -- available commands
    lines.append(_s('   /index-status  /index-graph  /index-rebuild', DIM))

    return '\n'.join(lines)


# ---------------------------------------------------------------------------
# Status line -- always-visible terminal footer
# ---------------------------------------------------------------------------

def build_status_line(stats: dict, temporal: dict, drift: dict) -> str:
    """Compact ANSI-colored status line for the Claude Code status bar."""
    file_count = stats.get('file_count', 0)
    symbol_count = stats.get('symbol_count', 0)

    if symbol_count > 0:
        health = _s('*', GREEN)
    else:
        health = _s('-', DIM)

    if temporal.get('available') and temporal.get('files_analyzed', 0) > 0:
        critical = temporal.get('critical_risk_count', 0)
        if critical > 0:
            risk_icon = _s('>>', RED)
        elif temporal.get('high_risk_count', 0) > 3:
            risk_icon = _s('>', YELLOW)
        else:
            risk_icon = _s('*', GREEN)
    else:
        risk_icon = _s('-', DIM)

    drift_str = ''
    if drift.get('files_analyzed', 0) > 0:
        high_drift = drift.get('high_drift_files', 0)
        if high_drift > 5:
            drift_str = f' drift:{_s(str(high_drift), YELLOW)}'
        elif high_drift > 0:
            drift_str = f' drift:{high_drift}'
        else:
            drift_str = f' drift:{_s("0", GREEN)}'

    parts = [f'{health} {file_count}f / {symbol_count}s', f'{risk_icon}']
    if drift_str:
        parts.append(drift_str)
    return '  '.join(parts)


# ---------------------------------------------------------------------------
# Random quotes -- kept in module but NOT used in output (noise reduction)
# ---------------------------------------------------------------------------

QUOTES = [
    ("First, do no harm. Then, do less.", "Architecture wisdom"),
    ("The best code is the code you never write.", "Anonymous"),
    ("Make it work, make it right, make it fast -- in that order.", "Kent Beck"),
    ("Duplication is the primary enemy of a well-designed system.", "The DRY principle"),
    ("Simplicity is the ultimate sophistication.", "Leonardo da Vinci"),
    ("Any fool can write code a computer can understand. Good programmers write code humans can understand.", "Martin Fowler"),
    ("The cheapest, fastest, and most reliable components are those that aren't there.", "Gordon Bell"),
    ("Complex systems that work evolved from simple systems that worked.", "Gall's Law"),
    ("Perfection is achieved not when there is nothing more to add, but when there is nothing left to take away.", "Antoine de Saint-Exupéry"),
    ("The structure of a system reflects the structure of the organization that built it.", "Conway's Law"),
    ("Code without tests is broken by design.", "Jacob Kaplan-Moss"),
    ("Talk is cheap. Show me the code.", "Linus Torvalds"),
    ("When you feel the need to write a comment, first try to refactor the code so the comment becomes unnecessary.", "Martin Fowler"),
    ("It's harder to read code than to write it.", "Joel Spolsky"),
    ("Measuring programming progress by lines of code is like measuring aircraft building progress by weight.", "Bill Gates"),
]


def random_quote() -> tuple[str, str]:
    """Return (quote_text, attribution). Available but not injected into output."""
    return random.choice(QUOTES)


# ---------------------------------------------------------------------------
# Dashboard header -- used by session_start dashboard
# ---------------------------------------------------------------------------

def build_dashboard_header() -> str:
    """Build the top section of the dashboard with a random quote."""
    quote, author = random.choice(QUOTES)
    lines = [
        '+' + '-' * 58 + '+',
        f'|  >>  REPOSITORY COGNITION  --  Index Dashboard             |',
    ]
    # Truncate quote to fit
    display_quote = quote if len(quote) <= 56 else quote[:53] + '...'
    lines.append(f'|  "{display_quote}"')
    if author:
        lines.append(f'|  -- {author[:50]}')
    return '\n'.join(lines)


# ---------------------------------------------------------------------------
# Error and diagnostic formatting
# ---------------------------------------------------------------------------

def format_error_summary(errors: list[str]) -> str:
    """Format a compact error summary for dashboard display (ASCII-safe)."""
    if not errors:
        return ''
    lines = ['  --  INDEXING WARNINGS']
    for e in errors[-8:]:
        truncated = e[:120] + ('...' if len(e) > 120 else '')
        lines.append(f'     !!  {truncated}')
    if len(errors) > 8:
        lines.append(f'     ... and {len(errors) - 8} more')
    lines.append('')
    return '\n'.join(lines)


def format_diagnostic_result(report: dict) -> str:
    """Render a diagnostic report (ASCII-safe for cross-platform compatibility)."""
    overall = report.get('overall', '?')
    overall_icon = {'PASS': '*', 'WARN': '!', 'FAIL': 'X'}.get(overall, '?')

    lines = []
    lines.append('+' + '-' * 58 + '+')
    lines.append(f'|  REPOSITORY COGNITION  --  System Check                     |')
    lines.append(f'|  [{overall_icon}]  {overall:<53}|')
    lines.append(f'|  {report.get("pass_count", 0)} pass  |  {report.get("warn_count", 0)} warn  |  '
                 f'{report.get("fail_count", 0)} fail  |  {report.get("skip_count", 0)} skip     |')
    lines.append('+' + '-' * 58 + '+')
    lines.append('')

    for check in report.get('checks', []):
        status = check.get('status', '?')
        icon = {'PASS': '[OK]', 'WARN': '[!!]', 'FAIL': '[XX]', 'SKIP': '[--]'}.get(status, '[  ]')
        name = check.get('name', '')
        detail = check.get('detail', '')
        fix = check.get('fix', '')

        lines.append(f'  {icon}  {name}')
        if detail:
            lines.append(f'       {detail}')
        if fix:
            lines.append(f'       -> Fix: {fix}')
        lines.append('')

    lines.append('  ' + '=' * 58)
    return '\n'.join(lines)
