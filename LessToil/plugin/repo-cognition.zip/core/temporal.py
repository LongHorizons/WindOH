"""Temporal architectural intelligence via git history analysis.

Computes per-file risk scores from churn frequency, bug fix density,
security patch frequency, and ownership volatility. Results are cached
by git HEAD hash — reparse only when HEAD changes.
"""

from __future__ import annotations

import json
import os
import re
import subprocess
from dataclasses import dataclass, field

from .manifest import get_connection

# Risk score weights (configurable via local.md in future)
CHURN_WEIGHT = 0.35
INSTABILITY_WEIGHT = 0.25
BUG_DENSITY_WEIGHT = 0.20
SECURITY_PATCH_WEIGHT = 0.20

# Regex patterns for commit classification
BUG_FIX_PATTERN = re.compile(
    r'\b(?:fix|bug|patch|hotfix|issue|resolve|closes|correct)\b', re.IGNORECASE
)
SECURITY_PATCH_PATTERN = re.compile(
    r'\b(?:security|vuln|vulnerability|CVE|exploit|inject|XSS|CSRF|bypass|auth[eo]rization)\b',
    re.IGNORECASE
)

# Risk thresholds
RISK_THRESHOLD_HIGH = 0.7
RISK_THRESHOLD_CRITICAL = 0.9


@dataclass
class TemporalMetrics:
    file_path: str
    total_commits: int = 0
    bug_fix_commits: int = 0
    security_patch_commits: int = 0
    distinct_authors: int = 0
    first_commit_date: str = ''
    last_commit_date: str = ''
    churn_rate: float = 0.0       # commits per month
    bug_density: float = 0.0       # bug commits / total commits
    security_density: float = 0.0  # security commits / total commits
    ownership_volatility: float = 0.0  # authors / commits (0-1, >0 = more volatile)
    instability: float = 0.0       # recent change frequency
    risk_score: float = 0.0


def _get_project_root() -> str:
    """Get the project root directory. Returns empty string if not found."""
    for env_var in ('CLAUDE_PROJECT_DIR', 'PROJECT_DIR'):
        val = os.environ.get(env_var, '')
        if val:
            return val
    try:
        result = subprocess.run(
            ['git', 'rev-parse', '--show-toplevel'],
            capture_output=True, text=True, timeout=10
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except Exception:
        pass
    return os.getcwd()


def _get_git_head() -> str:
    """Get the current git HEAD hash. Returns empty string if unavailable."""
    try:
        result = subprocess.run(
            ['git', 'rev-parse', 'HEAD'],
            capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except Exception:
        pass
    return ''


def _get_cached_head() -> str:
    """Get the HEAD hash cached in temporal_metrics metadata."""
    conn = get_connection()
    try:
        cur = conn.execute(
            "SELECT head_hash FROM temporal_metadata WHERE id = 1"
        )
        row = cur.fetchone()
        return row[0] if row else ''
    except Exception:
        return ''
    finally:
        conn.close()


def _cache_head(head_hash: str) -> None:
    """Store the current HEAD hash for cache invalidation."""
    conn = get_connection()
    try:
        conn.execute(
            "INSERT OR REPLACE INTO temporal_metadata (id, head_hash, computed_at) "
            "VALUES (1, ?, datetime('now'))",
            (head_hash,)
        )
        conn.commit()
    finally:
        conn.close()


def _is_git_repo() -> bool:
    """Check if the current directory is inside a git repository."""
    try:
        result = subprocess.run(
            ['git', 'rev-parse', '--git-dir'],
            capture_output=True, text=True, timeout=5
        )
        return result.returncode == 0
    except Exception:
        return False


def _parse_git_log(git_log_depth: int = 500) -> dict[str, TemporalMetrics]:
    """Parse git log and return per-file temporal metrics.

    Uses git log --numstat to get per-commit per-file changes.
    Returns a dict mapping file_path -> TemporalMetrics.
    """
    if not _is_git_repo():
        return {}

    try:
        result = subprocess.run(
            ['git', 'log', f'-n{git_log_depth}',
             '--format=COMMIT %H%n%AUTHOR %an%nDATE %ai%nSUBJECT %s%n%BODY %b%n---',
             '--numstat', '--no-merges'],
            capture_output=True, text=True, timeout=30
        )
        if result.returncode != 0:
            return {}
    except (subprocess.TimeoutExpired, Exception):
        return {}

    return _parse_log_output(result.stdout)


def _parse_log_output(output: str) -> dict[str, TemporalMetrics]:
    """Parse raw git log output into per-file metrics."""
    file_metrics: dict[str, TemporalMetrics] = {}
    current_subject = ''
    current_date = ''
    current_author = ''
    is_bug_fix = False
    is_security = False

    for line in output.split('\n'):
        if line.startswith('COMMIT '):
            current_subject = ''
            current_date = ''
            current_author = ''
            is_bug_fix = False
            is_security = False
        elif line.startswith('SUBJECT '):
            current_subject = line[8:]
            is_bug_fix = bool(BUG_FIX_PATTERN.search(current_subject))
            is_security = bool(SECURITY_PATCH_PATTERN.search(current_subject))
        elif line.startswith('BODY '):
            body = line[5:]
            if BUG_FIX_PATTERN.search(body):
                is_bug_fix = True
            if SECURITY_PATCH_PATTERN.search(body):
                is_security = True
        elif line.startswith('DATE '):
            current_date = line[5:].strip()
        elif line.startswith('AUTHOR '):
            current_author = line[7:].strip()
        elif line == '---':
            pass
        elif line and line[0].isdigit():
            # --numstat line: additions<TAB>deletions<TAB>filepath
            parts = line.split('\t')
            if len(parts) >= 3:
                file_path = parts[2]
                if file_path not in file_metrics:
                    file_metrics[file_path] = TemporalMetrics(file_path=file_path)

                fm = file_metrics[file_path]
                fm.total_commits += 1
                if is_bug_fix:
                    fm.bug_fix_commits += 1
                if is_security:
                    fm.security_patch_commits += 1

                # Track authors and dates
                if current_author:
                    fm.distinct_authors = len({current_author})  # approximated
                    # We track unique authors per file with a set in the caller
                if current_date:
                    if not fm.last_commit_date or current_date > fm.last_commit_date:
                        fm.last_commit_date = current_date
                    if not fm.first_commit_date or current_date < fm.first_commit_date:
                        fm.first_commit_date = current_date

    return _compute_derived_metrics(file_metrics, output)


def _compute_derived_metrics(
    metrics: dict[str, TemporalMetrics], raw_output: str
) -> dict[str, TemporalMetrics]:
    """Compute derived metrics: churn rate, densities, risk scores."""
    # Collect per-file unique authors
    file_authors: dict[str, set] = {}
    current_author = ''
    current_files: list[str] = []

    for line in raw_output.split('\n'):
        if line.startswith('AUTHOR '):
            current_author = line[7:].strip()
        elif line and line[0].isdigit():
            parts = line.split('\t')
            if len(parts) >= 3:
                file_path = parts[2]
                if file_path in metrics and current_author:
                    if file_path not in file_authors:
                        file_authors[file_path] = set()
                    file_authors[file_path].add(current_author)

    # Compute derived metrics
    for file_path, fm in metrics.items():
        if fm.total_commits > 0:
            fm.bug_density = fm.bug_fix_commits / fm.total_commits
            fm.security_density = fm.security_patch_commits / fm.total_commits
            if file_path in file_authors:
                fm.distinct_authors = len(file_authors[file_path])
                fm.ownership_volatility = fm.distinct_authors / fm.total_commits

        # Churn rate: commits per month (approximate)
        if fm.first_commit_date and fm.last_commit_date:
            try:
                from datetime import datetime
                first = datetime.fromisoformat(fm.first_commit_date.split(' ')[0])
                last = datetime.fromisoformat(fm.last_commit_date.split(' ')[0])
                months = max(1, (last - first).days / 30.0)
                fm.churn_rate = fm.total_commits / months
            except (ValueError, TypeError):
                fm.churn_rate = float(fm.total_commits)

        # Instability: recent change frequency (files changed in last 20% of commits)
        fm.instability = _compute_instability(file_path, raw_output)

        # Risk score
        fm.risk_score = _compute_risk_score(fm)

    return metrics


def _compute_instability(file_path: str, raw_output: str) -> float:
    """Compute instability as proportion of recent commits touching this file."""
    total_recent = 0
    file_recent = 0
    recent_threshold = max(1, len(raw_output.split('\n')) // 5)
    in_recent = False
    line_idx = 0

    for line in raw_output.split('\n'):
        if line.startswith('COMMIT '):
            if line_idx > (len(raw_output.split('\n')) - recent_threshold):
                in_recent = True
                total_recent += 1
            line_idx += 1
        elif in_recent and line and line[0].isdigit():
            parts = line.split('\t')
            if len(parts) >= 3 and parts[2] == file_path:
                file_recent += 1

    if total_recent == 0:
        return 0.0
    return min(1.0, file_recent / total_recent)


def _compute_risk_score(fm: TemporalMetrics) -> float:
    """Compute composite risk score from temporal metrics.

    Uses z-score normalization against all files for churn and bug density.
    For initial computation, uses raw values scaled to 0-1.
    """
    churn_component = min(1.0, fm.churn_rate / 20.0) if fm.churn_rate > 0 else 0.0
    instability_component = fm.instability
    bug_component = min(1.0, fm.bug_density * 5.0)
    security_component = min(1.0, fm.security_density * 10.0)

    return round(
        CHURN_WEIGHT * churn_component +
        INSTABILITY_WEIGHT * instability_component +
        BUG_DENSITY_WEIGHT * bug_component +
        SECURITY_PATCH_WEIGHT * security_component,
        4
    )


def compute_temporal_metrics(force: bool = False) -> dict:
    """Compute and store temporal metrics for all files.

    Returns a summary dict with top risky files.
    Only recomputes if git HEAD changed (or force=True).
    """
    if not _is_git_repo():
        return {'status': 'skipped', 'reason': 'not a git repository'}

    head = _get_git_head()
    if not head:
        return {'status': 'skipped', 'reason': 'unable to determine git HEAD'}

    cached = _get_cached_head()
    if not force and cached == head:
        return {'status': 'cached', 'head': head[:8]}

    # Parse git log
    file_metrics = _parse_git_log()

    if not file_metrics:
        return {'status': 'skipped', 'reason': 'no file history found'}

    # Store in database
    conn = get_connection()
    try:
        conn.execute("DELETE FROM temporal_metrics")
        for fm in file_metrics.values():
            conn.execute(
                """INSERT INTO temporal_metrics
                   (file_path, total_commits, bug_fix_commits, security_patch_commits,
                    distinct_authors, first_commit_date, last_commit_date,
                    churn_rate, bug_density, security_density,
                    ownership_volatility, instability, risk_score)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (fm.file_path, fm.total_commits, fm.bug_fix_commits,
                 fm.security_patch_commits, fm.distinct_authors,
                 fm.first_commit_date, fm.last_commit_date,
                 fm.churn_rate, fm.bug_density, fm.security_density,
                 fm.ownership_volatility, fm.instability, fm.risk_score)
            )
        conn.commit()
        _cache_head(head)
    finally:
        conn.close()

    return {
        'status': 'computed',
        'head': head[:8],
        'files_analyzed': len(file_metrics),
    }


def get_riskiest_files(limit: int = 10) -> list[dict]:
    """Return the top-N riskiest files by temporal risk score."""
    conn = get_connection()
    try:
        conn.row_factory = None
        cur = conn.execute(
            """SELECT file_path, risk_score, total_commits, bug_fix_commits,
                      security_patch_commits, churn_rate, instability,
                      distinct_authors
               FROM temporal_metrics
               ORDER BY risk_score DESC
               LIMIT ?""",
            (limit,)
        )
        return [
            {
                'file_path': r[0], 'risk_score': r[1],
                'total_commits': r[2], 'bug_fix_commits': r[3],
                'security_patch_commits': r[4], 'churn_rate': round(r[5], 2),
                'instability': round(r[6], 3), 'distinct_authors': r[7],
            }
            for r in cur.fetchall()
        ]
    finally:
        conn.close()


def get_file_temporal_metrics(file_path: str) -> TemporalMetrics | None:
    """Get temporal metrics for a specific file."""
    conn = get_connection()
    try:
        cur = conn.execute(
            """SELECT file_path, total_commits, bug_fix_commits, security_patch_commits,
                      distinct_authors, first_commit_date, last_commit_date,
                      churn_rate, bug_density, security_density,
                      ownership_volatility, instability, risk_score
               FROM temporal_metrics WHERE file_path = ?""",
            (file_path,)
        )
        row = cur.fetchone()
        if row is None:
            return None
        return TemporalMetrics(
            file_path=row[0], total_commits=row[1], bug_fix_commits=row[2],
            security_patch_commits=row[3], distinct_authors=row[4],
            first_commit_date=row[5], last_commit_date=row[6],
            churn_rate=row[7], bug_density=row[8], security_density=row[9],
            ownership_volatility=row[10], instability=row[11], risk_score=row[12],
        )
    finally:
        conn.close()


def increment_change_counter(file_path: str) -> None:
    """Increment the change counter for a file (called from PostToolUse)."""
    conn = get_connection()
    try:
        conn.execute(
            """INSERT INTO temporal_change_log (file_path, changed_at)
               VALUES (?, datetime('now'))""",
            (file_path,)
        )
        conn.commit()
    except Exception:
        pass
    finally:
        conn.close()


def get_temporal_summary() -> dict:
    """Return a summary of temporal metrics for session context injection."""
    if not _is_git_repo():
        return {'available': False, 'reason': 'not a git repository'}

    conn = get_connection()
    try:
        total = conn.execute("SELECT COUNT(*) FROM temporal_metrics").fetchone()[0]
        if total == 0:
            return {'available': True, 'files_analyzed': 0}

        risky_count = conn.execute(
            "SELECT COUNT(*) FROM temporal_metrics WHERE risk_score >= ?",
            (RISK_THRESHOLD_HIGH,)
        ).fetchone()[0]

        critical_count = conn.execute(
            "SELECT COUNT(*) FROM temporal_metrics WHERE risk_score >= ?",
            (RISK_THRESHOLD_CRITICAL,)
        ).fetchone()[0]

        avg_risk = conn.execute(
            "SELECT AVG(risk_score) FROM temporal_metrics"
        ).fetchone()[0] or 0.0

        return {
            'available': True,
            'files_analyzed': total,
            'average_risk': round(avg_risk, 3),
            'high_risk_count': risky_count,
            'critical_risk_count': critical_count,
        }
    finally:
        conn.close()
