"""Formal Constraints — machine-enforced architectural rules.

Constraints are must/must_not rules checked via Python functions against
the indexed graph. They complement SQL invariants (governance.py) by
enforcing structural properties that require imperative logic.

Generation becomes constraint satisfaction, not autocomplete.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class FormalConstraint:
    name: str
    description: str
    constraint_type: str  # 'must' or 'must_not'
    scope: str = 'global'
    severity: str = 'error'
    enabled: bool = True


def _check_no_circular_imports() -> list[dict]:
    """Detect circular import chains in the call graph."""
    violations = []
    try:
        from .manifest import get_connection
        conn = get_connection()
        try:
            cur = conn.execute(
                """WITH RECURSIVE cycles AS (
                    SELECT s1.name AS start_name, ce.callee_name AS next_name,
                           1 AS depth, s1.name || '→' || ce.callee_name AS path
                    FROM call_edges ce
                    JOIN symbols s1 ON ce.caller_id = s1.id
                    UNION ALL
                    SELECT c.start_name, ce2.callee_name,
                           c.depth + 1, c.path || '→' || ce2.callee_name
                    FROM cycles c
                    JOIN symbols s ON s.name = c.next_name
                    JOIN call_edges ce2 ON s.id = ce2.caller_id
                    WHERE c.depth < 10 AND c.next_name != c.start_name
                )
                SELECT start_name, path, depth FROM cycles
                WHERE start_name = next_name AND depth > 1
                LIMIT 10"""
            )
            for start_name, path, depth in cur.fetchall():
                violations.append({
                    'constraint': 'no_circular_imports',
                    'symbol': start_name,
                    'cycle': path,
                    'depth': depth,
                })
        finally:
            conn.close()
    except Exception:
        pass
    return violations


def _check_no_unbounded_memory_growth() -> list[dict]:
    """Detect patterns suggesting unbounded memory growth."""
    violations = []
    try:
        from .manifest import get_connection
        conn = get_connection()
        try:
            # Look for symbols with names suggesting unbounded collections
            cur = conn.execute(
                """SELECT s.name, f.file_path
                   FROM symbols s JOIN files f ON s.file_id = f.id
                   WHERE (s.name LIKE '%cache%' OR s.name LIKE '%buffer%'
                          OR s.name LIKE '%pool%' OR s.name LIKE '%accumulate%')
                     AND s.name NOT LIKE '%_limit%'
                     AND s.name NOT LIKE '%_max%'
                     AND s.name NOT LIKE '%_cap%'
                   LIMIT 10"""
            )
            for name, file_path in cur.fetchall():
                violations.append({
                    'constraint': 'no_unbounded_memory_growth',
                    'symbol': name,
                    'file': file_path,
                    'detail': 'Potential unbounded collection without size limit',
                })
        finally:
            conn.close()
    except Exception:
        pass
    return violations


def _check_no_sync_io_on_hotpaths() -> list[dict]:
    """Detect synchronous I/O in high-churn hotpath files."""
    violations = []
    try:
        from .manifest import get_connection
        conn = get_connection()
        try:
            # Cross-reference temporal hotspots with I/O symbols
            cur = conn.execute(
                """SELECT s.name, f.file_path, tm.risk_score
                   FROM symbols s
                   JOIN files f ON s.file_id = f.id
                   JOIN temporal_metrics tm ON f.file_path = tm.file_path
                   WHERE tm.risk_score >= 0.7
                     AND (s.name LIKE '%read%' OR s.name LIKE '%write%'
                          OR s.name LIKE '%open%' OR s.name LIKE '%connect%'
                          OR s.name LIKE '%request%' OR s.name LIKE '%fetch%')
                     AND s.name NOT LIKE '%async%'
                     AND s.name NOT LIKE '%await%'
                   LIMIT 10"""
            )
            for name, file_path, risk in cur.fetchall():
                violations.append({
                    'constraint': 'no_sync_io_on_hotpaths',
                    'symbol': name,
                    'file': file_path,
                    'risk_score': risk,
                    'detail': 'Synchronous I/O in high-risk hotspot',
                })
        finally:
            conn.close()
    except Exception:
        pass
    return violations


def _check_no_unsafe_sql_concatenation() -> list[dict]:
    """Detect potential SQL injection patterns in symbol names/members."""
    violations = []
    try:
        from .manifest import get_connection
        conn = get_connection()
        try:
            cur = conn.execute(
                """SELECT s.name, f.file_path
                   FROM symbols s JOIN files f ON s.file_id = f.id
                   WHERE (s.name LIKE '%sql%' OR s.name LIKE '%query%'
                          OR s.name LIKE '%execute%')
                     AND (s.name LIKE '%format%' OR s.name LIKE '%concat%'
                          OR s.name LIKE '%string%' OR s.name LIKE '%build%')
                   LIMIT 10"""
            )
            for name, file_path in cur.fetchall():
                violations.append({
                    'constraint': 'no_unsafe_sql_concatenation',
                    'symbol': name,
                    'file': file_path,
                    'detail': 'Potential unsafe SQL string building',
                })
        finally:
            conn.close()
    except Exception:
        pass
    return violations


def _check_no_new_global_mutation() -> list[dict]:
    """Detect symbols that suggest global state mutation."""
    violations = []
    try:
        from .manifest import get_connection
        conn = get_connection()
        try:
            cur = conn.execute(
                """SELECT s.name, f.file_path
                   FROM symbols s JOIN files f ON s.file_id = f.id
                   WHERE (s.name LIKE '%global%' OR s.name LIKE 'GLOBAL%')
                     AND s.kind = 'variable'
                   LIMIT 10"""
            )
            for name, file_path in cur.fetchall():
                violations.append({
                    'constraint': 'no_new_global_mutation',
                    'symbol': name,
                    'file': file_path,
                    'detail': 'Global mutable variable detected',
                })
        finally:
            conn.close()
    except Exception:
        pass
    return violations


def _check_no_dynamic_eval() -> list[dict]:
    """Detect symbols suggesting dynamic code execution."""
    violations = []
    try:
        from .manifest import get_connection
        conn = get_connection()
        try:
            cur = conn.execute(
                """SELECT s.name, f.file_path
                   FROM symbols s JOIN files f ON s.file_id = f.id
                   WHERE s.name IN ('eval', 'exec', '__import__',
                                    'compile', 'execfile')
                      OR s.name LIKE '%eval%'
                      OR s.name LIKE '%exec%'
                   LIMIT 10"""
            )
            for name, file_path in cur.fetchall():
                violations.append({
                    'constraint': 'no_dynamic_eval',
                    'symbol': name,
                    'file': file_path,
                    'detail': 'Dynamic code execution detected',
                })
        finally:
            conn.close()
    except Exception:
        pass
    return violations


def _check_domain_dependency_acyclic() -> list[dict]:
    """Verify domain dependency graph has no cycles."""
    violations = []
    try:
        from .manifest import get_connection
        conn = get_connection()
        try:
            cur = conn.execute(
                """WITH RECURSIVE domain_chain AS (
                    SELECT d1.name AS src, d2.name AS dst, 1 AS depth
                    FROM call_edges ce
                    JOIN symbols s1 ON ce.caller_id = s1.id
                    JOIN files f1 ON s1.file_id = f1.id
                    JOIN file_domains fd1 ON f1.id = fd1.file_id
                    JOIN domains d1 ON fd1.domain_id = d1.id
                    JOIN symbols s2 ON s2.name = ce.callee_name
                    JOIN files f2 ON s2.file_id = f2.id
                    JOIN file_domains fd2 ON f2.id = fd2.file_id
                    JOIN domains d2 ON fd2.domain_id = d2.id
                    WHERE d1.name != d2.name
                    UNION ALL
                    SELECT dc.src, d3.name, dc.depth + 1
                    FROM domain_chain dc
                    JOIN call_edges ce ON ce.callee_name IN (
                        SELECT s.name FROM symbols s
                        JOIN file_domains fd ON s.file_id = fd.file_id
                        JOIN domains d ON fd.domain_id = d.id
                        WHERE d.name = dc.dst
                    )
                    JOIN symbols s_caller ON ce.caller_id = s_caller.id
                    JOIN files f_caller ON s_caller.file_id = f_caller.id
                    JOIN file_domains fd_caller ON f_caller.id = fd_caller.file_id
                    JOIN domains d3 ON fd_caller.domain_id = d3.id
                    WHERE dc.depth < 10 AND d3.name != dc.dst
                )
                SELECT src, MIN(depth) FROM domain_chain
                WHERE src = dst GROUP BY src
                LIMIT 10"""
            )
            for domain, depth in cur.fetchall():
                violations.append({
                    'constraint': 'domain_dependency_acyclic',
                    'domain': domain,
                    'depth': depth,
                    'detail': f'Circular dependency in domain {domain}',
                })
        finally:
            conn.close()
    except Exception:
        pass
    return violations


def _check_security_boundary_respected() -> list[dict]:
    """Verify security boundaries between domains are not violated."""
    violations = []
    try:
        from .manifest import get_connection
        conn = get_connection()
        try:
            cur = conn.execute(
                """SELECT ce.callee_name AS symbol,
                          d_caller.name AS from_domain,
                          d_callee.name AS to_domain
                   FROM call_edges ce
                   JOIN symbols s_caller ON ce.caller_id = s_caller.id
                   JOIN files f_caller ON s_caller.file_id = f_caller.id
                   JOIN file_domains fd_caller ON f_caller.id = fd_caller.file_id
                   JOIN domains d_caller ON fd_caller.domain_id = d_caller.id
                   JOIN symbols s_callee ON s_callee.name = ce.callee_name
                   JOIN files f_callee ON s_callee.file_id = f_callee.id
                   JOIN file_domains fd_callee ON f_callee.id = fd_callee.file_id
                   JOIN domains d_callee ON fd_callee.domain_id = d_callee.id
                   WHERE d_callee.security_boundary = 1
                     AND d_caller.security_boundary = 0
                     AND d_caller.name != d_callee.name
                   LIMIT 10"""
            )
            for symbol, from_domain, to_domain in cur.fetchall():
                violations.append({
                    'constraint': 'security_boundary_respected',
                    'symbol': symbol,
                    'crossing': f'{from_domain} → {to_domain}',
                    'detail': f'Untrusted domain {from_domain} calling into security boundary {to_domain}',
                })
        finally:
            conn.close()
    except Exception:
        pass
    return violations


def _check_max_call_depth(max_depth: int = 7) -> list[dict]:
    """Detect call chains exceeding maximum recommended depth."""
    violations = []
    try:
        from .manifest import get_connection
        conn = get_connection()
        try:
            cur = conn.execute(
                """WITH RECURSIVE depth_check AS (
                    SELECT s.name AS root, ce.callee_name, 1 AS depth
                    FROM call_edges ce
                    JOIN symbols s ON ce.caller_id = s.id
                    UNION ALL
                    SELECT dc.root, ce2.callee_name, dc.depth + 1
                    FROM depth_check dc
                    JOIN call_edges ce2 ON dc.callee_name = (
                        SELECT name FROM symbols WHERE id = ce2.caller_id
                    )
                    WHERE dc.depth < ?
                )
                SELECT root, MAX(depth) FROM depth_check
                GROUP BY root HAVING MAX(depth) > ?
                ORDER BY MAX(depth) DESC LIMIT 10""",
                (max_depth + 10, max_depth)
            )
            for root, depth in cur.fetchall():
                violations.append({
                    'constraint': 'max_call_depth',
                    'root_symbol': root,
                    'max_depth': depth,
                    'threshold': max_depth,
                    'detail': f'Call chain depth {depth} exceeds max {max_depth}',
                })
        finally:
            conn.close()
    except Exception:
        pass
    return violations


# Registry of all built-in constraint checkers
CONSTRAINT_CHECKERS = {
    'no_circular_imports': _check_no_circular_imports,
    'no_unbounded_memory_growth': _check_no_unbounded_memory_growth,
    'no_sync_io_on_hotpaths': _check_no_sync_io_on_hotpaths,
    'no_unsafe_sql_concatenation': _check_no_unsafe_sql_concatenation,
    'no_new_global_mutation': _check_no_new_global_mutation,
    'no_dynamic_eval': _check_no_dynamic_eval,
    'domain_dependency_acyclic': _check_domain_dependency_acyclic,
    'security_boundary_respected': _check_security_boundary_respected,
    'max_call_depth': _check_max_call_depth,
}

BUILTIN_FORMAL_CONSTRAINTS = [
    FormalConstraint('no_circular_imports', 'No circular import chains', 'must_not'),
    FormalConstraint('no_unbounded_memory_growth', 'No unbounded collections', 'must_not', severity='warning'),
    FormalConstraint('no_sync_io_on_hotpaths', 'No sync I/O in high-churn files', 'must_not', severity='warning'),
    FormalConstraint('no_unsafe_sql_concatenation', 'No unsafe SQL string building', 'must_not'),
    FormalConstraint('no_new_global_mutation', 'No new global mutable state', 'must_not', severity='warning'),
    FormalConstraint('no_dynamic_eval', 'No dynamic code execution', 'must_not'),
    FormalConstraint('domain_dependency_acyclic', 'Domain dependency graph must be acyclic', 'must'),
    FormalConstraint('security_boundary_respected', 'Security boundaries must be respected', 'must'),
    FormalConstraint('max_call_depth', 'Call chain depth must not exceed threshold', 'must', severity='warning'),
]


def check_formal_constraints(file_paths: list[str] | None = None) -> dict:
    """Run all enabled formal constraint checks.

    Returns: {block, errors, warnings, violations, passed}
    """
    result = {
        'block': False,
        'errors': [],
        'warnings': [],
        'violations': [],
    }

    for constraint in BUILTIN_FORMAL_CONSTRAINTS:
        if not constraint.enabled:
            continue
        checker = CONSTRAINT_CHECKERS.get(constraint.name)
        if checker is None:
            continue
        try:
            violations = checker()
            if violations:
                for v in violations:
                    entry = {
                        'constraint': constraint.name,
                        'description': constraint.description,
                        'detail': v.get('detail', str(v)),
                        'severity': constraint.severity,
                    }
                    result['violations'].append(entry)
                    if constraint.severity == 'error':
                        result['errors'].append(
                            f"CONSTRAINT: {constraint.name} — {v.get('detail', '')}"
                        )
                    else:
                        result['warnings'].append(
                            f"Constraint warning: {constraint.name} — {v.get('detail', '')}"
                        )
                if constraint.severity == 'error':
                    result['block'] = True
        except Exception:
            pass

    return result


def get_formal_summary() -> dict:
    """Return a summary of formal constraint state."""
    result = check_formal_constraints()
    return {
        'constraints_checked': len(BUILTIN_FORMAL_CONSTRAINTS),
        'violations': len(result['violations']),
        'errors': len(result['errors']),
        'warnings': len(result['warnings']),
        'block': result['block'],
    }
