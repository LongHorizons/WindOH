"""SimHash-based code duplicate detection.

Normalizes source code, computes SimHash fingerprints, and stores
similarity groups in the SQLite database for duplicate detection.
"""

from __future__ import annotations

import hashlib
import re
from typing import Iterator

from .manifest import get_connection


def _tokenize(source: str, n: int = 3) -> list[str]:
    """Tokenize source code into n-grams for SimHash."""
    tokens = re.findall(r'[a-zA-Z_]\w+|\d+|[^\s]', source)
    return [''.join(tokens[i:i + n]) for i in range(len(tokens) - n + 1)]


def _simhash(tokens: list[str]) -> str:
    """Compute a 64-bit SimHash fingerprint from tokens.

    Returns a 16-character hex string.
    """
    weights = [0] * 64
    for token in tokens:
        h = int(hashlib.md5(token.encode()).hexdigest()[:16], 16)
        for i in range(64):
            if h & (1 << i):
                weights[i] += 1
            else:
                weights[i] -= 1

    fingerprint = 0
    for i in range(64):
        if weights[i] > 0:
            fingerprint |= (1 << i)

    return f"{fingerprint:016x}"


def normalize_code(source: str) -> str:
    """Normalize source code for comparison.

    Strips comments, normalizes whitespace, and replaces identifiers
    with placeholders to focus on structural similarity.
    """
    # Remove single-line comments (// and #)
    source = re.sub(r'//[^\n]*', '', source)
    source = re.sub(r'#[^\n]*', '', source)

    # Remove multi-line comments (/* */)
    source = re.sub(r'/\*.*?\*/', '', source, flags=re.DOTALL)

    # Remove string literals
    source = re.sub(r'"[^"]*"', '""', source)
    source = re.sub(r"'[^']*'", "''", source)
    source = re.sub(r'`[^`]*`', '``', source)

    # Normalize whitespace
    source = re.sub(r'\s+', ' ', source).strip()

    # Replace identifiers with placeholders (preserve keywords)
    keywords = {
        'def', 'class', 'return', 'if', 'else', 'elif', 'for', 'while',
        'import', 'from', 'async', 'await', 'yield', 'raise', 'try',
        'except', 'finally', 'with', 'as', 'lambda', 'function', 'const',
        'let', 'var', 'export', 'default', 'fn', 'pub', 'func', 'struct',
        'impl', 'type', 'interface', 'enum', 'match', 'case', 'switch',
    }
    identifier_pattern = re.compile(r'\b([a-zA-Z_]\w*)\b')

    counter = 0
    replacements = {}

    def replace_ident(m):
        nonlocal counter
        word = m.group(1)
        if word in keywords or len(word) <= 2:
            return word
        if word not in replacements:
            replacements[word] = f"ID{counter}"
            counter += 1
        return replacements[word]

    source = identifier_pattern.sub(replace_ident, source)
    return source


def compute_similarity(symbol_name: str, file_path: str, code: str,
                        language: str, start_line: int = 0,
                        end_line: int = 0) -> str:
    """Compute and store a SimHash for a code block.

    Returns the simhash hex string.
    """
    normalized = normalize_code(code)
    tokens = _tokenize(normalized)
    simhash = _simhash(tokens)

    conn = get_connection()
    try:
        conn.execute(
            """INSERT OR REPLACE INTO similarity_groups
               (simhash, file_path, symbol_name, start_line, end_line,
                normalized_code, language)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (simhash, file_path, symbol_name, start_line, end_line,
             normalized[:1000], language)
        )
        conn.commit()
    finally:
        conn.close()

    return simhash


def find_similar(simhash: str, hamming_threshold: int = 8,
                  limit: int = 20) -> list[dict]:
    """Find code blocks similar to the given simhash.

    Args:
        simhash: The simhash to compare against.
        hamming_threshold: Maximum Hamming distance for "similar" (default 8).
        limit: Max results to return.
    """
    conn = get_connection()
    try:
        cur = conn.execute(
            "SELECT simhash, file_path, symbol_name, start_line, end_line, language "
            "FROM similarity_groups LIMIT 5000"
        )
        results = []
        target_int = int(simhash, 16)

        for row in cur.fetchall():
            other_hash, file_path, sym_name, start, end, lang = row
            other_int = int(other_hash, 16)
            distance = (target_int ^ other_int).bit_count()

            if distance > 0 and distance <= hamming_threshold:
                results.append({
                    'file_path': file_path,
                    'symbol_name': sym_name,
                    'start_line': start,
                    'end_line': end,
                    'language': lang,
                    'hamming_distance': distance,
                })

        results.sort(key=lambda x: x['hamming_distance'])
        return results[:limit]
    finally:
        conn.close()


def check_duplicate_risk(name: str) -> list[dict]:
    """Check if a symbol name already exists in the index.

    Returns a list of existing symbols with the same name.
    """
    conn = get_connection()
    try:
        cur = conn.execute(
            """SELECT s.name, s.kind, f.file_path, s.start_line
               FROM symbols s JOIN files f ON s.file_id = f.id
               WHERE s.name = ?
               ORDER BY f.file_path""",
            (name,)
        )
        return [
            {"name": r[0], "kind": r[1], "file": r[2], "line": r[3]}
            for r in cur.fetchall()
        ]
    finally:
        conn.close()


def run_similarity_pass(limit: int = 200) -> int:
    """Batch compute simhashes for indexed symbols. Called from session start.

    Reads symbol definitions from the DB, extracts source code, computes simhashes.
    Works even when end_line is not reliably set (regex-fallback languages like Rust).
    Returns the number of simhashes stored.
    """
    import os
    from .manifest import get_connection as _get_conn
    from . import PROJECT_DIR

    conn = _get_conn()
    try:
        cur = conn.execute(
            """SELECT s.name, s.kind, f.file_path, s.start_line, s.end_line, f.language
               FROM symbols s JOIN files f ON s.file_id = f.id
               WHERE s.kind IN ('function', 'method', 'closure', 'struct', 'trait', 'impl')
               ORDER BY (s.end_line - s.start_line) DESC
               LIMIT ?""",
            (limit,)
        )
        symbols = list(cur.fetchall())
    finally:
        conn.close()

    count = 0
    seen_files = {}
    for name, kind, file_path, start_line, end_line, language in symbols:
        try:
            if file_path not in seen_files:
                full_path = os.path.join(PROJECT_DIR, file_path)
                if not os.path.exists(full_path):
                    seen_files[file_path] = None
                    continue
                with open(full_path, 'r', encoding='utf-8', errors='replace') as fh:
                    seen_files[file_path] = fh.readlines()
            lines = seen_files.get(file_path)
            if not lines:
                continue

            # If end_line is unreliable (== start_line or 0), estimate
            # by taking up to 50 lines or until a blank line after logical block end
            if end_line <= start_line:
                end_line = min(start_line + 50, len(lines))
                # Try to find a better boundary: next fn/struct/trait/pub at same indent
                for i in range(start_line, end_line):
                    stripped = lines[i].rstrip('\n\r') if i < len(lines) else ''
                    if i > start_line and stripped and not stripped[0].isspace():
                        if re.match(
                            r'(pub(\s+\(crate\))?\s+)?(fn|struct|enum|trait|impl|mod|macro_rules!)\s',
                            stripped
                        ):
                            end_line = i
                            break

            code_block = ''.join(lines[start_line - 1:end_line])
            if len(code_block) < 30:
                continue
            compute_similarity(name, file_path, code_block, language,
                               start_line, end_line)
            count += 1
        except Exception:
            continue

    return count


def get_all_duplicates(hamming_threshold: int = 6,
                        min_confidence: float = 0.8) -> list[dict]:
    """Find all duplicate code pairs in the index.

    Returns pairs of (file1, symbol1, file2, symbol2, distance).
    """
    conn = get_connection()
    try:
        cur = conn.execute(
            "SELECT simhash, file_path, symbol_name, start_line "
            "FROM similarity_groups ORDER BY simhash"
        )
        all_entries = list(cur.fetchall())

        # Group by simhash prefix for efficiency (same first 4 hex chars)
        groups = {}
        for simhash, file_path, sym_name, start_line in all_entries:
            prefix = simhash[:4]
            if prefix not in groups:
                groups[prefix] = []
            groups[prefix].append((simhash, file_path, sym_name, start_line))

        duplicates = []
        for prefix, entries in groups.items():
            for i in range(len(entries)):
                for j in range(i + 1, len(entries)):
                    hash1, fp1, sn1, sl1 = entries[i]
                    hash2, fp2, sn2, sl2 = entries[j]
                    if fp1 == fp2:
                        continue
                    distance = (int(hash1, 16) ^ int(hash2, 16)).bit_count()
                    if distance <= hamming_threshold:
                        duplicates.append({
                            'file1': fp1, 'symbol1': sn1, 'line1': sl1,
                            'file2': fp2, 'symbol2': sn2, 'line2': sl2,
                            'hamming_distance': distance,
                        })

        duplicates.sort(key=lambda x: x['hamming_distance'])
        return duplicates
    finally:
        conn.close()
