"""Repository Immune System — behavioral baseline + anomaly detection + quarantine.

Establishes a "known-good" baseline of the indexed graph, then monitors
for deviations that could indicate architectural degradation, malicious
refactoring patterns, or unexpected structural changes.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field


@dataclass
class AnomalySignal:
    signal_type: str
    severity: str = 'medium'
    affected_scope: list[str] = field(default_factory=list)
    description: str = ''
    baseline: str = ''
    current: str = ''


class ImmuneSystem:
    """Active defense through behavioral baseline comparison.

    SessionStart: establish_baseline()
    PreToolUse: behavioral_intrusion_detection()
    PostToolUse: update_baseline() (incremental)
    """

    def establish_baseline(self, label: str = 'auto') -> dict:
        """Capture current graph state as a known-good baseline."""
        from .manifest import get_connection
        conn = get_connection()
        try:
            # Capture key metrics that define "normal"
            file_count = conn.execute("SELECT COUNT(*) FROM files").fetchone()[0]
            sym_count = conn.execute("SELECT COUNT(*) FROM symbols").fetchone()[0]
            edge_count = conn.execute("SELECT COUNT(*) FROM call_edges").fetchone()[0]
            domain_count = conn.execute("SELECT COUNT(*) FROM domains").fetchone()[0]

            # Capture security-sensitive symbol count
            sec_count = conn.execute(
                "SELECT COUNT(*) FROM symbols WHERE security_sensitive = 1"
            ).fetchone()[0]

            # Capture drift distribution
            avg_drift = conn.execute(
                "SELECT AVG(architectural_drift_score) FROM files"
            ).fetchone()[0] or 0.0

            baseline = {
                'files': file_count,
                'symbols': sym_count,
                'edges': edge_count,
                'domains': domain_count,
                'security_sensitive_symbols': sec_count,
                'average_drift': round(avg_drift, 4),
                'label': label,
            }

            conn.execute(
                """INSERT INTO immune_baselines (label, baseline_data)
                   VALUES (?, ?)""",
                (label, json.dumps(baseline))
            )
            conn.commit()
            return baseline
        finally:
            conn.close()

    def detect_anomalies(self) -> list[AnomalySignal]:
        """Compare current state vs most recent baseline, flag deviations."""
        signals: list[AnomalySignal] = []

        from .manifest import get_connection
        conn = get_connection()
        try:
            # Get most recent baseline
            cur = conn.execute(
                "SELECT baseline_data FROM immune_baselines ORDER BY id DESC LIMIT 1"
            )
            row = cur.fetchone()
            if row is None:
                return signals

            baseline = json.loads(row[0])

            # Compare with current state
            file_count = conn.execute("SELECT COUNT(*) FROM files").fetchone()[0]
            sym_count = conn.execute("SELECT COUNT(*) FROM symbols").fetchone()[0]
            edge_count = conn.execute("SELECT COUNT(*) FROM call_edges").fetchone()[0]
            sec_count = conn.execute(
                "SELECT COUNT(*) FROM symbols WHERE security_sensitive = 1"
            ).fetchone()[0]
            avg_drift = conn.execute(
                "SELECT AVG(architectural_drift_score) FROM files"
            ).fetchone()[0] or 0.0
        finally:
            conn.close()

        # Check for significant deviations
        if baseline.get('files', 0) > 0:
            file_change = abs(file_count - baseline['files']) / baseline['files']
            if file_change > 0.2:
                signals.append(AnomalySignal(
                    signal_type='file_count_deviation',
                    severity='medium',
                    description=f"File count changed {file_change:.1%} from baseline "
                               f"({baseline['files']} → {file_count})",
                    baseline=str(baseline['files']),
                    current=str(file_count),
                ))

        if baseline.get('symbols', 0) > 0:
            sym_change = abs(sym_count - baseline['symbols']) / baseline['symbols']
            if sym_change > 0.3:
                signals.append(AnomalySignal(
                    signal_type='symbol_count_deviation',
                    severity='medium',
                    description=f"Symbol count changed {sym_change:.1%} "
                               f"({baseline['symbols']} → {sym_count})",
                    baseline=str(baseline['symbols']),
                    current=str(sym_count),
                ))

        if baseline.get('security_sensitive_symbols', 0) > 0:
            if sec_count > baseline['security_sensitive_symbols'] * 1.5:
                signals.append(AnomalySignal(
                    signal_type='security_surface_expansion',
                    severity='high',
                    description=f"Security-sensitive symbols increased from "
                               f"{baseline['security_sensitive_symbols']} to {sec_count}",
                    baseline=str(baseline['security_sensitive_symbols']),
                    current=str(sec_count),
                ))

        if baseline.get('average_drift', 0) > 0:
            drift_change = avg_drift - baseline['average_drift']
            if drift_change > 0.1:
                signals.append(AnomalySignal(
                    signal_type='drift_acceleration',
                    severity='medium',
                    description=f"Average drift increased by {drift_change:.3f}",
                    baseline=str(baseline['average_drift']),
                    current=str(round(avg_drift, 4)),
                ))

        # Persist alerts
        conn = get_connection()
        try:
            for sig in signals:
                conn.execute(
                    """INSERT INTO immune_alerts
                       (signal_type, severity, affected_scope, description,
                        baseline_value, current_value)
                       VALUES (?, ?, ?, ?, ?, ?)""",
                    (sig.signal_type, sig.severity,
                     json.dumps(sig.affected_scope),
                     sig.description, sig.baseline, sig.current)
                )
            conn.commit()
        finally:
            conn.close()

        return signals

    def quarantine_file(self, file_path: str, reason: str) -> bool:
        """Mark a file for quarantine review.

        Quarantined files trigger high-severity immune alerts.
        Does NOT modify the actual file on disk.
        """
        conn = get_connection()
        try:
            conn.execute(
                """INSERT INTO immune_alerts
                   (signal_type, severity, affected_scope, description)
                   VALUES (?, ?, ?, ?)""",
                ('quarantine', 'high', json.dumps([file_path]), reason)
            )
            conn.commit()
            return True
        finally:
            conn.close()

    def behavioral_intrusion_detection(self) -> list[dict]:
        """Detect malicious-looking refactoring patterns.

        Flags patterns like:
        - Sudden removal of security-sensitive symbols
        - Mass deletion of test files
        - Rapid domain restructuring
        """
        alerts = []
        try:
            from .manifest import get_connection
            conn = get_connection()
            try:
                # Check for mass symbol changes in a short period
                cur = conn.execute(
                    """SELECT file_path, COUNT(*) AS changes
                       FROM temporal_change_log
                       WHERE changed_at > datetime('now', '-1 day')
                       GROUP BY file_path
                       HAVING COUNT(*) > 10
                       ORDER BY COUNT(*) DESC
                       LIMIT 10"""
                )
                for file_path, count in cur.fetchall():
                    alerts.append({
                        'type': 'rapid_churn',
                        'severity': 'medium',
                        'file': file_path,
                        'changes_24h': count,
                        'detail': f"File modified {count} times in 24h",
                    })

                # Check for deleted files with security-sensitive symbols
                # (files in temporal_change_log but not in files table)
                cur2 = conn.execute(
                    """SELECT tcl.file_path, COUNT(*) AS changes
                       FROM temporal_change_log tcl
                       WHERE tcl.file_path NOT IN (SELECT file_path FROM files)
                         AND tcl.changed_at > datetime('now', '-7 days')
                       GROUP BY tcl.file_path
                       LIMIT 20"""
                )
                for file_path, count in cur2.fetchall():
                    alerts.append({
                        'type': 'potential_deletion',
                        'severity': 'low',
                        'file': file_path,
                        'changes_7d': count,
                        'detail': f"File may have been deleted (not in current index)",
                    })
            finally:
                conn.close()
        except Exception:
            pass

        return alerts


def check_immune_system() -> dict:
    """Convenience entry point for hook integration.

    Returns a summary of immune system state.
    """
    system = ImmuneSystem()
    signals = system.detect_anomalies()
    return {
        'anomalies': len(signals),
        'high_severity': sum(1 for s in signals if s.severity == 'high'),
        'medium_severity': sum(1 for s in signals if s.severity == 'medium'),
        'signals': [
            {'type': s.signal_type, 'severity': s.severity,
             'description': s.description}
            for s in signals[:10]
        ],
    }
