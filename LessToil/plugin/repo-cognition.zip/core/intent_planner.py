"""Intent-to-topology planning.

Maps user intents ("build", "create", "implement") to architectural
constraints and execution plans. Generates bounded optimization rather
than unconstrained autocomplete.

Intent → ConstraintSet (target domain, applicable invariants, policies,
security boundaries) → ExecutionPlan
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .manifest import get_connection


@dataclass
class ConstraintSet:
    target_domain: str = ''
    applicable_invariants: list[dict] = field(default_factory=list)
    applicable_policies: list[dict] = field(default_factory=list)
    security_boundaries: list[str] = field(default_factory=list)
    forbidden_patterns: list[str] = field(default_factory=list)
    requires_tests: bool = False
    max_complexity: int = 80
    max_dependencies: int = 20


@dataclass
class ExecutionPlan:
    intent: str
    target_domain: str
    constraints: ConstraintSet
    suggested_files: list[dict] = field(default_factory=list)
    affected_domains: list[str] = field(default_factory=list)
    risk_level: str = 'unknown'
    estimated_complexity: str = 'unknown'
    warnings: list[str] = field(default_factory=list)


# Intent → domain mapping keywords
INTENT_DOMAIN_KEYWORDS = {
    'auth': ['login', 'logout', 'register', 'authenticate', 'authorize',
              'permission', 'role', 'token', 'session', 'jwt', 'oauth'],
    'ui': ['component', 'page', 'view', 'render', 'display', 'layout',
            'button', 'form', 'modal', 'dialog', 'style', 'css'],
    'data': ['database', 'query', 'migrate', 'schema', 'model', 'entity',
              'repository', 'dao', 'orm', 'table', 'column', 'index'],
    'api': ['endpoint', 'route', 'controller', 'handler', 'middleware',
             'request', 'response', 'rest', 'graphql', 'rpc'],
    'core': ['business', 'logic', 'service', 'domain', 'rule', 'policy',
              'workflow', 'process', 'orchestrate'],
    'infra': ['config', 'deploy', 'build', 'ci', 'cd', 'pipeline',
               'docker', 'kubernetes', 'monitor', 'log', 'cache'],
}


def infer_target_domain(intent: str) -> str:
    """Infer the target architectural domain from a user intent string."""
    intent_lower = intent.lower()
    scores = {}
    for domain, keywords in INTENT_DOMAIN_KEYWORDS.items():
        score = sum(1 for kw in keywords if kw in intent_lower)
        if score > 0:
            scores[domain] = score

    if not scores:
        return 'core'

    return max(scores, key=scores.get)


def get_domain_invariants(domain_name: str) -> list[dict]:
    """Get invariants relevant to the given domain."""
    conn = get_connection()
    try:
        cur = conn.execute(
            """SELECT name, description, severity
               FROM invariants WHERE enabled = 1
                 AND (query LIKE ? OR description LIKE ?)""",
            (f'%{domain_name}%', f'%{domain_name}%')
        )
        return [
            {'name': r[0], 'description': r[1], 'severity': r[2]}
            for r in cur.fetchall()
        ]
    finally:
        conn.close()


def get_domain_policies(domain_name: str) -> list[dict]:
    """Get policies relevant to the given domain."""
    conn = get_connection()
    try:
        cur = conn.execute(
            "SELECT name, category, threshold_value, severity FROM policies WHERE enabled = 1"
        )
        return [
            {'name': r[0], 'category': r[1], 'threshold_value': r[2], 'severity': r[3]}
            for r in cur.fetchall()
        ]
    finally:
        conn.close()


def get_security_boundaries_in_domain(domain_name: str) -> list[str]:
    """Find security boundaries in or adjacent to the given domain."""
    conn = get_connection()
    try:
        cur = conn.execute(
            "SELECT name FROM domains WHERE security_boundary = 1 AND name = ?",
            (domain_name,)
        )
        return [r[0] for r in cur.fetchall()]
    finally:
        conn.close()


def get_suggested_files(domain_name: str, intent: str, limit: int = 5) -> list[dict]:
    """Suggest existing files in the target domain for modification."""
    conn = get_connection()
    try:
        # Try domain assignment
        cur = conn.execute(
            """SELECT f.file_path, f.language, f.line_count
               FROM files f
               JOIN file_domains fd ON f.id = fd.file_id
               JOIN domains d ON fd.domain_id = d.id
               WHERE d.name = ?
               ORDER BY f.line_count DESC
               LIMIT ?""",
            (domain_name, limit)
        )
        results = list(cur.fetchall())

        # Fallback: search by keywords from intent
        if not results:
            intent_words = [w.lower() for w in intent.split() if len(w) > 3]
            for word in intent_words:
                cur2 = conn.execute(
                    "SELECT file_path, language, line_count FROM files WHERE file_path LIKE ? LIMIT 3",
                    (f'%{word}%',)
                )
                results.extend(cur2.fetchall())
            results = results[:limit]

        return [
            {'file_path': r[0], 'language': r[1], 'line_count': r[2]}
            for r in results
        ]
    finally:
        conn.close()


def compute_required_constraints(intent: str) -> ConstraintSet:
    """Given an intent, compute the applicable constraint set."""
    domain = infer_target_domain(intent)

    constraints = ConstraintSet(
        target_domain=domain,
        applicable_invariants=get_domain_invariants(domain),
        applicable_policies=get_domain_policies(domain),
        security_boundaries=get_security_boundaries_in_domain(domain),
    )

    # Autodetect constraints from intent
    intent_lower = intent.lower()

    if any(w in intent_lower for w in ('security', 'auth', 'login', 'permission',
                                          'role', 'private', 'sensitive')):
        constraints.requires_tests = True
        constraints.forbidden_patterns.append('no_plaintext_secrets')

    if any(w in intent_lower for w in ('critical', 'important', 'core', 'essential')):
        constraints.max_complexity = 50  # stricter
        constraints.requires_tests = True

    if any(w in intent_lower for w in ('fix', 'bug', 'patch', 'hotfix')):
        constraints.forbidden_patterns.append('no_large_refactors')
        constraints.max_dependencies = 10

    return constraints


def generate_execution_plan(intent: str) -> ExecutionPlan:
    """Generate a bounded execution plan from a user intent.

    This is designed to be called by an agent/skill that provides
    natural language summarization of the plan.
    """
    constraints = compute_required_constraints(intent)
    domain = constraints.target_domain

    plan = ExecutionPlan(
        intent=intent,
        target_domain=domain,
        constraints=constraints,
        suggested_files=get_suggested_files(domain, intent),
    )

    # Determine affected domains
    domain_keywords = list(INTENT_DOMAIN_KEYWORDS.keys())
    plan.affected_domains = _find_affected_domains(intent, domain, domain_keywords)

    # Assess risk
    plan.risk_level = _assess_risk(constraints, plan)

    # Estimate complexity
    plan.estimated_complexity = _estimate_complexity(intent, plan)

    # Generate warnings
    plan.warnings = _generate_warnings(constraints, plan)

    return plan


def _find_affected_domains(intent: str, primary: str,
                            all_domains: list[str]) -> list[str]:
    """Find all domains potentially affected by the intent."""
    affected = [primary]
    intent_lower = intent.lower()

    for domain in all_domains:
        if domain != primary:
            keywords = INTENT_DOMAIN_KEYWORDS.get(domain, [])
            if any(kw in intent_lower for kw in keywords):
                affected.append(domain)

    return affected


def _assess_risk(constraints: ConstraintSet, plan: ExecutionPlan) -> str:
    """Assess the risk level of the execution plan."""
    risk_score = 0

    if constraints.requires_tests:
        risk_score += 1
    if constraints.security_boundaries:
        risk_score += 2
    if len(constraints.applicable_invariants) > 3:
        risk_score += 1
    if len(plan.affected_domains) > 2:
        risk_score += 1

    if risk_score >= 4:
        return 'high'
    elif risk_score >= 2:
        return 'medium'
    return 'low'


def _estimate_complexity(intent: str, plan: ExecutionPlan) -> str:
    """Estimate the complexity of the intended change."""
    intent_lower = intent.lower()
    score = 0

    # Heuristic based on intent words
    if any(w in intent_lower for w in ('refactor', 'rewrite', 'migrate', 'restructure')):
        score += 3
    if any(w in intent_lower for w in ('add', 'create', 'build', 'implement')):
        score += 1
    if any(w in intent_lower for w in ('fix', 'patch', 'update', 'change')):
        score += 0
    if len(plan.affected_domains) > 2:
        score += 2
    if len(plan.suggested_files) > 5:
        score += 1

    if score >= 4:
        return 'complex'
    elif score >= 2:
        return 'moderate'
    return 'simple'


def _generate_warnings(constraints: ConstraintSet, plan: ExecutionPlan) -> list[str]:
    """Generate advisory warnings for the execution plan."""
    warnings = []

    if constraints.security_boundaries:
        warnings.append(
            f"Security boundary involved: {', '.join(constraints.security_boundaries)}. "
            f"Changes must be reviewed for security implications."
        )

    if constraints.requires_tests:
        warnings.append("Tests are required for this change. Ensure test coverage.")

    if len(plan.affected_domains) > 2:
        warnings.append(
            f"Multiple domains affected: {', '.join(plan.affected_domains)}. "
            f"Coordinate changes carefully."
        )

    for inv in constraints.applicable_invariants:
        if inv.get('severity') == 'error':
            warnings.append(
                f"Invariant '{inv['name']}' applies: {inv.get('description', '')}"
            )

    if not plan.suggested_files:
        warnings.append(
            f"No existing files found in domain '{plan.target_domain}'. "
            f"New file creation may be needed."
        )

    return warnings
