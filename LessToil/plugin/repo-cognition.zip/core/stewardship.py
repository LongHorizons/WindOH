"""Autonomous architectural stewardship.

Proactive scan that identifies:
- Dead subsystems (unreferenced symbols/domains)
- Over-complex files
- High-churn hotspots
- Stale patterns
- Dangerous coupling
- Unowned critical paths

Produces ranked suggestion list with justification and estimated effort.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .manifest import get_connection


@dataclass
class StewardshipSuggestion:
    category: str
    title: str
    description: str
    file_path: str = ''
    severity: str = 'medium'
    estimated_effort: str = 'medium'
    justification: str = ''


def find_dead_subsystems() -> list[StewardshipSuggestion]:
    """Find domains with no incoming references (potentially dead code)."""
    conn = get_connection()
    try:
        cur = conn.execute(
            """SELECT d.name, d.description,
                      COUNT(DISTINCT f.id) AS file_count
               FROM domains d
               LEFT JOIN file_domains fd ON d.id = fd.domain_id
               LEFT JOIN files f ON fd.file_id = f.id
               GROUP BY d.id
               HAVING COUNT(DISTINCT f.id) = 0"""
        )
        return [
            StewardshipSuggestion(
                category='dead_subsystem',
                title=f'Empty domain: {r[0]}',
                description=f"Domain '{r[0]}' has no associated files. "
                            f"Consider removing or populating it.",
                file_path='',
                severity='low',
                estimated_effort='low',
                justification=f"Description: {r[1] or 'N/A'}",
            )
            for r in cur.fetchall()
        ]
    finally:
        conn.close()


def find_over_complex_files() -> list[StewardshipSuggestion]:
    """Find files that exceed complexity thresholds."""
    conn = get_connection()
    try:
        cur = conn.execute(
            """SELECT f.file_path, f.line_count, f.language,
                      COUNT(s.id) AS sym_count,
                      COUNT(DISTINCT ce.callee_name) AS dependencies
               FROM files f
               LEFT JOIN symbols s ON f.id = s.file_id
               LEFT JOIN call_edges ce ON s.id = ce.caller_id
               GROUP BY f.id
               HAVING f.line_count > 800 OR COUNT(s.id) > 25
               ORDER BY f.line_count DESC
               LIMIT 10"""
        )
        return [
            StewardshipSuggestion(
                category='over_complex',
                title=f'Complex file: {r[0]}',
                description=f"{r[1]} lines, {r[3]} symbols, "
                            f"{r[4]} dependencies in {r[2]}."
                            f" Consider splitting into smaller modules.",
                file_path=r[0],
                severity='high',
                estimated_effort='large',
                justification=f"Exceeds recommended thresholds "
                              f"(lines > 800 or symbols > 25)",
            )
            for r in cur.fetchall()
        ]
    finally:
        conn.close()


def find_high_churn_hotspots() -> list[StewardshipSuggestion]:
    """Find files with excessive change frequency and bug density."""
    conn = get_connection()
    try:
        cur = conn.execute(
            """SELECT file_path, total_commits, bug_fix_commits,
                      risk_score, instability
               FROM temporal_metrics
               WHERE risk_score >= 0.7
               ORDER BY risk_score DESC
               LIMIT 10"""
        )
        return [
            StewardshipSuggestion(
                category='high_churn',
                title=f'Hotspot: {r[0]}',
                description=f"Risk score {r[3]:.3f}, {r[1]} commits, "
                            f"{r[2]} bug-fixes, instability {r[4]:.3f}. "
                            f"Consider stabilization refactoring.",
                file_path=r[0],
                severity='high',
                estimated_effort='large',
                justification=f"High risk score ({r[3]:.3f}) from temporal analysis",
            )
            for r in cur.fetchall()
        ]
    except Exception:
        return []


def find_dangerous_coupling() -> list[StewardshipSuggestion]:
    """Find dangerously coupled files/symbols."""
    conn = get_connection()
    try:
        # Find symbols with excessive callers across domains
        cur = conn.execute(
            """SELECT s.name, s.kind, f.file_path,
                      COUNT(DISTINCT ce.caller_id) AS caller_count,
                      COUNT(DISTINCT f2.file_path) AS caller_files
               FROM symbols s
               JOIN files f ON s.file_id = f.id
               LEFT JOIN call_edges ce ON s.name = ce.callee_name
               LEFT JOIN symbols s2 ON ce.caller_id = s2.id
               LEFT JOIN files f2 ON s2.file_id = f2.id
               WHERE s.is_exported = 1
               GROUP BY s.id
               HAVING COUNT(DISTINCT f2.file_path) > 10
               ORDER BY caller_files DESC
               LIMIT 10"""
        )
        return [
            StewardshipSuggestion(
                category='dangerous_coupling',
                title=f'Over-coupled symbol: {r[0]}',
                description=f"`{r[0]}` ({r[1]}) in {r[2]} has {r[3]} callers "
                            f"across {r[4]} files. High coupling risk — "
                            f"consider abstraction layer.",
                file_path=r[2],
                severity='medium',
                estimated_effort='large',
                justification=f"{r[4]} files depend on this symbol",
            )
            for r in cur.fetchall()
        ]
    finally:
        conn.close()


def find_unowned_critical_paths() -> list[StewardshipSuggestion]:
    """Find security-sensitive symbols without clear ownership or tests."""
    conn = get_connection()
    try:
        cur = conn.execute(
            """SELECT s.name, s.kind, f.file_path
               FROM symbols s
               JOIN files f ON s.file_id = f.id
               WHERE s.security_sensitive = 1
                 AND s.name NOT IN (
                     SELECT ce.callee_name FROM call_edges ce
                     JOIN symbols s2 ON ce.caller_id = s2.id
                     JOIN files f2 ON s2.file_id = f2.id
                     WHERE f2.file_path LIKE '%test%'
                        OR f2.file_path LIKE '%spec%'
                        OR f2.file_path LIKE '%__tests__%'
                 )
               LIMIT 10"""
        )
        return [
            StewardshipSuggestion(
                category='unowned_critical',
                title=f'Unowned security symbol: {r[0]}',
                description=f"Security-sensitive `{r[0]}` ({r[1]}) in {r[2]} "
                            f"has no visible tests. Add test coverage.",
                file_path=r[2],
                severity='high',
                estimated_effort='medium',
                justification='Security-sensitive symbol lacks test coverage',
            )
            for r in cur.fetchall()
        ]
    finally:
        conn.close()


def find_stale_patterns() -> list[StewardshipSuggestion]:
    """Find stale patterns: heavily duplicated but rarely changed code."""
    conn = get_connection()
    try:
        cur = conn.execute(
            """SELECT sg.file_path, sg.symbol_name, COUNT(*) AS occurrences
               FROM similarity_groups sg
               GROUP BY sg.file_path, sg.symbol_name
               HAVING COUNT(*) > 1
               ORDER BY COUNT(*) DESC
               LIMIT 10"""
        )
        return [
            StewardshipSuggestion(
                category='stale_pattern',
                title=f'Duplicated code: {r[1]}',
                description=f"`{r[1]}` appears {r[2]} times (including in {r[0]}). "
                            f"Consider extracting to shared module.",
                file_path=r[0],
                severity='medium',
                estimated_effort='medium',
                justification=f"{r[2]} duplicate occurrences found",
            )
            for r in cur.fetchall()
        ]
    finally:
        conn.close()


def run_full_stewardship_scan() -> list[StewardshipSuggestion]:
    """Run all stewardship scans and return ranked suggestions."""
    all_suggestions = []

    all_suggestions.extend(find_dead_subsystems())
    all_suggestions.extend(find_over_complex_files())
    all_suggestions.extend(find_high_churn_hotspots())
    all_suggestions.extend(find_dangerous_coupling())
    all_suggestions.extend(find_unowned_critical_paths())
    all_suggestions.extend(find_stale_patterns())

    # Sort by severity
    severity_order = {'high': 0, 'medium': 1, 'low': 2}
    all_suggestions.sort(key=lambda s: severity_order.get(s.severity, 1))

    return all_suggestions


def persist_suggestions(suggestions: list[StewardshipSuggestion]) -> int:
    """Persist stewardship suggestions to the database. Returns count stored."""
    conn = get_connection()
    try:
        count = 0
        for s in suggestions:
            conn.execute(
                """INSERT INTO stewardship_suggestions
                   (category, title, description, file_path, severity,
                    estimated_effort, justification, detected_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))""",
                (s.category, s.title, s.description, s.file_path,
                 s.severity, s.estimated_effort, s.justification)
            )
            count += 1
        conn.commit()
        return count
    finally:
        conn.close()


def get_top_suggestions(limit: int = 10) -> list[dict]:
    """Get top stewardship suggestions as serializable dicts."""
    suggestions = run_full_stewardship_scan()
    return [
        {
            'category': s.category,
            'title': s.title,
            'description': s.description,
            'file_path': s.file_path,
            'severity': s.severity,
            'estimated_effort': s.estimated_effort,
            'justification': s.justification,
        }
        for s in suggestions[:limit]
    ]


def get_stewardship_summary() -> dict:
    """Return a summary of stewardship findings."""
    suggestions = run_full_stewardship_scan()
    by_category = {}
    by_severity = {'high': 0, 'medium': 0, 'low': 0}

    for s in suggestions:
        by_category[s.category] = by_category.get(s.category, 0) + 1
        by_severity[s.severity] += 1

    return {
        'total_suggestions': len(suggestions),
        'high_severity': by_severity['high'],
        'medium_severity': by_severity['medium'],
        'low_severity': by_severity['low'],
        'by_category': by_category,
        'top_suggestions': get_top_suggestions(5),
    }
