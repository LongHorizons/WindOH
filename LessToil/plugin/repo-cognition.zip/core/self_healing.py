"""Self-Healing Loop — Detect → Propose → Validate → Repair.

Aggregates anomalies from drift_detection, confidence drops, invariant
violations, and coupling surges. Generates repair proposals, validates
them via simulation before execution, and produces a ranked repair plan.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Anomaly:
    anomaly_type: str
    target: str
    detected_by: str
    severity: str = 'medium'
    description: str = ''
    evidence: list[dict] = field(default_factory=list)


@dataclass
class RepairProposal:
    anomaly: Anomaly
    proposed_action: str
    estimated_effort: str = 'medium'
    risk_level: str = 'low'
    validation_checks: list[str] = field(default_factory=list)
    rollback_plan: str = ''


class SelfHealingLoop:
    """Detect → Propose → Validate → Repair cycle.

    Execution (the actual code change) is deferred to the agent.
    This loop surfaces the highest-value repairs for human or agent action.
    """

    def detect(self) -> list[Anomaly]:
        """Aggregate anomalies from all detection subsystems."""
        anomalies: list[Anomaly] = []

        # 1. Drift detection
        try:
            from .drift_detection import get_drift_summary, detect_god_objects
            drift = get_drift_summary()
            if drift.get('high_drift_files', 0) > 0:
                anomalies.append(Anomaly(
                    anomaly_type='architectural_drift',
                    target=f"{drift['high_drift_files']} files",
                    detected_by='drift_detection',
                    severity='medium' if drift['high_drift_files'] < 10 else 'high',
                    description=f"Average drift: {drift.get('average_drift', 0):.3f}",
                    evidence=[drift],
                ))
            god_objects = detect_god_objects()
            for go in god_objects[:5]:
                anomalies.append(Anomaly(
                    anomaly_type='god_object',
                    target=go['file_path'],
                    detected_by='drift_detection',
                    severity='medium',
                    description=f"{go['line_count']} lines, {go['symbol_count']} symbols",
                    evidence=[go],
                ))
        except Exception:
            pass

        # 2. Low confidence symbols (confidence drops)
        try:
            from .confidence import get_low_confidence_symbols
            low_syms = get_low_confidence_symbols(10)
            for ls in low_syms:
                anomalies.append(Anomaly(
                    anomaly_type='low_confidence',
                    target=f"{ls['name']} ({ls['kind']}) in {ls['file']}",
                    detected_by='confidence',
                    severity='low',
                    description=f"Confidence: {ls['confidence']:.2f}",
                    evidence=[ls],
                ))
        except Exception:
            pass

        # 3. Unresolved invariant violations
        try:
            from .manifest import get_connection
            conn = get_connection()
            try:
                cur = conn.execute(
                    """SELECT i.name, iv.file_path, iv.detail
                       FROM invariant_violations iv
                       JOIN invariants i ON iv.invariant_id = i.id
                       WHERE iv.resolved_at IS NULL
                       LIMIT 20"""
                )
                for inv_name, fp, detail in cur.fetchall():
                    anomalies.append(Anomaly(
                        anomaly_type='invariant_violation',
                        target=fp or 'unknown',
                        detected_by='governance',
                        severity='high',
                        description=f"Invariant '{inv_name}': {detail or ''}",
                    ))
            finally:
                conn.close()
        except Exception:
            pass

        # 4. High risk temporal hotspots
        try:
            from .temporal import get_riskiest_files
            risky = get_riskiest_files(5)
            for r in risky:
                if r.get('risk_score', 0) > 0.7:
                    anomalies.append(Anomaly(
                        anomaly_type='high_churn_hotspot',
                        target=r['file_path'],
                        detected_by='temporal',
                        severity='high',
                        description=f"Risk: {r['risk_score']:.3f}, {r.get('total_commits', 0)} commits",
                        evidence=[r],
                    ))
        except Exception:
            pass

        return anomalies

    def propose(self, anomaly: Anomaly) -> RepairProposal:
        """Generate a repair proposal for an anomaly."""
        proposals = {
            'architectural_drift': RepairProposal(
                anomaly=anomaly,
                proposed_action='Review naming conventions and refactor outliers to match dominant style',
                estimated_effort='medium',
                risk_level='low',
                validation_checks=['Naming convention conformity improves', 'No new test failures'],
                rollback_plan='Revert to previous naming via git revert',
            ),
            'god_object': RepairProposal(
                anomaly=anomaly,
                proposed_action=f'Split {anomaly.target} into smaller modules by responsibility',
                estimated_effort='large',
                risk_level='medium',
                validation_checks=['All existing callers still work', 'Tests pass', 'No new circular deps'],
                rollback_plan='Keep original file; extract one module at a time, revert individually if needed',
            ),
            'low_confidence': RepairProposal(
                anomaly=anomaly,
                proposed_action=f'Add tests or profiling coverage for {anomaly.target} to improve confidence',
                estimated_effort='medium',
                risk_level='low',
                validation_checks=['Confidence score increases', 'Tests pass'],
                rollback_plan='Remove added tests if they prove unnecessary',
            ),
            'invariant_violation': RepairProposal(
                anomaly=anomaly,
                proposed_action=f'Resolve invariant violation: {anomaly.description}. '
                               f'Restructure dependencies to comply with architectural constraint.',
                estimated_effort='large',
                risk_level='high',
                validation_checks=['Invariant check passes', 'All tests pass', 'Simulation grade safe or cautious'],
                rollback_plan='Revert dependency changes; re-architect with domain owners',
            ),
            'high_churn_hotspot': RepairProposal(
                anomaly=anomaly,
                proposed_action=f'Stabilization refactoring for {anomaly.target}: '
                               f'add tests, reduce coupling, document invariants',
                estimated_effort='large',
                risk_level='medium',
                validation_checks=['Risk score decreases', 'Test coverage increases', 'Bug fix rate decreases'],
                rollback_plan='Work on a branch; only merge when stabilization metrics improve',
            ),
        }

        default = RepairProposal(
            anomaly=anomaly,
            proposed_action=f'Investigate and remediate {anomaly.anomaly_type} in {anomaly.target}',
            estimated_effort='medium',
            risk_level='low',
            validation_checks=['Issue no longer detected'],
            rollback_plan='Revert changes',
        )
        return proposals.get(anomaly.anomaly_type, default)

    def validate(self, proposal: RepairProposal) -> bool:
        """Validate a repair proposal via simulation.

        Returns True if the proposal passes pre-flight checks.
        """
        # For invariant violations, check that the invariant would be satisfied
        if proposal.anomaly.anomaly_type == 'invariant_violation':
            try:
                from .governance import check_all_invariants
                results = check_all_invariants()
                if results['errors']:
                    return False
            except Exception:
                pass
            return True

        # For architectural drift, verify drift score is actually high
        if proposal.anomaly.anomaly_type == 'architectural_drift':
            try:
                from .drift_detection import get_drift_summary
                drift = get_drift_summary()
                return drift.get('average_drift', 0) > 0.3
            except Exception:
                return True

        # Default: low-risk proposals pass validation
        if proposal.risk_level == 'low':
            return True

        return True  # Conservative: let the agent make the final call

    def run_cycle(self) -> dict:
        """Run a full detect → propose → validate pass.

        Returns a dict with anomalies found, proposals generated, and
        validation results. Execution is deferred to the agent.
        """
        anomalies = self.detect()
        proposals = []
        validated = []
        rejected = []

        for anomaly in anomalies:
            proposal = self.propose(anomaly)
            proposals.append(proposal)
            if self.validate(proposal):
                validated.append(proposal)
            else:
                rejected.append(proposal)

        # Rank validated proposals by severity
        severity_order = {'high': 0, 'medium': 1, 'low': 2}
        validated.sort(key=lambda p: severity_order.get(p.anomaly.severity, 1))

        return {
            'anomalies_detected': len(anomalies),
            'proposals_generated': len(proposals),
            'validated': len(validated),
            'rejected': len(rejected),
            'top_proposals': [
                {
                    'anomaly_type': p.anomaly.anomaly_type,
                    'target': p.anomaly.target,
                    'severity': p.anomaly.severity,
                    'proposed_action': p.proposed_action,
                    'estimated_effort': p.estimated_effort,
                    'risk_level': p.risk_level,
                }
                for p in validated[:10]
            ],
        }


def run_self_healing_pass() -> dict:
    """Convenience entry point for hook integration."""
    loop = SelfHealingLoop()
    return loop.run_cycle()
