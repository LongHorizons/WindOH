#!/usr/bin/env python3
"""
Generate a CLAUDE.md knowledge file from the repository cognition index.
This file tells Claude Code agents how to query the structural index.

Robust path resolution: tries CLAUDE_PLUGIN_ROOT env var, then auto-detects
from __file__ location, then falls back to common install paths.
"""

import os
import sys
from datetime import datetime, timezone

# -- Robust plugin root detection --
PLUGIN_ROOT = os.environ.get('CLAUDE_PLUGIN_ROOT', '')
if not PLUGIN_ROOT:
    # Auto-detect from script location (scripts/ directory inside plugin root)
    PLUGIN_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if not PLUGIN_ROOT or not os.path.isdir(PLUGIN_ROOT):
    # Fallback: check common install locations
    candidates = [
        os.path.expanduser('~/.claude/plugins/repo-cognition'),
        os.path.expanduser('~/.claude/plugins/less-toil'),
    ]
    for c in candidates:
        if os.path.isdir(c):
            PLUGIN_ROOT = c
            break

if not PLUGIN_ROOT or not os.path.isdir(PLUGIN_ROOT):
    print("Error: Cannot determine CLAUDE_PLUGIN_ROOT. Set the environment variable.", file=sys.stderr)
    print(f"  Auto-detected: {PLUGIN_ROOT}", file=sys.stderr)
    sys.exit(1)

sys.path.insert(0, PLUGIN_ROOT)

# Ensure project directory is resolved correctly
from core import set_project_dir, CLAUDE_MD_PATH, INDEX_DIR

# Respect CLAUDE_PROJECT_DIR if set
if 'CLAUDE_PROJECT_DIR' in os.environ:
    set_project_dir(os.environ['CLAUDE_PROJECT_DIR'])

from core.manifest import get_stats, get_all_domains


TEMPLATE = """# Repository Cognition Index — Query Reference

> Auto-generated at {timestamp}.
> {file_count} files indexed across {lang_count} languages.
> **Do not edit manually.** Rebuild with `/index-rebuild`.

## Database

```
.claude/index/repo-cognition/index.db
```

### Primary: Python (works on all platforms)
The plugin installs a query helper at `~/.claude/plugins/repo-cognition/scripts/query-index.py`:

```bash
# Any SQL query
python ~/.claude/plugins/repo-cognition/scripts/query-index.py "SELECT * FROM files LIMIT 5"

# Predefined queries (no SQL needed)
python ~/.claude/plugins/repo-cognition/scripts/query-index.py --stats
python ~/.claude/plugins/repo-cognition/scripts/query-index.py --hotspots
python ~/.claude/plugins/repo-cognition/scripts/query-index.py --orphans
python ~/.claude/plugins/repo-cognition/scripts/query-index.py --callers validateToken
python ~/.claude/plugins/repo-cognition/scripts/query-index.py --symbol auth

# JSON output
python ~/.claude/plugins/repo-cognition/scripts/query-index.py --json "SELECT * FROM files LIMIT 5"
```

### Alternative: sqlite3 CLI (Unix/macOS only)
If the `sqlite3` command is available:
```bash
sqlite3 .claude/index/repo-cognition/index.db "SELECT * FROM files LIMIT 5"
```

### Inline Python (any query, always available)
```bash
python -c "
import sqlite3
conn = sqlite3.connect('.claude/index/repo-cognition/index.db')
conn.row_factory = sqlite3.Row
for row in conn.execute('SELECT * FROM files LIMIT 5'):
    print(dict(row))
"
```

## Citation Requirement

**Every codebase answer you give MUST cite its data source.** This is how the user knows the plugin is working:

- When you query the index, prefix your answer with: **`[index]`**
- When you fall back to Grep/Glob, prefix with: **`[grep]`** and explain why the index couldn't answer it

Example: `[index] The function \`handle_event\` is defined in agent-core/src/events.rs:42 and is called by 3 functions across 2 files.`

## Schema

### files
| Column | Type | Description |
|--------|------|-------------|
| id | INTEGER | Primary key |
| file_path | TEXT | Relative path from project root |
| sha256 | TEXT | SHA-256 hash of file contents |
| language | TEXT | Detected programming language |
| file_size | INTEGER | File size in bytes |
| line_count | INTEGER | Number of lines |
| last_indexed_at | TEXT | ISO-8601 timestamp |

### symbols
| Column | Type | Description |
|--------|------|-------------|
| id | INTEGER | Primary key |
| file_id | INTEGER | FK to files.id |
| name | TEXT | Symbol name |
| kind | TEXT | function, class, method, variable, import, export |
| signature | TEXT | Full signature string |
| start_line | INTEGER | Starting line number |
| end_line | INTEGER | Ending line number |
| is_exported | INTEGER | 1 if publicly exported |
| security_sensitive | INTEGER | 1 if touches auth/crypto/secrets |
| has_side_effects | INTEGER | 1 if mutates state, does I/O, etc. |

### call_edges
| Column | Type | Description |
|--------|------|-------------|
| id | INTEGER | Primary key |
| caller_id | INTEGER | FK to symbols.id (the caller) |
| callee_name | TEXT | Name of the called function |
| callee_file | TEXT | File where callee is defined (if resolved) |
| call_line | INTEGER | Line number of the call |
| is_dynamic | INTEGER | 1 for reflection/dynamic calls |
| confidence | REAL | 0.0-1.0 resolution confidence |

### domains
| Column | Type | Description |
|--------|------|-------------|
| id | INTEGER | Primary key |
| name | TEXT | Unique domain name (auth, payments, caching, etc.) |
| description | TEXT | Human-readable description |
| entry_points | TEXT | JSON array of "file:line" strings |
| security_boundary | INTEGER | 1 if this is a security-sensitive boundary |

### file_domains
| Column | Type | Description |
|--------|------|-------------|
| file_id | INTEGER | FK to files.id |
| domain_id | INTEGER | FK to domains.id |
| confidence | REAL | 0.0-1.0 confidence score |

### similarity_groups
| Column | Type | Description |
|--------|------|-------------|
| id | INTEGER | Primary key |
| simhash | TEXT | SimHash fingerprint (hex) |
| file_path | TEXT | File path |
| symbol_name | TEXT | Function/symbol name |
| start_line | INTEGER | Start line |
| end_line | INTEGER | End line |
| normalized_code | TEXT | Normalized code for comparison |

## Common Queries

### Find all files in a language
```sql
SELECT file_path, file_size, line_count
FROM files WHERE language = 'typescript'
ORDER BY file_path;
```

### Find all symbols by name pattern
```sql
SELECT s.name, s.kind, s.start_line, f.file_path
FROM symbols s JOIN files f ON s.file_id = f.id
WHERE s.name LIKE '%{{pattern}}%'
ORDER BY s.name;
```

### Find all callers of a function
```sql
SELECT caller.name AS caller, caller.kind, f.file_path, ce.call_line
FROM call_edges ce
JOIN symbols caller ON ce.caller_id = caller.id
JOIN files f ON caller.file_id = f.id
WHERE ce.callee_name = '{{function_name}}';
```

### Find all functions called by a function
```sql
SELECT ce.callee_name, ce.callee_file, ce.call_line, ce.confidence
FROM call_edges ce
JOIN symbols s ON ce.caller_id = s.id
WHERE s.name = '{{function_name}}';
```

### Find files in a domain
```sql
SELECT f.file_path, f.language, fd.confidence
FROM files f
JOIN file_domains fd ON f.id = fd.file_id
JOIN domains d ON fd.domain_id = d.id
WHERE d.name = '{{domain_name}}'
ORDER BY fd.confidence DESC;
```

### Find similar code blocks (potential duplicates)
```sql
SELECT sg1.file_path, sg1.symbol_name, sg1.start_line, sg2.file_path, sg2.symbol_name, sg2.start_line
FROM similarity_groups sg1
JOIN similarity_groups sg2 ON sg1.simhash = sg2.simhash
WHERE sg1.file_path < sg2.file_path
ORDER BY sg1.simhash;
```

### Trace transitive dependents (impact analysis)
```sql
WITH RECURSIVE dependents AS (
    SELECT s.id, s.name, f.file_path, 1 AS depth
    FROM call_edges ce
    JOIN symbols s ON ce.caller_id = s.id
    JOIN files f ON s.file_id = f.id
    WHERE ce.callee_name = '{{function_name}}'

    UNION ALL

    SELECT s.id, s.name, f.file_path, d.depth + 1
    FROM call_edges ce
    JOIN symbols s ON ce.caller_id = s.id
    JOIN files f ON s.file_id = f.id
    JOIN dependents d ON ce.callee_name = d.name
    WHERE d.depth < 10
)
SELECT DISTINCT file_path, name, depth FROM dependents
ORDER BY depth, file_path
LIMIT 200;
```

### Get index statistics
```sql
SELECT language, COUNT(*) AS count
FROM files GROUP BY language
ORDER BY count DESC;

SELECT COUNT(*) AS symbol_count FROM symbols;
SELECT COUNT(*) AS edge_count FROM call_edges;
SELECT COUNT(*) AS domain_count FROM domains;
```

## Usage in Agent Context

Before creating any new file, utility, or function:
1. **Check for existing implementations**: Query `symbols` for similar names
2. **Check for duplicates**: Query `similarity_groups` for similar code blocks
3. **Check callers before refactoring**: Query `call_edges` for all dependents
4. **Check architectural placement**: Query `file_domains` to find the right domain for new code
5. **Check domain boundaries**: Query `domains` to respect security and architectural boundaries

## Existing Domains
{domains_section}

## Language Breakdown
{language_section}
"""


def build_domains_section() -> str:
    """Build a human-readable domains section."""
    try:
        domains = get_all_domains()
    except Exception:
        return "_(no domains inferred yet — run the architecture-inferrer agent)_"

    if not domains:
        return "_(no domains inferred yet — run the architecture-inferrer agent)_"

    lines = []
    for d in domains:
        sb = " [SECURITY BOUNDARY]" if d.get('security_boundary') else ""
        lines.append(f"- **{d['name']}**{sb}: {d.get('description', '')}")
        try:
            domain_files = get_files_by_language(d['name']) if False else []
            if domain_files:
                lines.append(f"  ({len(domain_files)} files)")
        except Exception:
            pass
    return '\n'.join(lines)


def build_language_section() -> str:
    """Build a language breakdown section."""
    try:
        stats = get_stats()
    except Exception:
        return "_(no index data available)_"

    langs = stats.get('languages', {})
    if not langs:
        return "_(no files indexed yet)_"

    lines = []
    for lang, count in list(langs.items())[:20]:
        lines.append(f"- {lang}: {count} files")
    return '\n'.join(lines)


def main():
    try:
        stats = get_stats()
    except Exception:
        print("Error: could not read index database. Run /index-rebuild first.", file=sys.stderr)
        sys.exit(1)

    timestamp = datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
    domains_section = build_domains_section()
    language_section = build_language_section()

    content = TEMPLATE.format(
        timestamp=timestamp,
        file_count=stats.get('file_count', 0),
        lang_count=len(stats.get('languages', {})),
        domains_section=domains_section,
        language_section=language_section,
    )

    os.makedirs(INDEX_DIR, exist_ok=True)
    with open(CLAUDE_MD_PATH, 'w') as f:
        f.write(content)

    print(f"CLAUDE.md generated at {CLAUDE_MD_PATH}")


if __name__ == "__main__":
    main()
