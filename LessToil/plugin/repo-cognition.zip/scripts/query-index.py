#!/usr/bin/env python3
"""
Cross-platform index query helper for the Repository Cognition Engine.
Uses Python's built-in sqlite3 (stdlib) — works everywhere Python does.

Usage:
  python query-index.py "SELECT * FROM files LIMIT 5"
  python query-index.py --json "SELECT name, kind FROM symbols WHERE name LIKE '%auth%'"
  python query-index.py --callers validateToken
  python query-index.py --hotspots
  python query-index.py --orphans
  python query-index.py --tables
  python query-index.py --check
  python query-index.py --health
  echo "SELECT COUNT(*) FROM files" | python query-index.py

The script auto-detects the project root from CLAUDE_PROJECT_DIR env var,
git root, or the current working directory.
"""

from __future__ import annotations

import json
import os
import sys


DB_RELATIVE_PATH = ".claude/index/repo-cognition/index.db"


def _resolve_project_dir() -> str:
    """Resolve the project directory using the fallback chain from core."""
    # Strategy 1: Environment variable
    env_dir = os.environ.get("CLAUDE_PROJECT_DIR", "")
    if env_dir and os.path.isdir(env_dir):
        return os.path.abspath(env_dir)

    # Strategy 2: Git root
    try:
        import subprocess
        result = subprocess.run(
            ['git', 'rev-parse', '--show-toplevel'],
            capture_output=True, text=True, timeout=10,
            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0)
        )
        if result.returncode == 0:
            git_root = result.stdout.strip()
            if git_root and os.path.isdir(git_root):
                return os.path.abspath(git_root)
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        pass

    # Strategy 3: CWD
    return os.path.abspath(os.getcwd())


def _find_db() -> str:
    """Resolve the index database path. Exits with a clear message if not found."""
    project_dir = _resolve_project_dir()
    db_path = os.path.join(project_dir, DB_RELATIVE_PATH)

    if not os.path.exists(db_path):
        print(f"Error: Index database not found.", file=sys.stderr)
        print(f"  Expected: {db_path}", file=sys.stderr)
        print(f"  Project directory: {project_dir}", file=sys.stderr)
        print(file=sys.stderr)
        print("The repository cognition index has not been built yet.", file=sys.stderr)
        print(file=sys.stderr)
        print("To create it:", file=sys.stderr)
        print("  1. Open Claude Code in this project", file=sys.stderr)
        print("  2. Run /index-rebuild", file=sys.stderr)
        print(file=sys.stderr)
        print("Or manually:", file=sys.stderr)
        print("  python plugins/repo-cognition/hooks/session_start.py", file=sys.stderr)
        sys.exit(1)

    # Verify it's a real SQLite database with tables
    if os.path.getsize(db_path) == 0:
        print(f"Error: Index database is empty (zero bytes).", file=sys.stderr)
        print(f"  Path: {db_path}", file=sys.stderr)
        print("Run /index-rebuild to recreate it.", file=sys.stderr)
        sys.exit(1)

    try:
        import sqlite3
        conn = sqlite3.connect(db_path)
        try:
            table_count = conn.execute(
                "SELECT COUNT(*) FROM sqlite_master WHERE type='table'"
            ).fetchone()[0]
            if table_count == 0:
                print(f"Error: Index database exists but contains no tables.", file=sys.stderr)
                print(f"  Path: {db_path}", file=sys.stderr)
                print("The file may be corrupt. Delete it and run /index-rebuild.", file=sys.stderr)
                sys.exit(1)
        finally:
            conn.close()
    except sqlite3.Error as e:
        print(f"Error: Cannot open index database: {e}", file=sys.stderr)
        print(f"  Path: {db_path}", file=sys.stderr)
        print("The file may be corrupt. Delete it and run /index-rebuild.", file=sys.stderr)
        sys.exit(1)

    return db_path


def run_sql(sql: str, db_path: str, params: tuple = ()) -> list[dict]:
    """Execute SQL with parameters and return rows as dicts."""
    import sqlite3
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        rows = conn.cursor().execute(sql, params).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def run_sql_raw(sql: str, db_path: str) -> list[dict]:
    """Execute raw SQL (for predefined queries from trusted source)."""
    import sqlite3
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        rows = conn.cursor().execute(sql).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def print_table(rows: list[dict]) -> None:
    """Print rows as a formatted text table."""
    if not rows:
        print("(no results)")
        return
    cols = list(rows[0].keys())
    widths = {c: len(c) for c in cols}
    for row in rows:
        for c in cols:
            widths[c] = max(widths[c], len(str(row[c])))
    header = " | ".join(c.ljust(widths[c]) for c in cols)
    sep = "-+-".join("-" * widths[c] for c in cols)
    print(header)
    print(sep)
    for row in rows:
        print(" | ".join(str(row[c]).ljust(widths[c]) for c in cols))
    print(f"\n({len(rows)} row(s))")


def print_json(rows: list[dict]) -> None:
    """Print rows as JSON."""
    print(json.dumps(rows, indent=2, default=str))


# --- Predefined queries (trusted, static SQL) -------------------------------

PREDEFINED = {
    "--tables": """
        SELECT name FROM sqlite_master
        WHERE type='table' AND name NOT LIKE 'sqlite_%'
        ORDER BY name
    """,
    "--stats": """
        SELECT
            (SELECT COUNT(*) FROM files) AS files,
            (SELECT COUNT(*) FROM symbols) AS symbols,
            (SELECT COUNT(*) FROM call_edges) AS call_edges,
            (SELECT COUNT(*) FROM domains) AS domains
    """,
    "--health": """
        SELECT
            (SELECT COUNT(*) FROM files) AS files,
            (SELECT COUNT(*) FROM symbols) AS symbols,
            (SELECT COUNT(*) FROM call_edges) AS edges,
            (SELECT COUNT(*) FROM domains) AS domains,
            (SELECT COUNT(*) FROM confidence_scores) AS confidence_scores,
            (SELECT COUNT(*) FROM temporal_metrics) AS temporal_metrics,
            (SELECT COUNT(*) FROM similarity_groups) AS similarity_groups,
            (SELECT COUNT(*) FROM stewardship_suggestions WHERE resolved_at IS NULL) AS open_suggestions,
            (SELECT COUNT(*) FROM invariant_violations WHERE resolved_at IS NULL) AS open_violations,
            (SELECT COUNT(*) FROM immune_alerts WHERE resolved_at IS NULL) AS open_alerts,
            CASE WHEN (SELECT COUNT(*) FROM files) > 0 AND (SELECT COUNT(*) FROM symbols) = 0
                 THEN 'WARN: files but no symbols — indexing may be incomplete'
                 WHEN (SELECT COUNT(*) FROM files) = 0
                 THEN 'EMPTY: no files indexed'
                 ELSE 'OK'
            END AS status
    """,
    "--hotspots": """
        SELECT ce.callee_name, COUNT(*) AS callers, f.file_path
        FROM call_edges ce
        LEFT JOIN symbols s ON s.name = ce.callee_name
        LEFT JOIN files f ON s.file_id = f.id
        WHERE ce.callee_name IS NOT NULL
        GROUP BY ce.callee_name
        ORDER BY callers DESC LIMIT 20
    """,
    "--orphans": """
        SELECT s.name, s.kind, f.file_path, s.start_line
        FROM symbols s JOIN files f ON s.file_id = f.id
        WHERE s.kind IN ('function', 'method')
          AND s.name NOT IN (
            SELECT DISTINCT ce.callee_name FROM call_edges
            WHERE ce.callee_name IS NOT NULL
          )
        ORDER BY f.file_path, s.start_line LIMIT 50
    """,
    "--domains": """
        SELECT d.name, d.description,
               CASE WHEN d.security_boundary THEN 'YES' ELSE 'no' END AS sec_boundary,
               COUNT(fd.file_id) AS files
        FROM domains d
        LEFT JOIN file_domains fd ON d.id = fd.domain_id
        GROUP BY d.id ORDER BY files DESC
    """,
    "--languages": """
        SELECT language, COUNT(*) AS files, SUM(file_size) AS total_bytes
        FROM files GROUP BY language ORDER BY files DESC
    """,
    "--riskiest": """
        SELECT file_path, ROUND(risk_score, 3) AS risk
        FROM temporal_metrics ORDER BY risk_score DESC LIMIT 10
    """,
    "--drift": """
        SELECT file_path, ROUND(drift_score, 3) AS drift
        FROM files WHERE drift_score > 0 ORDER BY drift_score DESC LIMIT 10
    """,
    "--duplicates": """
        SELECT sg1.file_path AS file_a, sg1.symbol_name AS symbol_a,
               sg2.file_path AS file_b, sg2.symbol_name AS symbol_b
        FROM similarity_groups sg1
        JOIN similarity_groups sg2 ON sg1.simhash = sg2.simhash
        WHERE sg1.file_path < sg2.file_path
        ORDER BY sg1.simhash LIMIT 20
    """,
}


# --- User-input-based queries (PARAMETERIZED — no SQL injection) ------------

_CALLERS_SQL = """
    SELECT DISTINCT s.name, s.kind, f.file_path, ce.call_line
    FROM call_edges ce
    JOIN symbols s ON ce.caller_id = s.id
    JOIN files f ON s.file_id = f.id
    WHERE ce.callee_name = ?
    ORDER BY f.file_path
"""

_CALLEES_SQL = """
    SELECT ce.callee_name, ce.callee_file, ce.call_line, ce.confidence
    FROM call_edges ce
    JOIN symbols s ON ce.caller_id = s.id
    WHERE s.name = ?
    ORDER BY ce.call_line
"""

_SYMBOL_SQL = """
    SELECT s.name, s.kind, f.file_path, s.start_line, s.end_line,
           s.is_exported, s.security_sensitive
    FROM symbols s JOIN files f ON s.file_id = f.id
    WHERE s.name LIKE ?
    ORDER BY s.name, f.file_path
"""


def _callers_query(db_path: str, name: str) -> list[dict]:
    return run_sql(_CALLERS_SQL, db_path, (name,))


def _callees_query(db_path: str, name: str) -> list[dict]:
    return run_sql(_CALLEES_SQL, db_path, (name,))


def _symbol_query(db_path: str, name: str) -> list[dict]:
    return run_sql(_SYMBOL_SQL, db_path, (f'%{name}%',))


# --- Main -----------------------------------------------------------------

def main() -> None:
    # Ensure UTF-8 output on Windows (cp1252 can't render Unicode)
    if sys.platform == 'win32':
        try:
            sys.stdout.reconfigure(encoding='utf-8', errors='replace')
            sys.stderr.reconfigure(encoding='utf-8', errors='replace')
        except Exception:
            pass

    if len(sys.argv) < 2 or sys.argv[1] in ("-h", "--help"):
        print(__doc__)
        print("Predefined queries:")
        for key in sorted(PREDEFINED):
            print(f"  {key}")
        print("  --callers NAME")
        print("  --callees NAME")
        print("  --symbol NAME")
        print("  --check              (verify index exists and is non-empty)")
        return

    use_json = False
    sql = None
    sql_params = ()
    mode_callers = None
    mode_callees = None
    mode_symbol = None

    args = sys.argv[1:]
    i = 0
    while i < len(args):
        arg = args[i]
        if arg == "--json":
            use_json = True
            i += 1
        elif arg == "--callers":
            i += 1
            if i < len(args):
                mode_callers = args[i]
            i += 1
        elif arg == "--callees":
            i += 1
            if i < len(args):
                mode_callees = args[i]
            i += 1
        elif arg == "--symbol":
            i += 1
            if i < len(args):
                mode_symbol = args[i]
            i += 1
        elif arg == "--check":
            # Just verify the index exists and is non-empty
            db_path = _find_db()  # Will exit with clear message if missing
            import sqlite3
            conn = sqlite3.connect(db_path)
            try:
                count = conn.execute("SELECT COUNT(*) FROM files").fetchone()[0]
                if count > 0:
                    print(f"OK: Index exists with {count} files.")
                    sys.exit(0)
                else:
                    print("WARN: Index exists but has 0 files.", file=sys.stderr)
                    print("Run /index-rebuild to populate it.", file=sys.stderr)
                    sys.exit(2)
            finally:
                conn.close()
        elif arg in PREDEFINED:
            sql = PREDEFINED[arg]
            i += 1
        else:
            sql = arg
            i += 1

    # Resolve DB path (may exit if not found)
    db_path = _find_db()

    # Execute
    rows = []
    if mode_callers:
        rows = _callers_query(db_path, mode_callers)
    elif mode_callees:
        rows = _callees_query(db_path, mode_callees)
    elif mode_symbol:
        rows = _symbol_query(db_path, mode_symbol)
    elif sql:
        rows = run_sql_raw(sql, db_path)
    else:
        # Try reading from stdin
        if not sys.stdin.isatty():
            sql = sys.stdin.read().strip()
            if sql:
                rows = run_sql_raw(sql, db_path)
            else:
                print("Error: no SQL query provided", file=sys.stderr)
                sys.exit(1)
        else:
            print("Error: no SQL query provided", file=sys.stderr)
            print("Use --check to verify index existence, or pass a query.", file=sys.stderr)
            sys.exit(1)

    if use_json:
        print_json(rows)
    else:
        print_table(rows)


if __name__ == "__main__":
    main()
