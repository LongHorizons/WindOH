#!/usr/bin/env python3
"""
Cross-platform index query helper for the Repository Cognition Engine.
Uses Python's built-in sqlite3 (stdlib) — works everywhere Python does.

Usage:
  python query-index.py "SELECT * FROM files LIMIT 5"
  python query-index.py --json "SELECT name, kind FROM symbols WHERE name LIKE '%auth%'"
  python query-index.py --callers validateToken
  python query-index.py --hotspots
  python query-index.py --orphans
  python query-index.py --tables
  echo "SELECT COUNT(*) FROM files" | python query-index.py

The script auto-detects the project root from CLAUDE_PROJECT_DIR env var
or the current working directory.
"""

from __future__ import annotations

import json
import os
import sys


DB_RELATIVE_PATH = ".claude/index/repo-cognition/index.db"


def _find_db() -> str:
    """Resolve the index database path."""
    project_dir = os.environ.get("CLAUDE_PROJECT_DIR", os.getcwd())
    db_path = os.path.join(project_dir, DB_RELATIVE_PATH)
    if not os.path.exists(db_path):
        print(f"Error: index database not found at {db_path}", file=sys.stderr)
        print("Run /index-rebuild or open a Claude Code session to generate it.", file=sys.stderr)
        sys.exit(1)
    return db_path


def run_sql(sql: str, db_path: str) -> list[dict]:
    """Execute SQL and return rows as dicts."""
    import sqlite3
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        rows = conn.cursor().execute(sql).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def print_table(rows: list[dict]) -> None:
    """Print rows as a formatted text table."""
    if not rows:
        print("(no results)")
        return
    cols = list(rows[0].keys())
    widths = {c: len(c) for c in cols}
    for row in rows:
        for c in cols:
            widths[c] = max(widths[c], len(str(row[c])))
    header = " | ".join(c.ljust(widths[c]) for c in cols)
    sep = "-+-".join("-" * widths[c] for c in cols)
    print(header)
    print(sep)
    for row in rows:
        print(" | ".join(str(row[c]).ljust(widths[c]) for c in cols))
    print(f"\n({len(rows)} row(s))")


def print_json(rows: list[dict]) -> None:
    """Print rows as JSON."""
    print(json.dumps(rows, indent=2, default=str))


# --- Predefined queries ---------------------------------------------------

PREDEFINED = {
    "--tables": """
        SELECT name FROM sqlite_master
        WHERE type='table' AND name NOT LIKE 'sqlite_%'
        ORDER BY name
    """,
    "--stats": """
        SELECT
            (SELECT COUNT(*) FROM files) AS files,
            (SELECT COUNT(*) FROM symbols) AS symbols,
            (SELECT COUNT(*) FROM call_edges) AS call_edges,
            (SELECT COUNT(*) FROM domains) AS domains
    """,
    "--hotspots": """
        SELECT ce.callee_name, COUNT(*) AS callers, f.file_path
        FROM call_edges ce
        LEFT JOIN symbols s ON s.name = ce.callee_name
        LEFT JOIN files f ON s.file_id = f.id
        WHERE ce.callee_name IS NOT NULL
        GROUP BY ce.callee_name
        ORDER BY callers DESC LIMIT 20
    """,
    "--orphans": """
        SELECT s.name, s.kind, f.file_path, s.start_line
        FROM symbols s JOIN files f ON s.file_id = f.id
        WHERE s.kind IN ('function', 'method')
          AND s.name NOT IN (
            SELECT DISTINCT ce.callee_name FROM call_edges
            WHERE ce.callee_name IS NOT NULL
          )
        ORDER BY f.file_path, s.start_line LIMIT 50
    """,
    "--domains": """
        SELECT d.name, d.description,
               CASE WHEN d.security_boundary THEN 'YES' ELSE 'no' END AS sec_boundary,
               COUNT(fd.file_id) AS files
        FROM domains d
        LEFT JOIN file_domains fd ON d.id = fd.domain_id
        GROUP BY d.id ORDER BY files DESC
    """,
    "--languages": """
        SELECT language, COUNT(*) AS files, SUM(file_size) AS total_bytes
        FROM files GROUP BY language ORDER BY files DESC
    """,
    "--riskiest": """
        SELECT file_path, ROUND(risk_score, 3) AS risk
        FROM temporal_metrics ORDER BY risk_score DESC LIMIT 10
    """,
    "--drift": """
        SELECT file_path, ROUND(drift_score, 3) AS drift
        FROM files WHERE drift_score > 0 ORDER BY drift_score DESC LIMIT 10
    """,
    "--duplicates": """
        SELECT sg1.file_path AS file_a, sg1.symbol_name AS symbol_a,
               sg2.file_path AS file_b, sg2.symbol_name AS symbol_b
        FROM similarity_groups sg1
        JOIN similarity_groups sg2 ON sg1.simhash = sg2.simhash
        WHERE sg1.file_path < sg2.file_path
        ORDER BY sg1.simhash LIMIT 20
    """,
}


def _callers_query(name: str) -> str:
    return f"""
        SELECT DISTINCT s.name, s.kind, f.file_path, ce.call_line
        FROM call_edges ce
        JOIN symbols s ON ce.caller_id = s.id
        JOIN files f ON s.file_id = f.id
        WHERE ce.callee_name = '{name}'
        ORDER BY f.file_path
    """


def _callees_query(name: str) -> str:
    return f"""
        SELECT ce.callee_name, ce.callee_file, ce.call_line, ce.confidence
        FROM call_edges ce
        JOIN symbols s ON ce.caller_id = s.id
        WHERE s.name = '{name}'
        ORDER BY ce.call_line
    """


def _symbol_query(name: str) -> str:
    return f"""
        SELECT s.name, s.kind, f.file_path, s.start_line, s.end_line,
               s.is_exported, s.security_sensitive
        FROM symbols s JOIN files f ON s.file_id = f.id
        WHERE s.name LIKE '%{name}%'
        ORDER BY s.name, f.file_path
    """


# --- Main -----------------------------------------------------------------

def main() -> None:
    if len(sys.argv) < 2 or sys.argv[1] in ("-h", "--help"):
        print(__doc__)
        print("Predefined queries:")
        for key in sorted(PREDEFINED):
            print(f"  {key}")
        print("  --callers NAME")
        print("  --callees NAME")
        print("  --symbol NAME")
        return

    use_json = False
    sql = None

    args = sys.argv[1:]
    i = 0
    while i < len(args):
        arg = args[i]
        if arg == "--json":
            use_json = True
            i += 1
        elif arg == "--callers":
            i += 1
            sql = _callers_query(args[i]) if i < len(args) else None
            i += 1
        elif arg == "--callees":
            i += 1
            sql = _callees_query(args[i]) if i < len(args) else None
            i += 1
        elif arg == "--symbol":
            i += 1
            sql = _symbol_query(args[i]) if i < len(args) else None
            i += 1
        elif arg in PREDEFINED:
            sql = PREDEFINED[arg]
            i += 1
        else:
            sql = arg
            i += 1

    if not sql:
        # Try reading from stdin
        if not sys.stdin.isatty():
            sql = sys.stdin.read().strip()
        else:
            print("Error: no SQL query provided", file=sys.stderr)
            sys.exit(1)

    db_path = _find_db()
    rows = run_sql(sql, db_path)

    if use_json:
        print_json(rows)
    else:
        print_table(rows)


if __name__ == "__main__":
    main()
