---
description: Display index health, governance, drift, stewardship, and trust statistics as a professional dashboard
allowed-tools: Bash, Read
---

Show a professional visual dashboard of the repository cognition index.

## Collect Data

Run these queries in parallel:

1. Core stats:
   ```bash
   ls -la .claude/index/repo-cognition/index.db 2>/dev/null && echo "EXISTS" || echo "MISSING"
   ```
   ```bash
   sqlite3 .claude/index/repo-cognition/index.db "
   SELECT 'files:' || COUNT(*) FROM files
   UNION ALL SELECT 'symbols:' || COUNT(*) FROM symbols
   UNION ALL SELECT 'edges:' || COUNT(*) FROM call_edges
   UNION ALL SELECT 'domains:' || COUNT(*) FROM domains
   UNION ALL SELECT 'schema:v' || version FROM schema_version;
   "
   ```

2. Language distribution:
   ```bash
   sqlite3 .claude/index/repo-cognition/index.db "
   SELECT language, COUNT(*) FROM files GROUP BY language ORDER BY COUNT(*) DESC;
   "
   ```

3. Domains:
   ```bash
   sqlite3 .claude/index/repo-cognition/index.db "
   SELECT d.name, COUNT(fd.file_id), d.security_boundary
   FROM domains d LEFT JOIN file_domains fd ON d.id = fd.domain_id
   GROUP BY d.name ORDER BY COUNT(fd.file_id) DESC;
   "
   ```

4. Governance:
   ```bash
   sqlite3 .claude/index/repo-cognition/index.db "
   SELECT 'invariants:' || COUNT(*) || ' enabled, ' || (SELECT COUNT(*) FROM invariant_violations WHERE resolved_at IS NULL) || ' violations' FROM invariants WHERE enabled = 1
   UNION ALL SELECT 'policies:' || COUNT(*) || ' enabled, ' || (SELECT COUNT(*) FROM policy_violations WHERE resolved_at IS NULL) || ' violations' FROM policies WHERE enabled = 1;
   "
   ```

5. Confidence:
   ```bash
   sqlite3 .claude/index/repo-cognition/index.db "
   SELECT ROUND(AVG(aggregate_confidence), 2), COUNT(*), (SELECT COUNT(*) FROM confidence_scores WHERE aggregate_confidence < 0.5) FROM confidence_scores;
   "
   ```

6. Temporal risk:
   ```bash
   sqlite3 .claude/index/repo-cognition/index.db "
   SELECT COUNT(*), ROUND(AVG(risk_score), 2), (SELECT COUNT(*) FROM temporal_metrics WHERE risk_score >= 0.7), (SELECT COUNT(*) FROM temporal_metrics WHERE risk_score >= 0.9) FROM temporal_metrics;
   "
   ```

7. Top risky files:
   ```bash
   sqlite3 .claude/index/repo-cognition/index.db "
   SELECT file_path, ROUND(risk_score, 2) FROM temporal_metrics ORDER BY risk_score DESC LIMIT 5;
   "
   ```

8. Drift:
   ```bash
   sqlite3 .claude/index/repo-cognition/index.db "
   SELECT ROUND(AVG(architectural_drift_score), 2), (SELECT COUNT(*) FROM files WHERE architectural_drift_score > 0.5) FROM files;
   "
   ```

9. Stewardship:
   ```bash
   sqlite3 .claude/index/repo-cognition/index.db "
   SELECT severity, category, title FROM stewardship_suggestions WHERE resolved_at IS NULL ORDER BY CASE severity WHEN 'high' THEN 0 WHEN 'medium' THEN 1 ELSE 2 END LIMIT 8;
   "
   ```

10. Immune & epistemic:
    ```bash
    sqlite3 .claude/index/repo-cognition/index.db "
    SELECT 'evidence:' || COUNT(*) || ' records, ' || (SELECT COUNT(*) FROM evidence_records WHERE expires_at IS NOT NULL AND datetime(expires_at) < datetime('now')) || ' stale' FROM evidence_records
    UNION ALL SELECT 'contradictions:' || COUNT(*) || ' unresolved' FROM contradictions WHERE resolved_at IS NULL
    UNION ALL SELECT 'immune alerts:' || COUNT(*) || ' unresolved' FROM immune_alerts WHERE resolved_at IS NULL;
    "
    ```

11. Freshness:
    ```bash
    cat .claude/index/repo-cognition/last_index.txt 2>/dev/null || echo "unknown"
    ```

## Present as Professional Dashboard

Format the collected data into this exact structure. Use geometric indicators and clean box drawing. Replace `<placeholders>` with actual values.

Determine health:
- ● HEALTHY: symbols > 0 AND edges > 0 AND no critical risk
- ◉ DEGRADED: files > 0 but (no symbols OR no edges OR violations exist)
- ○ LIMITED: no files OR no index

```
┌──────────────────────────────────────────────────────────┐
│  ◆  REPOSITORY COGNITION  —  Index Dashboard             │
│  <health indicator>                                      │
│  Last index: <timestamp>                                  │
└──────────────────────────────────────────────────────────┘

  ──  CORE METRICS
  ┌──────────────────────────────────────────────────────────┐
  │  Files: <N>       Symbols: <N>       Call edges: <N>      │
  │  Domains: <N>      Schema: v<N>                           │
  └──────────────────────────────────────────────────────────┘

  ──  LANGUAGE DISTRIBUTION
  <bar chart using █ and ░, width proportional to max>
  rust           ████████████████ 38
  python         ████████ 18
  markdown       ██████ 13
  ...

  ──  DOMAINS
  <list with ◆ for security boundaries>
  agent-core (21 files)  │  agent-etw (14) ◆  │  service (8)
  ...

  ──  TEMPORAL RISK
  ┌──────────────────────────────────────────────────────────┐
  │  Files analyzed: <N>    Avg risk: <score>                  │
  │  High-risk (>0.7): <N>    Critical (>0.9): <N>             │
  └──────────────────────────────────────────────────────────┘
  Top risk:
  ◆  path/to/file.rs  [0.92]
  ◇  path/to/file.rs  [0.75]
  ... (up to 5, ◆ for ≥0.9, ◇ for ≥0.7)

  ──  CONFIDENCE
  ┌──────────────────────────────────────────────────────────┐
  │  Avg aggregate: <score>    Total scores: <N>               │
  │  Below threshold: <N>                                      │
  └──────────────────────────────────────────────────────────┘

  ──  ARCHITECTURAL DRIFT
  ┌──────────────────────────────────────────────────────────┐
  │  Avg drift: <score>    High-drift files: <N>               │
  └──────────────────────────────────────────────────────────┘

  ──  STEWARDSHIP
  ◆  [HIGH] <title>
  ◇  [MEDIUM] <title>
  ... (up to 8, ◆ for high, ◇ for medium)

  ──  GOVERNANCE
  ┌──────────────────────────────────────────────────────────┐
  │  Invariants: <N> enabled, <N> violations                   │
  │  Policies: <N> enabled, <N> violations                     │
  └──────────────────────────────────────────────────────────┘

  ──  IMMUNE + EPISTEMIC
  ┌──────────────────────────────────────────────────────────┐
  │  Evidence: <N> records, <N> stale                          │
  │  Contradictions: <N> unresolved                            │
  │  Immune alerts: <N> unresolved                             │
  └──────────────────────────────────────────────────────────┘

  ═══════════════════════════════════════════════════════════
  /index-rebuild  ·  /index-graph  ·  /index-graph --hotspots
```

Project this dashboard directly. Do not describe it — output it as the response.
