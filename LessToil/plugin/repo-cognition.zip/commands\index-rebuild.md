---
description: Force a full rebuild of the repository cognition index
allowed-tools: Bash
---

Force a complete rebuild of the repository cognition index from scratch.

## Clear Existing Index

```bash
rm -f .claude/index/repo-cognition/index.db \
      .claude/index/repo-cognition/index.db-wal \
      .claude/index/repo-cognition/index.db-shm \
      .claude/index/repo-cognition/file_manifest.json \
      .claude/index/repo-cognition/indexing.lock \
      .claude/index/repo-cognition/last_index.txt
```

## Run SessionStart Hook

```bash
CLAUDE_PLUGIN_ROOT="$HOME/.claude/plugins/repo-cognition" \
CLAUDE_PROJECT_DIR="$(pwd)" \
python "$HOME/.claude/plugins/repo-cognition/hooks/session_start.py" <<< '{"session_id":"rebuild","cwd":"'"$(pwd)"'"}'
```

## Confirm Rebuild

After the hook completes, verify the index was rebuilt:

```bash
sqlite3 .claude/index/repo-cognition/index.db \
  "SELECT 'files:' || COUNT(*) FROM files
   UNION ALL SELECT 'symbols:' || COUNT(*) FROM symbols
   UNION ALL SELECT 'edges:' || COUNT(*) FROM call_edges
   UNION ALL SELECT 'schema:v' || version FROM schema_version;"
```

Report the new file count, symbol count, call edge count, and schema version to confirm the rebuild succeeded.
