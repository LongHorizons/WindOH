#!/usr/bin/env python3
"""
PostToolUse hook for the Repository Cognition Engine.

Detects file changes from Write/Edit/MultiEdit tools, incrementally
reindexes only the affected files. All analysis runs at full speed.
Output is silent — reindexing is background infrastructure.

Failures are logged to stderr (visible in Claude Code debug output)
but never block the user's workflow.
"""

from __future__ import annotations

import json
import os
import sys
import time
import traceback

PLUGIN_ROOT = os.environ.get('CLAUDE_PLUGIN_ROOT', '')
if not PLUGIN_ROOT:
    PLUGIN_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PLUGIN_ROOT:
    sys.path.insert(0, PLUGIN_ROOT)

from core import PROJECT_DIR
from core.manifest import init_db, upsert_file, get_connection
from core.indexer import compute_sha256, detect_language, count_lines, is_binary


def _log_error(msg: str) -> None:
    """Log an error to stderr for debug visibility without chat noise."""
    print(f'[repo-cognition] {msg}', file=sys.stderr)


def read_hook_input() -> dict:
    try:
        raw = sys.stdin.read()
        if not raw.strip():
            return {}
        return json.loads(raw)
    except json.JSONDecodeError as e:
        _log_error(f'Failed to parse hook input: {e}')
        return {}


def extract_file_paths(tool_name: str, tool_input: dict) -> list[str]:
    """Extract affected file paths from tool input."""
    paths = []
    file_path = tool_input.get('file_path', '')

    if tool_name == 'Write':
        if file_path:
            paths.append(file_path)
    elif tool_name == 'Edit':
        if file_path:
            paths.append(file_path)
    elif tool_name == 'MultiEdit':
        edits = tool_input.get('edits', [])
        for edit in edits:
            edit_path = edit.get('file_path', file_path)
            if edit_path:
                paths.append(edit_path)
        if not paths and file_path:
            paths.append(file_path)

    return paths


def reindex_file(file_path: str) -> dict:
    """Reindex a single file. Returns status dict with outcome detail.

    On symbol extraction failure, old symbols are cleared so the index
    shows "no data" rather than stale data. The error is logged so the
    user can investigate.
    """
    full_path = os.path.join(PROJECT_DIR, file_path)
    full_path = os.path.normpath(full_path)

    # File was deleted — remove from index entirely
    if not os.path.exists(full_path):
        conn = get_connection()
        try:
            conn.execute("DELETE FROM files WHERE file_path = ?", (file_path,))
            conn.commit()
        finally:
            conn.close()
        return {"status": "deleted", "file": file_path}

    if is_binary(full_path):
        return {"status": "skipped", "file": file_path, "reason": "binary"}

    language = detect_language(full_path)
    if language == 'unknown':
        return {"status": "skipped", "file": file_path, "reason": "unknown_language"}

    # Recompute file identity
    try:
        sha256 = compute_sha256(full_path)
        file_size = os.path.getsize(full_path)
        line_count = count_lines(full_path)
    except OSError as e:
        return {"status": "error", "file": file_path, "reason": f"io_error: {e}"}

    init_db()

    # Get file_id (or create if new) — need this even if symbol extraction fails
    conn = get_connection()
    try:
        cur = conn.execute("SELECT id FROM files WHERE file_path = ?", (file_path,))
        row = cur.fetchone()
        if row:
            file_id = row[0]
        else:
            # New file — upsert_file will create it
            file_id = None
    finally:
        conn.close()

    # Always update the file manifest (SHA256, size, line count)
    upsert_file(
        file_path=file_path,
        sha256=sha256,
        language=language,
        file_size=file_size,
        line_count=line_count,
    )

    # Re-fetch file_id if it was a new file
    if file_id is None:
        conn = get_connection()
        try:
            cur = conn.execute("SELECT id FROM files WHERE file_path = ?", (file_path,))
            row = cur.fetchone()
            file_id = row[0] if row else None
        finally:
            conn.close()

    if file_id is None:
        _log_error(f'Could not find or create file_id for {file_path}')
        return {"status": "error", "file": file_path, "reason": "no_file_id"}

    # ── Symbol re-extraction ──
    from core.symbols import parse_file, SUPPORTED_LANGUAGES
    from core.manifest import upsert_symbols_batch, insert_call_edges_batch

    symbols = []
    calls = []
    extraction_error = None

    if language in SUPPORTED_LANGUAGES:
        try:
            symbols, calls = parse_file(full_path, language)
        except Exception as e:
            extraction_error = f'{type(e).__name__}: {e}'
            _log_error(f'Symbol extraction failed for {file_path}: {extraction_error}')
            _log_error(traceback.format_exc())
            # symbols and calls stay empty — old data will be cleared below
    else:
        # Language detected but not in tree-sitter/regex support list.
        # Still clear old symbols since the file content changed.
        pass

    # Always clear old symbols + edges for this file, even on extraction failure.
    # Stale data is worse than no data.
    try:
        upsert_symbols_batch(file_id, symbols)
    except Exception as e:
        _log_error(f'Symbol upsert failed for {file_path}: {e}')

    # Confidence scores
    if symbols:
        try:
            from core.confidence import compute_confidence_batch
            compute_confidence_batch(file_id, symbols, language)
        except Exception as e:
            _log_error(f'Confidence scoring failed for {file_path}: {e}')

    # Call edges
    edges = []
    if calls:
        try:
            conn = get_connection()
            try:
                for call in calls:
                    cur2 = conn.execute(
                        """SELECT id FROM symbols
                           WHERE file_id = ? AND kind IN ('function', 'method')
                             AND start_line <= ? AND end_line >= ?
                           LIMIT 1""",
                        (file_id, call['call_line'], call['call_line'])
                    )
                    caller_row = cur2.fetchone()
                    if caller_row:
                        edges.append({
                            'caller_id': caller_row[0],
                            'callee_name': call['callee_name'],
                            'callee_file': call.get('callee_file'),
                            'call_line': call['call_line'],
                            'is_dynamic': call.get('is_dynamic', False),
                            'confidence': call.get('confidence', 1.0),
                        })
            finally:
                conn.close()

            if edges:
                insert_call_edges_batch(edges)
        except Exception as e:
            _log_error(f'Call edge insertion failed for {file_path}: {e}')

    # Temporal change counter
    try:
        from core.temporal import increment_change_counter
        increment_change_counter(file_path)
    except Exception as e:
        _log_error(f'Temporal counter failed for {file_path}: {e}')

    # Confidence feedback loop
    if symbols:
        try:
            from core.confidence import feedback_loop
            feedback_loop(file_path)
        except Exception as e:
            _log_error(f'Confidence feedback failed for {file_path}: {e}')

    # Mark reindex timestamp on the file record
    try:
        conn = get_connection()
        try:
            conn.execute(
                "UPDATE files SET last_indexed_at = datetime('now') WHERE id = ?",
                (file_id,)
            )
            conn.commit()
        finally:
            conn.close()
    except Exception:
        pass

    result = {
        "status": "reindexed",
        "file": file_path,
        "language": language,
        "symbols": len(symbols),
        "calls": len(edges),
    }
    if extraction_error:
        result["warning"] = extraction_error

    return result


def main():
    start_time = time.time()
    input_data = read_hook_input()
    tool_name = input_data.get('tool_name', '')
    tool_input = input_data.get('tool_input', {})

    if tool_name not in ('Write', 'Edit', 'MultiEdit'):
        sys.exit(0)

    if 'CLAUDE_PROJECT_DIR' in os.environ:
        import core
        core.PROJECT_DIR = os.environ['CLAUDE_PROJECT_DIR']

    file_paths = extract_file_paths(tool_name, tool_input)
    results = []

    for path in file_paths:
        if not path:
            continue
        if os.path.isabs(path) and not path.startswith(PROJECT_DIR):
            _log_error(f'Skipping path outside project: {path}')
            continue
        try:
            result = reindex_file(path)
            results.append(result)
        except Exception as e:
            _log_error(f'Reindex crashed for {path}: {traceback.format_exc()}')
            results.append({"status": "error", "file": path, "reason": str(e)})

    # Post-execute verification (TRACE + SCORE)
    reindexed = [r for r in results if r.get('status') == 'reindexed']
    if reindexed:
        try:
            from core.verification import verify_change
            changed_paths = [r['file'] for r in reindexed]
            verify_change(changed_paths, post_execute=True)
        except Exception:
            pass

    # Log a summary of what happened (stderr, not chat output)
    elapsed = (time.time() - start_time) * 1000
    statuses = {}
    for r in results:
        s = r.get('status', 'unknown')
        statuses[s] = statuses.get(s, 0) + 1
    summary = ', '.join(f'{v} {k}' for k, v in statuses.items())
    errors = [r for r in results if r.get('warning')]
    if errors:
        _log_error(f'Post-edit complete ({elapsed:.0f}ms): {summary}')
        for e in errors:
            _log_error(f'  {e["file"]}: {e["warning"]}')
    elif results:
        _log_error(f'Post-edit OK ({elapsed:.0f}ms): {summary}')

    sys.exit(0)


if __name__ == "__main__":
    main()
