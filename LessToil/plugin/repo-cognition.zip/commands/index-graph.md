---
description: Generate a call graph, dependency graph, or domain graph from the index
argument-hint: "[function-name | domain <name> | --domain-graph | --hotspots | --orphans | --unified | --risk-graph]"
allowed-tools: Bash, Read, Write
---

Generate a graph visualization from the repository cognition index.

## Step 0: Verify Index Exists

First, check that the index database exists and has symbols:

```bash
if [ -f ".claude/index/repo-cognition/index.db" ] && [ -s ".claude/index/repo-cognition/index.db" ]; then
  HAS_DATA=$(sqlite3 .claude/index/repo-cognition/index.db "SELECT CASE WHEN COUNT(*) > 0 THEN 'yes' ELSE 'no' END FROM symbols;" 2>/dev/null || echo "no")
  echo "DB_EXISTS:yes SYMBOLS:$HAS_DATA"
else
  echo "DB_EXISTS:no SYMBOLS:no"
fi
```

If DB_EXISTS is "no": Display:
```
No index database found. Run /index-rebuild to create it.
```

If DB_EXISTS is "yes" but SYMBOLS is "no": Display:
```
Index exists but has no symbols. The index may be partially built.
Run /index-rebuild to re-extract symbols.
```

If both are "yes", proceed with the graph mode below.

## Modes

- **Call graph**: Pass a function name to see its callers and callees
- **Domain graph**: `--domain-graph` to see cross-domain dependencies with security boundaries highlighted
- **Hotspots**: `--hotspots` to see the most-called functions ranked by call count
- **Orphans**: `--orphans` to see functions that are never called (potential dead code)
- **Risk graph**: `--risk-graph` to see the riskiest files by temporal risk score
- **Taint graph**: `--taint-graph` to see security taint flows from source to sink
- **Unified graph**: `--unified` to export the full weighted multi-edge graph (AST, type, runtime, profiling, temporal)

## Steps

### Call Graph Mode (default)

1. Query the symbol:
   ```bash
   sqlite3 .claude/index/repo-cognition/index.db "
   SELECT s.name, s.kind, f.file_path, s.start_line, s.confidence_score, s.security_sensitive
   FROM symbols s JOIN files f ON s.file_id = f.id
   WHERE s.name = '$ARGUMENTS';
   " 2>/dev/null || echo "QUERY_FAILED"
   ```

2. Find callers:
   ```bash
   sqlite3 .claude/index/repo-cognition/index.db "
   SELECT DISTINCT s.name, f.file_path, ce.call_line, ce.is_dynamic
   FROM call_edges ce
   JOIN symbols s ON ce.caller_id = s.id
   JOIN files f ON s.file_id = f.id
   WHERE ce.callee_name = '$ARGUMENTS'
   LIMIT 50;
   " 2>/dev/null || echo "QUERY_FAILED"
   ```

3. Find callees:
   ```bash
   sqlite3 .claude/index/repo-cognition/index.db "
   SELECT DISTINCT ce.callee_name, ce.callee_file, ce.call_line, ce.is_dynamic
   FROM call_edges ce
   JOIN symbols s ON ce.caller_id = s.id
   WHERE s.name = '$ARGUMENTS'
   LIMIT 50;
   " 2>/dev/null || echo "QUERY_FAILED"
   ```

4. Show confidence scores for the function and its immediate neighbors:
   ```bash
   sqlite3 .claude/index/repo-cognition/index.db "
   SELECT s.name, cs.aggregate_confidence, cs.parser_confidence, cs.type_confidence, cs.runtime_confidence
   FROM confidence_scores cs
   JOIN symbols s ON cs.symbol_id = s.id
   WHERE s.name = '$ARGUMENTS'
      OR s.name IN (SELECT DISTINCT ce.callee_name FROM call_edges ce JOIN symbols caller ON ce.caller_id = caller.id WHERE caller.name = '$ARGUMENTS');
   " 2>/dev/null || echo "QUERY_FAILED"
   ```

5. If all queries fail, say "No data found for '$ARGUMENTS'. The symbol may not be indexed. Run /index-rebuild to refresh."

6. Present the results: list callers and callees with confidence scores, show security-sensitive markers, highlight dynamic edges.

### Domain Graph Mode (--domain-graph)

1. First check if domains exist:
   ```bash
   sqlite3 .claude/index/repo-cognition/index.db "SELECT COUNT(*) FROM domains;" 2>/dev/null || echo "0"
   ```
   If 0: "No domains found. Domain classification runs during indexing. Run /index-rebuild to classify files into domains."

2. Query domain interconnections (only if domains exist):
   ```bash
   sqlite3 .claude/index/repo-cognition/index.db "
   SELECT DISTINCT d1.name AS from_domain, d2.name AS to_domain, COUNT(*) AS connections,
                  MAX(CASE WHEN d1.security_boundary OR d2.security_boundary THEN 1 ELSE 0 END) AS crosses_boundary
   FROM call_edges ce
   JOIN symbols s_caller ON ce.caller_id = s_caller.id
   JOIN files f_caller ON s_caller.file_id = f_caller.id
   JOIN file_domains fd1 ON f_caller.id = fd1.file_id
   JOIN domains d1 ON fd1.domain_id = d1.id
   JOIN symbols s_callee ON ce.callee_name = s_callee.name
   JOIN files f_callee ON s_callee.file_id = f_callee.id
   JOIN file_domains fd2 ON f_callee.id = fd2.file_id
   JOIN domains d2 ON fd2.domain_id = d2.id
   WHERE d1.name != d2.name
   GROUP BY d1.name, d2.name
   ORDER BY connections DESC
   LIMIT 50;
   " 2>/dev/null || echo "QUERY_FAILED"
   ```

3. Identify circular dependencies, orphan domains, hub domains, and security boundary crossings.

### Hotspots Mode (--hotspots)

1. Guard: check if call_edges has data:
   ```bash
   sqlite3 .claude/index/repo-cognition/index.db "SELECT COUNT(*) FROM call_edges;" 2>/dev/null || echo "0"
   ```
   If 0: "No call edges in the index. Run /index-rebuild to rebuild call graph."

2. Find the most-called functions:
   ```bash
   sqlite3 .claude/index/repo-cognition/index.db "
   SELECT ce.callee_name, COUNT(DISTINCT ce.caller_id) AS caller_count,
          AVG(cs.aggregate_confidence) AS avg_confidence
   FROM call_edges ce
   LEFT JOIN symbols s ON ce.callee_name = s.name
   LEFT JOIN confidence_scores cs ON s.id = cs.symbol_id
   WHERE ce.callee_name IS NOT NULL
   GROUP BY ce.callee_name
   ORDER BY caller_count DESC
   LIMIT 20;
   " 2>/dev/null || echo "QUERY_FAILED"
   ```

3. Additionally show hotspots by temporal risk:
   ```bash
   sqlite3 .claude/index/repo-cognition/index.db "
   SELECT f.file_path, tm.risk_score, tm.total_commits, tm.bug_fix_commits, tm.instability
   FROM temporal_metrics tm
   JOIN files f ON tm.file_id = f.id
   ORDER BY tm.risk_score DESC
   LIMIT 15;
   " 2>/dev/null || echo "QUERY_FAILED"
   ```

### Orphans Mode (--orphans)

1. Find functions that are never called:
   ```bash
   sqlite3 .claude/index/repo-cognition/index.db "
   SELECT s.name, s.kind, f.file_path, s.start_line,
          cs.aggregate_confidence
   FROM symbols s
   JOIN files f ON s.file_id = f.id
   LEFT JOIN confidence_scores cs ON s.id = cs.symbol_id
   WHERE s.kind IN ('function', 'method')
     AND s.name NOT IN (SELECT DISTINCT ce.callee_name FROM call_edges WHERE ce.callee_name IS NOT NULL)
   ORDER BY f.file_path, s.start_line
   LIMIT 50;
   " 2>/dev/null || echo "QUERY_FAILED"
   ```

2. Cross-reference with drift scores — orphans in high-drift files are strong deletion candidates.

### Risk Graph Mode (--risk-graph)

1. Guard: check temporal_metrics:
   ```bash
   sqlite3 .claude/index/repo-cognition/index.db "SELECT COUNT(*) FROM temporal_metrics;" 2>/dev/null || echo "0"
   ```
   If 0: "No temporal metrics. Git history analysis runs during /index-rebuild."

2. Show top files by temporal risk with domain and governance context:
   ```bash
   sqlite3 .claude/index/repo-cognition/index.db "
   SELECT f.file_path, f.architectural_drift_score, tm.risk_score,
          tm.bug_fix_commits, tm.security_patch_commits, tm.instability,
          GROUP_CONCAT(DISTINCT d.name) AS domains
   FROM files f
   LEFT JOIN temporal_metrics tm ON f.id = tm.file_id
   LEFT JOIN file_domains fd ON f.id = fd.file_id
   LEFT JOIN domains d ON fd.domain_id = d.id
   WHERE tm.risk_score >= 0.5
   GROUP BY f.id
   ORDER BY tm.risk_score DESC
   LIMIT 20;
   " 2>/dev/null || echo "QUERY_FAILED"
   ```

### Taint Graph Mode (--taint-graph)

1. Guard: check taint_flows:
   ```bash
   sqlite3 .claude/index/repo-cognition/index.db "SELECT COUNT(*) FROM taint_flows;" 2>/dev/null || echo "0"
   ```
   If 0: "No taint flows found. Taint analysis runs during indexing."

2. Show security taint flows from source to sink:
   ```bash
   sqlite3 .claude/index/repo-cognition/index.db "
   SELECT s1.name AS source, s2.name AS target, tf.depth,
          f1.file_path AS source_file, f2.file_path AS target_file
   FROM taint_flows tf
   JOIN symbols s1 ON tf.source_id = s1.id
   JOIN symbols s2 ON tf.target_id = s2.id
   JOIN files f1 ON s1.file_id = f1.id
   JOIN files f2 ON s2.file_id = f2.id
   ORDER BY tf.depth DESC LIMIT 30;
   " 2>/dev/null || echo "QUERY_FAILED"
   ```

### Unified Graph Mode (--unified)

1. Export the full weighted multi-edge graph (AST + type + runtime + profiling + temporal):
   ```bash
   CLAUDE_PLUGIN_ROOT="${CLAUDE_PLUGIN_ROOT:-.}" python -c "
   import sys, os
   sys.path.insert(0, os.environ.get('CLAUDE_PLUGIN_ROOT', '.'))
   from core.unified_graph import export_unified_graph
   result = export_unified_graph()
   print(f'Unified graph: {result[\"node_count\"]} nodes, {result[\"edge_count\"]} edges')
   print(f'JSON: {result[\"json_path\"]}')
   print(f'DOT:  {result[\"dot_path\"]}')
   " 2>/dev/null || echo "Unified graph export not available — ensure Python and CLAUDE_PLUGIN_ROOT are set."
   ```

2. Inform the user of the output locations.
