---
description: Run a comprehensive diagnostic check of the repository cognition engine
allowed-tools: Bash, Read
---

Run a full diagnostic check of the Repository Cognition Engine to identify and fix issues.

## Step 1: Run Diagnostics via Python Module

The most reliable way is to use the built-in diagnostics module:

```bash
CLAUDE_PLUGIN_ROOT="${CLAUDE_PLUGIN_ROOT:-.}" python -c "
import sys, os
plugin_root = os.environ.get('CLAUDE_PLUGIN_ROOT', '.')
sys.path.insert(0, plugin_root)
from core.diagnostics import run_diagnostics, format_diagnostic_result
report = run_diagnostics()
print(format_diagnostic_result(report))
" 2>/dev/null
```

If the Python module approach fails (e.g., CLAUDE_PLUGIN_ROOT not set), fall back to manual checks:

## Step 2: Fallback Manual Checks

Run each check independently:

### Python
```bash
python3 --version 2>/dev/null || python --version 2>/dev/null || echo "Python not found"
```

### Index database
```bash
if [ -f ".claude/index/repo-cognition/index.db" ]; then
  echo "DB: EXISTS ($(stat -f%z .claude/index/repo-cognition/index.db 2>/dev/null || wc -c < .claude/index/repo-cognition/index.db) bytes)"
  sqlite3 .claude/index/repo-cognition/index.db "SELECT 'tables:' || COUNT(*) FROM sqlite_master WHERE type='table';" 2>/dev/null || echo "DB: CORRUPT"
  sqlite3 .claude/index/repo-cognition/index.db "
    SELECT 'files:' || COUNT(*) FROM files
    UNION ALL SELECT 'symbols:' || COUNT(*) FROM symbols
    UNION ALL SELECT 'edges:' || COUNT(*) FROM call_edges;
  " 2>/dev/null || echo "QUERY_FAILED"
else
  echo "DB: MISSING"
fi
```

### Integrity check
```bash
sqlite3 .claude/index/repo-cognition/index.db "
SELECT 'orphan_symbols:' || COUNT(*) FROM symbols s WHERE NOT EXISTS (SELECT 1 FROM files f WHERE f.id = s.file_id)
UNION ALL SELECT 'orphan_edges:' || COUNT(*) FROM call_edges ce WHERE NOT EXISTS (SELECT 1 FROM symbols s WHERE s.id = ce.caller_id);
" 2>/dev/null || echo "INTEGRITY_CHECK_FAILED"
```

### Lock file
```bash
if [ -f ".claude/index/repo-cognition/indexing.lock" ]; then
  echo "LOCK: EXISTS"
  cat .claude/index/repo-cognition/indexing.lock
else
  echo "LOCK: CLEAR"
fi
```

### Error log
```bash
if [ -f ".claude/index/repo-cognition/errors.log" ]; then
  ERR_COUNT=$(wc -l < ".claude/index/repo-cognition/errors.log")
  echo "ERRORS: $ERR_COUNT entries"
  tail -10 ".claude/index/repo-cognition/errors.log"
else
  echo "ERRORS: none"
fi
```

### Environment
```bash
echo "CLAUDE_PLUGIN_ROOT=${CLAUDE_PLUGIN_ROOT:-not set}"
echo "CLAUDE_PROJECT_DIR=${CLAUDE_PROJECT_DIR:-not set}"
echo "PWD=$(pwd)"
```

## Step 3: Present Diagnostic Results

Format findings as a checklist. For each that fails, include the exact command to fix it.

### Example output format:

```
+----------------------------------------------------------+
|  REPOSITORY COGNITION  --  System Check                  |
|  !  WARN -- 2 issues found                               |
+----------------------------------------------------------+

  [OK]  Python version       Python 3.11.6
  [OK]  Project directory    /home/user/project (git: yes)
  [OK]  Index directory      exists and writable
  [OK]  Index database       234 files, 1892 symbols, 4512 edges
  [!!]  Error log            3 errors recorded
  [XX]  Index lock           Stale lock from PID 12345
       -> Fix: Delete .claude/index/repo-cognition/indexing.lock

  ===========================================================
  /index-rebuild  |  /index-status  |  /index-graph
```

## Step 4: Auto-Fix Option

If only minor issues are found (stale lock, orphan records), offer to fix them:

- **Stale lock**: Run `rm -f .claude/index/repo-cognition/indexing.lock`
- **Orphan records**: Run the integrity repair via Python:
  ```bash
  CLAUDE_PLUGIN_ROOT="${CLAUDE_PLUGIN_ROOT:-.}" python -c "
  import sys, os
  sys.path.insert(0, os.environ.get('CLAUDE_PLUGIN_ROOT', '.'))
  from core.manifest import repair_index
  result = repair_index()
  print('Repaired:', result['repaired'])
  for action in result['actions']:
      print(f'  - {action}')
  "
  ```
- **Missing/empty index**: Run `/index-rebuild`

If the user approves, apply the fixes and re-run diagnostics to confirm resolution.
