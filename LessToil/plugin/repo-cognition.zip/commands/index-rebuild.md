---
description: Force a full rebuild of the repository cognition index
allowed-tools: Bash
---

Force a complete rebuild of the repository cognition index from scratch.

## Step 1: Detect Environment

First, determine the plugin root, Python, and project directories. Try in order:

```bash
# Detect CLAUDE_PLUGIN_ROOT
if [ -n "$CLAUDE_PLUGIN_ROOT" ]; then
  PLUGIN_DIR="$CLAUDE_PLUGIN_ROOT"
elif [ -d "$HOME/.claude/plugins/repo-cognition" ]; then
  PLUGIN_DIR="$HOME/.claude/plugins/repo-cognition"
elif [ -d "$HOME/.claude/plugins/less-toil" ]; then
  PLUGIN_DIR="$HOME/.claude/plugins/less-toil"
else
  echo "Cannot find plugin directory. Set CLAUDE_PLUGIN_ROOT environment variable."
  exit 1
fi

# Detect Python
for py in python3 python; do
  if command -v "$py" >/dev/null 2>&1; then
    PYTHON="$py"
    break
  fi
done
if [ -z "$PYTHON" ]; then
  echo "Cannot find Python. Install Python 3.8+ from https://python.org"
  exit 1
fi

echo "PLUGIN_DIR=$PLUGIN_DIR"
echo "PYTHON=$PYTHON"
echo "PROJECT_DIR=$(pwd)"
```

On **Windows (PowerShell)**, use:
```powershell
if ($env:CLAUDE_PLUGIN_ROOT) {
  $PLUGIN_DIR = $env:CLAUDE_PLUGIN_ROOT
} elseif (Test-Path "$env:USERPROFILE\.claude\plugins\repo-cognition") {
  $PLUGIN_DIR = "$env:USERPROFILE\.claude\plugins\repo-cognition"
} elseif (Test-Path "$env:USERPROFILE\.claude\plugins\less-toil") {
  $PLUGIN_DIR = "$env:USERPROFILE\.claude\plugins\less-toil"
} else {
  Write-Host "Cannot find plugin directory. Set CLAUDE_PLUGIN_ROOT."
  exit 1
}
$PYTHON = (Get-Command python -ErrorAction SilentlyContinue) ?? (Get-Command python3 -ErrorAction SilentlyContinue) ?? (Get-Command py -ErrorAction SilentlyContinue)
```

## Step 2: Clear Existing Index

```bash
rm -f .claude/index/repo-cognition/index.db \
      .claude/index/repo-cognition/index.db-wal \
      .claude/index/repo-cognition/index.db-shm \
      .claude/index/repo-cognition/file_manifest.json \
      .claude/index/repo-cognition/indexing.lock \
      .claude/index/repo-cognition/last_index.txt \
      .claude/index/repo-cognition/errors.log
```

## Step 3: Run SessionStart Hook

```bash
CLAUDE_PLUGIN_ROOT="$PLUGIN_DIR" \
CLAUDE_PROJECT_DIR="$(pwd)" \
"$PYTHON" "$PLUGIN_DIR/hooks/session_start.py" <<< '{"session_id":"rebuild","cwd":"'"$(pwd)"'"}'
```

On Windows PowerShell:
```powershell
$env:CLAUDE_PLUGIN_ROOT = $PLUGIN_DIR
$env:CLAUDE_PROJECT_DIR = (Get-Location).Path
$inputJson = '{"session_id":"rebuild","cwd":"' + (Get-Location).Path + '"}'
$inputJson | & $PYTHON "$PLUGIN_DIR\hooks\session_start.py"
```

## Step 4: Confirm Rebuild

After the hook completes, verify the index was rebuilt:

```bash
sqlite3 .claude/index/repo-cognition/index.db \
  "SELECT 'files:' || COUNT(*) FROM files
   UNION ALL SELECT 'symbols:' || COUNT(*) FROM symbols
   UNION ALL SELECT 'edges:' || COUNT(*) FROM call_edges
   UNION ALL SELECT 'schema:v' || version FROM schema_version;"
```

Check for any errors during indexing:
```bash
if [ -f ".claude/index/repo-cognition/errors.log" ]; then
  echo "Errors logged:"
  tail -20 ".claude/index/repo-cognition/errors.log"
else
  echo "No errors logged."
fi
```

Report the new file count, symbol count, call edge count, schema version, and any errors to confirm the rebuild succeeded.

## Step 5: If Rebuild Fails

If the hook exits with an error or the index is still empty after rebuild:

1. Check Python version: `$PYTHON --version` (needs 3.8+)
2. Check project directory is a git repo: `git rev-parse --show-toplevel`
3. Try running diagnostics: `/index-check`
4. Check the error log: `.claude/index/repo-cognition/errors.log`
5. Manually run: `CLAUDE_PLUGIN_ROOT="$PLUGIN_DIR" CLAUDE_PROJECT_DIR="$(pwd)" $PYTHON "$PLUGIN_DIR/hooks/session_start.py"`
