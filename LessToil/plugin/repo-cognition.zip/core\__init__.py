"""Repository Cognition Engine - core constants and path configuration."""

import os

# The project root is the CWD when the hook runs.
# CLAUDE_PROJECT_DIR is set by the engine; fall back to CWD.
PROJECT_DIR = os.environ.get('CLAUDE_PROJECT_DIR', os.getcwd())
INDEX_DIR = os.path.join(PROJECT_DIR, '.claude', 'index', 'repo-cognition')
DB_PATH = os.path.join(INDEX_DIR, 'index.db')
MANIFEST_PATH = os.path.join(INDEX_DIR, 'file_manifest.json')
SYMBOL_GRAPH_PATH = os.path.join(INDEX_DIR, 'symbol_graph.json')
CALL_GRAPH_PATH = os.path.join(INDEX_DIR, 'call_graph.json')
TAXONOMY_PATH = os.path.join(INDEX_DIR, 'project_taxonomy.md')
CLAUDE_MD_PATH = os.path.join(INDEX_DIR, 'CLAUDE.md')
DOMAINS_STATE_PATH = os.path.join(PROJECT_DIR, '.claude', 'repo-cognition.domains.local.md')
PATTERNS_STATE_PATH = os.path.join(PROJECT_DIR, '.claude', 'repo-cognition.patterns.local.md')
LOCK_PATH = os.path.join(INDEX_DIR, 'indexing.lock')
LAST_INDEX_PATH = os.path.join(INDEX_DIR, 'last_index.txt')
POLICIES_PATH = os.path.join(PROJECT_DIR, '.claude', 'repo-cognition.policies.local.md')
KNOWLEDGE_PATH = os.path.join(PROJECT_DIR, '.claude', 'repo-cognition.knowledge.local.md')

# Ensure index directory exists
os.makedirs(INDEX_DIR, exist_ok=True)
