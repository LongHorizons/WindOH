#!/usr/bin/env python3
"""
SessionStart hook for the Repository Cognition Engine.
Walks the repository, indexes files into SQLite, and injects a structural
summary into the agent's session context.
"""

from __future__ import annotations

import json
import os
import sys
import time

# Add the plugin root to sys.path so we can import core modules.
# When run by Claude Code, CLAUDE_PLUGIN_ROOT is set automatically.
# When run manually (e.g. /index-rebuild), auto-detect from this file's location.
PLUGIN_ROOT = os.environ.get('CLAUDE_PLUGIN_ROOT', '')
if not PLUGIN_ROOT:
    PLUGIN_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PLUGIN_ROOT:
    sys.path.insert(0, PLUGIN_ROOT)

import core
from core import INDEX_DIR, LAST_INDEX_PATH, LOCK_PATH, CLAUDE_MD_PATH, MANIFEST_PATH
from core.formatting import dashboard_compact
from core.manifest import (
    init_db, upsert_file, get_stats, export_manifest_json,
    upsert_symbols_batch, insert_call_edges_batch, get_connection,
    verify_index_integrity, repair_index
)
from core.indexer import (
    walk_repository, load_previous_manifest, get_changed_files,
    write_last_index_timestamp, acquire_lock, remove_lock, is_locked,
    force_clear_lock
)
from core.error_log import log_error, log_warning, get_error_count, clear_error_log, format_error_summary

PROJECT_DIR = core.PROJECT_DIR

# Maximum time (seconds) for symbol extraction before deferring to background
MAX_EXTRACTION_TIME = 30


def ensure_gitignore() -> None:
    """Ensure .claude/index/ is listed in the project's .gitignore."""
    gitignore_path = os.path.join(PROJECT_DIR, '.gitignore')
    entry = '.claude/index/'

    try:
        if os.path.exists(gitignore_path):
            with open(gitignore_path, 'r') as f:
                content = f.read()
            if entry not in content:
                with open(gitignore_path, 'a') as f:
                    if not content.endswith('\n'):
                        f.write('\n')
                    f.write(entry + '\n')
        else:
            with open(gitignore_path, 'w') as f:
                f.write(entry + '\n')
    except Exception:
        pass  # Non-critical — never block the session for gitignore


def read_hook_input() -> dict:
    """Read and parse JSON from stdin."""
    try:
        raw = sys.stdin.read()
        if not raw.strip():
            return {}
        return json.loads(raw)
    except json.JSONDecodeError:
        return {}


def index_health(stats: dict) -> str:
    """Return a concise health indicator for the index."""
    file_count = stats.get('file_count', 0)
    symbol_count = stats.get('symbol_count', 0)
    edge_count = stats.get('edge_count', 0)

    if file_count == 0:
        return '-  NO DATA'
    if symbol_count == 0:
        return '~  INDEXING (files only)'

    signals_ok = 0
    signals_total = 0
    signals_total += 1
    if edge_count > 0:
        signals_ok += 1
    signals_total += 1
    if symbol_count >= file_count * 0.5:
        signals_ok += 1

    if signals_ok == signals_total:
        return '*  HEALTHY'
    elif signals_ok >= signals_total * 0.5:
        return '~  DEGRADED'
    return '-  LIMITED'


def format_dashboard(stats: dict, indexing_time: float, domain_info: dict,
                     conf: dict, temporal: dict, drift: dict,
                     top_suggestions: list, risky_files: list) -> str:
    """Build a professional visual dashboard for the systemMessage."""
    file_count = stats.get('file_count', 0)
    symbol_count = stats.get('symbol_count', 0)
    edge_count = stats.get('edge_count', 0)
    domain_count = len(domain_info.get('_domains', []))
    sim_count = stats.get('_similarity_count', 0)

    health = index_health(stats)

    lines = []
    # -- Header with random quote --
    lines.append(build_dashboard_header())
    lines.append(f'|  {health:<58}|')
    lines.append('+' + '-' * 58 + '+')
    lines.append('')

    # -- Core Metrics --
    lines.append('  --  CORE METRICS')
    lines.append(f'  Files: {file_count} files indexed in {indexing_time:.1f}s    Edges: {edge_count} call edges')
    lines.append(f'  Symbols: {symbol_count} symbols              Simhashes: {sim_count} simhashes')
    lines.append(f'  Domains: {domain_count} domains                 Schema v3, 26 tables')
    lines.append('')

    # -- Language Distribution --
    languages = stats.get('languages', {})
    if languages:
        max_count = max(languages.values()) if languages else 1
        lines.append('  --  LANGUAGE DISTRIBUTION')
        for lang, count in list(languages.items())[:9]:
            bar_len = max(1, int(count / max_count * 16))
            bar = '#' * bar_len + '.' * (16 - bar_len)
            lines.append(f'     {lang:<12} {bar} {count}')
        lines.append('')

    # -- Temporal Risk --
    if temporal and temporal.get('available') and temporal.get('files_analyzed', 0) > 0:
        high_risk = temporal.get('high_risk_count', 0)
        critical = temporal.get('critical_risk_count', 0)
        avg_risk = temporal.get('average_risk', 0)
        if critical > 0:
            status = '*  CRITICAL'
        elif high_risk > 3:
            status = '~  ELEVATED'
        else:
            status = '*  NOMINAL'
        lines.append(f'  --  TEMPORAL RISK  [{status}]')
        lines.append(f'  Avg: {avg_risk:.2f}    High-risk (>0.7): {high_risk}    Critical (>0.9): {critical}')
        if risky_files:
            lines.append('')
            for r in risky_files[:3]:
                marker = '>>' if r['risk_score'] >= 0.9 else ('>' if r['risk_score'] >= 0.7 else '  ')
                lines.append(f'     {marker}  {r["file_path"]}  [{r["risk_score"]:.2f}]')
        lines.append('')

    # -- Confidence --
    if conf and conf.get('total', 0) > 0:
        avg_conf = conf.get('avg_aggregate', 0)
        low_count = conf.get('low_confidence', 0)
        if avg_conf < 0.5:
            status = '-  LOW'
        elif avg_conf < 0.7:
            status = '~  MODERATE'
        else:
            status = '*  HIGH'
        lines.append(f'  --  CONFIDENCE  [{status}]')
        lines.append(f'  Avg aggregate: {avg_conf:.2f}    Below threshold: {low_count}')
        lines.append('')

    # -- Architectural Drift --
    if drift and drift.get('files_analyzed', 0) > 0:
        avg_drift = drift.get('average_drift', 0)
        high_drift = drift.get('high_drift_files', 0)
        if high_drift > 5:
            status = '~  ELEVATED'
        elif high_drift > 0:
            status = '~  PRESENT'
        else:
            status = '*  STABLE'
        lines.append(f'  --  ARCHITECTURAL DRIFT  [{status}]')
        lines.append(f'  Avg: {avg_drift:.2f}    Files drifting: {high_drift}')
        lines.append('')

    # -- Stewardship --
    if top_suggestions:
        lines.append('  --  STEWARDSHIP')
        for s in top_suggestions[:5]:
            icon = '>>' if s['severity'] == 'high' else ('>' if s['severity'] == 'medium' else '  ')
            lines.append(f'     {icon}  [{s["severity"].upper()}] {s["title"]}')
        lines.append('')

    # -- Security --
    lines.append('  --  SECURITY')
    lines.append('  [sec] Taint tracking active, Trust boundaries monitored, Immune system engaged')
    lines.append('')

    # -- Footer --
    lines.append('  =======================================================')
    lines.append('  /index-status  ·  /index-graph  ·  /index-rebuild')
    lines.append('')

    return '\n'.join(lines)


def format_stats_summary(stats: dict, indexing_time: float) -> str:
    """Format index statistics as agent-readable context (additionalContext)."""
    lang_lines = '\n'.join(
        f"  - {lang}: {count} files"
        for lang, count in list(stats['languages'].items())[:10]
    )

    # Confidence summary
    confidence_note = ''
    try:
        from core.confidence import get_confidence_summary, get_low_confidence_symbols
        conf = get_confidence_summary()
        if conf.get('total', 0) > 0:
            confidence_note = (
                f"\n### Confidence\n"
                f"Average: {conf['avg_aggregate']:.2f} "
                f"(parser: {conf['avg_parser']:.2f}, "
                f"type: {conf['avg_type']:.2f})\n"
                f"{conf['low_confidence']}/{conf['total']} symbols below "
                f"autonomous threshold (0.50)"
            )
            if conf['low_confidence'] > 0:
                low_syms = get_low_confidence_symbols(5)
                if low_syms:
                    lines = '\n'.join(
                        f"  - `{s['name']}` ({s['kind']}) in {s['file']} [{s['confidence']:.2f}]"
                        for s in low_syms
                    )
                    confidence_note += f"\n**Low-confidence symbols**:\n{lines}"
    except Exception as e:
        log_warning('session_start', f'Confidence summary failed: {e}')

    # Temporal intelligence summary
    temporal_note = ''
    try:
        from core.temporal import get_temporal_summary, get_riskiest_files
        temporal = get_temporal_summary()
        if temporal.get('available') and temporal.get('files_analyzed', 0) > 0:
            temporal_note = (
                f"\n### Temporal Risk (git history)\n"
                f"Files analyzed: {temporal['files_analyzed']}, "
                f"avg risk: {temporal['average_risk']:.3f}, "
                f"high-risk: {temporal['high_risk_count']}, "
                f"critical: {temporal['critical_risk_count']}"
            )
            risky = get_riskiest_files(5)
            if risky:
                lines = '\n'.join(
                    f"  - {r['file_path']} — risk {r['risk_score']:.3f} "
                    f"({r['total_commits']} commits, {r['bug_fix_commits']} bug-fix)"
                    for r in risky
                )
                temporal_note += f"\n**Top riskiest files**:\n{lines}"
    except Exception as e:
        log_warning('session_start', f'Temporal summary failed: {e}')

    # Stewardship summary
    stewardship_note = ''
    try:
        from core.stewardship import get_top_suggestions
        top = get_top_suggestions(5)
        if top:
            lines = '\n'.join(
                f"  - [{s['severity'].upper()}] {s['title']}"
                for s in top
            )
            stewardship_note = f"\n### Top Stewardship Suggestions\n{lines}"
    except Exception as e:
        log_warning('session_start', f'Stewardship summary failed: {e}')

    # Drift summary
    drift_note = ''
    try:
        from core.drift_detection import get_drift_summary
        drift = get_drift_summary()
        if drift.get('files_analyzed', 0) > 0:
            drift_note = (
                f"\n### Architectural Drift\n"
                f"Average drift: {drift['average_drift']:.3f} across "
                f"{drift['files_analyzed']} files. "
                f"High drift files: {drift['high_drift_files']}"
            )
    except Exception as e:
        log_warning('session_start', f'Drift summary failed: {e}')

    return f"""## Repository Cognition Engine Active

**Index**: {stats['file_count']} files indexed ({stats['total_size_bytes'] / 1024:.0f} KB) in {indexing_time:.1f}s.
**Symbols**: {stats['symbol_count']} symbols, {stats['edge_count']} call edges.
**Last index**: {stats.get('last_full_index', 'just now')}

### Languages
{lang_lines if lang_lines else '  (no files indexed yet)'}
{confidence_note}{temporal_note}{drift_note}{stewardship_note}
### Query the Index
- `.claude/index/repo-cognition/index.db` — SQLite database (use sqlite3 or python)
- `.claude/index/repo-cognition/CLAUDE.md` — schema reference and query examples
- `/index-status` — view index health and statistics
- `/index-graph <function>` — generate call graph for a symbol
- `/index-rebuild` — force full index rebuild"""


def index_file_symbols(file_path: str, language: str) -> tuple[int, int]:
    """Parse a single file for symbols and store them. Returns (symbol_count, edge_count)."""
    from core.symbols import parse_file, SUPPORTED_LANGUAGES

    if language not in SUPPORTED_LANGUAGES:
        return 0, 0

    full_path = os.path.join(PROJECT_DIR, file_path)
    symbols, calls = parse_file(full_path, language)

    if not symbols:
        return 0, 0

    # Get file_id from the database
    conn = get_connection()
    try:
        cur = conn.execute("SELECT id FROM files WHERE file_path = ?", (file_path,))
        row = cur.fetchone()
        if row is None:
            return 0, 0
        file_id = row[0]
    finally:
        conn.close()

    upsert_symbols_batch(file_id, symbols)

    # Compute confidence scores for extracted symbols
    try:
        from core.confidence import compute_confidence_batch
        compute_confidence_batch(file_id, symbols, language)
    except Exception as e:
        log_warning('session_start', f'Confidence scoring failed for {file_path}: {e}')

    # Match calls to caller symbols and insert edges
    edges = []
    for call in calls:
        # Find the caller symbol (function whose body contains this call)
        cur2 = get_connection()
        try:
            cur = cur2.execute(
                """SELECT id FROM symbols
                   WHERE file_id = ? AND kind IN ('function', 'method')
                     AND start_line <= ? AND end_line >= ?
                   LIMIT 1""",
                (file_id, call['call_line'], call['call_line'])
            )
            caller_row = cur.fetchone()
            if caller_row:
                edges.append({
                    'caller_id': caller_row[0],
                    'callee_name': call['callee_name'],
                    'callee_file': call.get('callee_file'),
                    'call_line': call['call_line'],
                    'is_dynamic': call.get('is_dynamic', False),
                    'confidence': call.get('confidence', 1.0),
                })
        finally:
            cur2.close()

    if edges:
        insert_call_edges_batch(edges)

    return len(symbols), len(edges)


def run_full_index() -> dict:
    """Perform a full repository index. Returns stats dict."""
    init_db()

    # Ensure .claude/index/ is gitignored (cheap, non-critical)
    ensure_gitignore()

    # Seed built-in invariants and policies (idempotent via INSERT OR REPLACE)
    try:
        from core.governance import init_builtin_invariants, init_builtin_policies
        init_builtin_invariants()
        init_builtin_policies()
    except Exception as e:
        log_warning('session_start', f'Governance init failed: {e}')

    start_time = time.time()
    previous = load_previous_manifest()

    file_count = 0
    new_count = 0
    changed_count = 0
    files_to_extract = []  # (file_path, language) for symbol extraction

    for file_info in walk_repository():
        file_path = file_info['file_path']
        sha256 = file_info['sha256']
        language = file_info['language']

        is_new = previous is None or file_path not in previous
        is_changed = (previous is not None and file_path in previous
                      and previous[file_path] != sha256)

        if is_new or is_changed:
            upsert_file(
                file_path=file_path,
                sha256=sha256,
                language=language,
                file_size=file_info['file_size'],
                line_count=file_info['line_count'],
            )
            if is_new:
                new_count += 1
            else:
                changed_count += 1
            files_to_extract.append((file_path, language))

        file_count += 1

    # Also remove deleted files from index
    if previous is not None:
        conn = get_connection()
        try:
            for path in previous:
                full_path = os.path.join(PROJECT_DIR, path)
                if not os.path.exists(full_path):
                    conn.execute("DELETE FROM files WHERE file_path = ?", (path,))
            conn.commit()
        finally:
            conn.close()

    # Symbol extraction with timeout awareness
    extraction_start = time.time()
    total_symbols = 0
    total_edges = 0
    extracted_files = 0

    for file_path, language in files_to_extract:
        elapsed = time.time() - extraction_start
        if elapsed > MAX_EXTRACTION_TIME:
            break
        try:
            sym_count, edge_count = index_file_symbols(file_path, language)
            total_symbols += sym_count
            total_edges += edge_count
            extracted_files += 1
        except Exception:
            continue

    # Write exported manifest
    manifest_data = export_manifest_json()
    with open(MANIFEST_PATH, 'w') as f:
        json.dump(manifest_data, f, indent=2)

    write_last_index_timestamp()

    stats = {}

    # Classify files into architectural domains
    try:
        from core.domains import classify_all_files
        domain_counts = classify_all_files()
        stats['_domain_files'] = sum(domain_counts.values())
        stats['_domains'] = list(domain_counts.keys())
    except Exception as e:
        log_warning('session_start', f'Domain classification failed: {e}')

    # Compute temporal metrics (git history analysis)
    try:
        from core.temporal import compute_temporal_metrics
        compute_temporal_metrics()
    except Exception as e:
        log_warning('session_start', f'Temporal metrics failed: {e}')

    # Persist drift scores
    try:
        from core.drift_detection import persist_file_drift_scores
        persist_file_drift_scores(limit=100)
    except Exception as e:
        log_warning('session_start', f'Drift scoring failed: {e}')

    # Run stewardship scans and persist suggestions
    try:
        from core.stewardship import run_full_stewardship_scan, persist_suggestions
        suggestions = run_full_stewardship_scan()
        if suggestions:
            persist_suggestions(suggestions)
    except Exception as e:
        log_warning('session_start', f'Stewardship scan failed: {e}')

    # Compute similarity hashes (SimHash dedup)
    try:
        from core.similarity import run_similarity_pass
        sim_count = run_similarity_pass(limit=200)
        stats['_similarity_count'] = sim_count
    except Exception as e:
        log_warning('session_start', f'Similarity analysis failed: {e}')

    # Run self-healing pass (detect > propose > validate)
    try:
        from core.self_healing import run_self_healing_pass
        run_self_healing_pass()
    except Exception as e:
        log_warning('session_start', f'Self-healing pass failed: {e}')

    indexing_time = time.time() - start_time

    _prefixed = {k: v for k, v in stats.items() if k.startswith('_')}
    stats = get_stats()
    stats.update(_prefixed)
    stats['_new_files'] = new_count
    stats['_changed_files'] = changed_count
    stats['_total_scanned'] = file_count
    stats['_indexing_time_sec'] = indexing_time

    return stats


def main():
    global PROJECT_DIR

    input_data = read_hook_input()
    session_id = input_data.get('session_id', 'unknown')
    cwd = input_data.get('cwd', PROJECT_DIR)

    # Respect CLAUDE_PROJECT_DIR if set
    if 'CLAUDE_PROJECT_DIR' in os.environ:
        PROJECT_DIR = os.environ['CLAUDE_PROJECT_DIR']
        core.PROJECT_DIR = PROJECT_DIR

    # Check if another indexing process is already running
    if is_locked():
        try:
            stats = get_stats()
            summary = f"## Repository Cognition Engine\nIndexing in progress (background). Current index: {stats['file_count']} files.\nUse `/index-status` to check progress."
            dashboard = f'Repo Cognition: indexing in progress ({stats["file_count"]} files so far)'
            output = {
                "hookSpecificOutput": {
                    "hookEventName": "SessionStart",
                    "additionalContext": summary
                },
                "systemMessage": dashboard
            }
            print(json.dumps(output))
        except Exception as e:
            log_error('session_start', f'Failed to read stats while locked: {e}')
        sys.exit(0)

    # Perform indexing with atomic lock acquisition
    if not acquire_lock():
        # Could not acquire lock — another indexer is running
        try:
            stats = get_stats()
            summary = f"## Repository Cognition Engine\nIndexing already in progress. Current index: {stats['file_count']} files.\nUse `/index-status` to check progress."
            dashboard = f'Repo Cognition: indexing in progress ({stats["file_count"]} files so far)'
            output = {
                "hookSpecificOutput": {
                    "hookEventName": "SessionStart",
                    "additionalContext": summary
                },
                "systemMessage": dashboard
            }
            print(json.dumps(output))
        except Exception:
            pass
        sys.exit(0)

    try:
        # Clear old error log on fresh start
        clear_error_log()
        stats = run_full_index()
    finally:
        remove_lock()

    indexing_time = stats.get('_indexing_time_sec', 0)

    # Collect auxiliary data for the visual dashboard
    domain_info = {
        '_domains': stats.get('_domains', []),
        '_domain_files': stats.get('_domain_files', 0),
    }
    conf = {}
    try:
        from core.confidence import get_confidence_summary
        conf = get_confidence_summary()
    except Exception:
        pass
    temporal = {}
    risky_files = []
    try:
        from core.temporal import get_temporal_summary, get_riskiest_files
        temporal = get_temporal_summary()
        risky_files = get_riskiest_files(5)
    except Exception:
        pass
    drift = {}
    try:
        from core.drift_detection import get_drift_summary
        drift = get_drift_summary()
    except Exception:
        pass
    top_suggestions = []
    try:
        from core.stewardship import get_top_suggestions
        top_suggestions = get_top_suggestions(5)
    except Exception:
        pass

    domain_count = len(domain_info.get('_domains', []))
    health = index_health(stats)
    dashboard = dashboard_compact(stats, indexing_time, health, domain_count,
                                  temporal, drift)
    summary = format_stats_summary(stats, indexing_time)

    # -- Integrity check and auto-repair --
    integrity = verify_index_integrity()
    if not integrity['ok']:
        for issue in integrity['issues']:
            log_warning('session_start', f'Integrity issue: {issue}')
        # Attempt auto-repair
        try:
            repair_result = repair_index()
            if repair_result['repaired']:
                summary += f"\n\n### Auto-Repair\n{len(repair_result['actions'])} integrity issue(s) repaired:"
                for action in repair_result['actions']:
                    summary += f"\n  - {action}"
        except Exception as e:
            log_error('session_start', f'Auto-repair failed: {e}')

    # Check for empty index after successful indexing
    if stats.get('file_count', 0) == 0 and stats.get('_total_scanned', 0) > 0:
        log_warning('session_start',
            f'Walked {stats["_total_scanned"]} files but 0 were indexed. '
            'Check for file permission issues or excluded directories.'
        )

    # Generate CLAUDE.md if the script is available
    claude_md_script = os.path.join(
        os.environ.get('CLAUDE_PLUGIN_ROOT', ''), 'scripts', 'generate-claude-md.py'
    )
    if os.path.exists(claude_md_script):
        try:
            import subprocess
            subprocess.run(
                [sys.executable, claude_md_script],
                capture_output=True, timeout=30,
                env={**os.environ, 'PYTHONPATH': os.environ.get('CLAUDE_PLUGIN_ROOT', '')}
            )
            summary += "\n\nCLAUDE.md query reference generated at `.claude/index/repo-cognition/CLAUDE.md`."
        except Exception as e:
            log_warning('session_start', f'CLAUDE.md generation failed: {e}')

    # Append error summary if any warnings were logged
    error_count = get_error_count()
    if error_count > 0:
        recent_errors = []
        try:
            from core.error_log import get_recent_errors
            recent_errors = get_recent_errors(8)
        except Exception:
            pass
        error_summary = format_error_summary(recent_errors)
        summary += f"\n\n### Indexing Warnings\n{error_count} warning(s) logged. Review `.claude/index/repo-cognition/errors.log` for details."
        if recent_errors:
            summary += f"\n{error_summary}"

    output = {
        "hookSpecificOutput": {
            "hookEventName": "SessionStart",
            "additionalContext": summary
        },
        "systemMessage": dashboard
    }
    print(json.dumps(output))
    sys.exit(0)


if __name__ == "__main__":
    main()
